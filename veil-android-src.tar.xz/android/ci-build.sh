#!/usr/bin/env bash
# CI-Hilfsskript: baut die Debug-APK in einer von zwei Toolchain-Varianten und schreibt eine Kurzfassung der Fehler in die
# GitHub-Zusammenfassung ($GITHUB_STEP_SUMMARY), damit man sie auf dem Handy nicht aus dem langen Protokoll suchen muss.
#
# Toolchain in beiden Faellen: AGP 9.1.x / Gradle 9.3.1 / compileSdk 37 / neueste stabile Kotlin- und AndroidX-Versionen
# (so verlangen es GeckoView 157, tor-android und AndroidX 1.19; die aeltere Toolchain AGP 8.7.3 scheiterte am Java-24-
# Bytecode von tor-android: "Unsupported class file major version 68").
#   modern  Debug-APK       (:app:assembleDebug)   – das ist die Variante, die zaehlt
#   compat  Release-APK     (:app:assembleRelease) – Zusatzversuch (R8-verkleinert); ein Fehler hier laesst den Lauf gruen
#
# Aufruf (aus dem Repo-Wurzelverzeichnis):  bash apps/android/ci-build.sh compat|modern
# DRY_RUN=1 fuehrt nur die Anpassungen aus (kein Download, kein Gradle) – zum Testen des Skripts selbst.
set -uo pipefail

variant=${1:?usage: ci-build.sh compat|modern}
case "$variant" in compat|modern) ;; *) echo "unknown variant $variant" >&2; exit 2;; esac
dry=${DRY_RUN:-0}

root=$(cd "$(dirname "$0")" && pwd)
work=$root/ci-work/$variant
out=$root/ci-out/$variant
rm -rf "$work" "$out"; mkdir -p "$work" "$out"
tar -C "$root" --exclude=./ci-work --exclude=./ci-out --exclude=./ci-build.sh -cf - . | tar -C "$work" -xf -
cd "$work"

summary() { if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then cat >> "$GITHUB_STEP_SUMMARY"; else cat; fi; }

# Neueste stabile Version (nur Ziffern und Punkte, also ohne alpha/beta/rc) aus einer maven-metadata.xml; $2 = optionaler Regex-Filter.
latest_stable() {
  [ "$dry" = 1 ] && return 0
  curl -fsSL --retry 3 "$1" 2>/dev/null | grep -o '<version>[^<]*</version>' | sed 's/<[^>]*>//g' \
    | grep -E "${2:-^[0-9]+(\.[0-9]+)*\$}" | sort -V | tail -1
}
set_version() {  # set_version <key in libs.versions.toml> <value>   (leere Werte aendern nichts)
  [ -n "$2" ] && sed -i "s|^$1 = .*|$1 = \"$2\"|" gradle/libs.versions.toml
}

G=https://dl.google.com/android/maven2
bom=$(latest_stable "$G/androidx/compose/compose-bom/maven-metadata.xml")
act=$(latest_stable "$G/androidx/activity/activity-compose/maven-metadata.xml")
core=$(latest_stable "$G/androidx/core/core-ktx/maven-metadata.xml")
life=$(latest_stable "$G/androidx/lifecycle/lifecycle-runtime-compose/maven-metadata.xml")
kot=$(latest_stable "https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-gradle-plugin/maven-metadata.xml" '^2\.3\.[0-9]+$')
: "${kot:=2.3.0}"
set_version composeBom "$bom"; set_version activityCompose "$act"; set_version coreKtx "$core"; set_version lifecycle "$life"
set_version kotlin "$kot"

agp=$(latest_stable "$G/com/android/tools/build/gradle/maven-metadata.xml" '^9\.1\.[0-9]+$')
: "${agp:=9.1.0}"; gradle_ver=9.3.1; csdk=37
set_version agp "$agp"
sed -i "s/compileSdk = 35/compileSdk = $csdk/" app/build.gradle.kts
cat >> gradle.properties <<'PROPS'
android.suppressUnsupportedCompileSdk=37
android.builtInKotlin=false
android.newDsl=false
PROPS
if [ "$dry" != 1 ] && [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  # (AGP laedt die Plattform bei Bedarf selbst nach; das hier ist nur ein Versuch)
  "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1 < <(yes) || true
  "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platforms;android-$csdk" >/dev/null 2>&1 || true
fi
if [ "$variant" = compat ]; then task=:app:assembleRelease; kind="Release-Build"; else task=:app:assembleDebug; kind="Debug-Build"; fi

versions="AGP $agp, Gradle $gradle_ver, Kotlin $kot, compileSdk $csdk, Compose BOM ${bom:-unveraendert}, activity-compose ${act:-unveraendert}, core-ktx ${core:-unveraendert}"
echo "== Variante $variant ($kind): $versions"

status=0
if [ "$dry" = 1 ]; then
  echo "DRY_RUN: kein Gradle-Lauf" > "$out/build.log"; status=1
else
  gdir=$HOME/gradle-$gradle_ver
  if [ ! -x "$gdir/bin/gradle" ]; then
    curl -fsSL --retry 3 -o "/tmp/gradle-$gradle_ver.zip" "https://services.gradle.org/distributions/gradle-$gradle_ver-bin.zip" \
      && unzip -q "/tmp/gradle-$gradle_ver.zip" -d /tmp/gradle-unpack && mv "/tmp/gradle-unpack/gradle-$gradle_ver" "$gdir"
  fi
  if [ ! -x "$gdir/bin/gradle" ]; then echo "Gradle $gradle_ver konnte nicht geladen werden" | tee "$out/build.log"; status=1
  else
    "$gdir/bin/gradle" --no-daemon --console=plain --stacktrace "$task" 2>&1 | tee "$out/build.log"
    status=${PIPESTATUS[0]}
  fi
fi

find app/build/outputs/apk -name '*.apk' -exec cp {} "$out/" \; 2>/dev/null || true

{
  if [ $status -eq 0 ]; then echo "## Variante $variant ($kind): ERFOLG"; else echo "## Variante $variant ($kind): FEHLER"; fi
  echo "$versions"; echo
  if [ $status -eq 0 ]; then
    echo "APKs:"; echo '```'; (cd "$out" && ls -la -- *.apk); echo '```'
  else
    echo '```'
    # Kotlin-Fehler (ohne langen Pfad)
    grep -E '^e: ' "$out/build.log" | sed -E 's#file://[^ ]*/ci-work/[a-z]+/##' | cut -c1-240 | head -50
    # Gradle-Fehlerblock
    sed -n '/^FAILURE: Build failed/,/^\* Try:/p' "$out/build.log" | cut -c1-240 | head -70
    echo '```'
  fi
} | summary

# Der Release-Zusatzversuch darf den Lauf nicht rot faerben (sein Ergebnis steht in der Zusammenfassung).
[ "$variant" = compat ] && exit 0
exit $status
