import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "app.veil.browser"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.veil.browser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    // Release signing comes from the environment, never from the repository (see docs/ANDROID.md). Without it the release
    // APK is signed with the debug key: installable for sideloading, but not suitable for distribution or updates between
    // machines (a different debug key = uninstall first).
    signingConfigs {
        val keystore = System.getenv("VEIL_KEYSTORE")
        if (!keystore.isNullOrBlank()) {
            create("veil") {
                storeFile = file(keystore)
                storePassword = System.getenv("VEIL_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("VEIL_KEY_ALIAS")
                keyPassword = System.getenv("VEIL_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("veil") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { compose = true }

    packaging {
        // GeckoView ships large native libraries and expects to find them extracted on disk.
        jniLibs { useLegacyPackaging = true }
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    // One APK per ABI keeps downloads reasonable (GeckoView is ~60 MB per architecture).
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64")
            isUniversalApk = true
        }
    }

    testOptions { unitTests.isReturnDefaultValues = true }
}

// (`android { kotlinOptions }` is an error since Kotlin 2.2; this form works from Kotlin 2.0 on)
kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }

dependencies {
    implementation(libs.geckoview)
    // Veil's own tor: native libtor + TorService (see docs/TOR.md). jtorctl is the control-port client TorService exposes.
    implementation(libs.tor.android)
    implementation(libs.jtorctl)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.animation)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    testImplementation(libs.junit)
}
