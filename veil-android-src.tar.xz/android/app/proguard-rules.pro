# GeckoView is called from native code and by reflection; its AAR carries consumer rules, these are a safety net.
-keep class org.mozilla.geckoview.** { *; }
-keep class org.mozilla.gecko.** { *; }
-keep class org.mozilla.thirdparty.** { *; }
-dontwarn org.mozilla.**
-dontwarn javax.annotation.**
# our own restart helper is started by name from the manifest
-keep class app.veil.browser.engine.RestartActivity { *; }
# tor-android: TorService calls into libtor through JNI and the library reads its own constants reflectively
-keep class org.torproject.jni.** { *; }
-keep class net.freehaven.tor.control.** { *; }
-dontwarn org.torproject.**
-dontwarn net.freehaven.**
