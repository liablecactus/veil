package app.veil.browser.core

import java.io.File
import java.net.ServerSocket
import java.nio.file.Files
import java.nio.file.attribute.PosixFilePermissions
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrefsTest {
    @Test fun configFileRendersTypedValues() {
        val y = GeckoConfigFile.render(mapOf("a.b" to true, "c.d" to 3, "e.f" to "it's", "a.a" to false))
        assertEquals(
            "# generated at every start – do not edit\nprefs:\n  a.a: false\n  a.b: true\n  c.d: 3\n  e.f: 'it''s'\n",
            y,
        )
    }

    @Test fun configFileRejectsUnsafeKeysAndTypes() {
        for (bad in listOf("a: b", "a\nb", "a b", "")) {
            try { GeckoConfigFile.render(mapOf(bad to true)); throw AssertionError("accepted $bad") } catch (_: IllegalArgumentException) {}
        }
        try { GeckoConfigFile.render(mapOf("a" to 1.5)); throw AssertionError("accepted double") } catch (_: IllegalArgumentException) {}
    }

    @Test fun baselineIsNonPersistentAndTorSwitchIsReversible() {
        val b = HardeningPrefs.baseline
        assertEquals(false, b["browser.cache.disk.enable"])
        assertEquals(false, b["places.history.enabled"])
        assertEquals(2, b["network.cookie.lifetimePolicy"])
        val on = HardeningPrefs.torOn()
        assertEquals(1, on["network.proxy.type"])
        assertEquals("127.0.0.1", on["network.proxy.socks"])
        assertEquals(9050, on["network.proxy.socks_port"])
        assertEquals(5, on["network.proxy.socks_version"])
        assertEquals(true, on["network.proxy.socks_remote_dns"])
        assertEquals(false, on["media.peerconnection.enabled"])   // UDP/WebRTC would bypass SOCKS
        // every pref that torOff touches is one that torOn touches as well (no stale leftovers)
        assertTrue(on.keys.containsAll(HardeningPrefs.torOff.keys))
        assertEquals(0, HardeningPrefs.torOff["network.proxy.type"])
        // the proxy switch flips last: type=1 without a SOCKS host would mean "direct" for a moment
        assertEquals("network.proxy.type", on.keys.last())
        assertEquals(false, on["geo.enabled"])
        // every value type is renderable
        GeckoConfigFile.render(b + on)
    }

    @Test fun endpointValidation() {
        assertTrue(HardeningPrefs.validTorEndpoint("127.0.0.1", 9050))
        assertTrue(HardeningPrefs.validTorEndpoint("localhost", 9150))
        assertTrue(HardeningPrefs.validTorEndpoint("127.1.2.3", 1))
        assertFalse(HardeningPrefs.validTorEndpoint("10.0.0.2", 9050))
        assertFalse(HardeningPrefs.validTorEndpoint("evil.example", 9050))
        assertFalse(HardeningPrefs.validTorEndpoint("127.300.0.1", 9050))
        assertFalse(HardeningPrefs.validTorEndpoint("127.0.0.1", 0))
        assertFalse(HardeningPrefs.validTorEndpoint("127.0.0.1", 70000))
    }
}

class AppSettingsTest {
    @Test fun roundTrip() {
        val s = AppSettings(
            theme = ThemeChoice.SYSTEM, secureWindow = false, httpsOnly = false, rememberSiteSettings = true,
            tor = TorSettings("127.0.0.1", 9150, true), panic = PanicSettings(clearClipboard = false, restartProcess = true),
            disabledExtensions = setOf("a@b.c", "{aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee}"),
        )
        assertEquals(s, AppSettings.fromJson(s.toJson()))
    }

    @Test fun hostileFileFallsBackToDefaults() {
        val d = AppSettings()
        assertEquals(d, AppSettings.fromJson(null))
        assertEquals(d, AppSettings.fromJson("}{"))
        val s = AppSettings.fromJson("""{"tor":{"host":"evil.example","port":9050},"searchEngine":"http://x/%s","theme":"neon","secureWindow":"yes"}""")
        assertEquals(d.tor, s.tor)                  // non-loopback proxy is refused
        assertEquals(d.searchEngine, s.searchEngine) // search engine must be https and contain %s
        assertEquals(d.theme, s.theme)
        assertTrue(s.secureWindow)
        assertEquals(setOf("ok@x.y"), AppSettings.fromJson("""{"disabledExtensions":["ok@x.y","../../evil",5]}""").disabledExtensions)
        assertEquals("https://s.example/?q=%s", AppSettings.fromJson("""{"searchEngine":"https://s.example/?q=%s"}""").searchEngine)
    }

    @Test fun secureByDefault() {
        val d = AppSettings()
        assertTrue(d.secureWindow)
        assertTrue(d.httpsOnly)
        assertFalse(d.rememberSiteSettings)
        assertFalse(d.tor.autoStart)
        assertTrue(d.panic.clearClipboard)
    }
}

private class FakePrefs(val log: MutableList<String>, var failOn: Int = -1) : PrefsGateway {
    var calls = 0
    val applied = ArrayList<Map<String, Any>>()
    override suspend fun apply(values: Map<String, Any>) {
        if (calls++ == failOn) throw IllegalStateException("gecko not ready")
        applied += values
        log += "prefs:" + (values["network.proxy.type"] ?: "?")
    }
}

private class FakeProbe(@Volatile var up: Boolean) : ProxyProbe {
    override suspend fun reachable(host: String, port: Int) = up
}

private class FakeIdentity(val log: MutableList<String>) : IdentityReset {
    override suspend fun reset() { log += "reset" }
}

class TorControllerTest {
    private fun scope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Test fun enableProbesFirstAndChangesNothingWithoutProxy() = runBlocking {
        val log = ArrayList<String>()
        val prefs = FakePrefs(log)
        val tor = TorController(prefs, FakeProbe(false), FakeIdentity(log), scope())
        val s = tor.enable()
        assertEquals(TorPhase.OFF, s.phase)
        assertFalse(s.want)
        assertEquals("unreachable", s.detail)
        assertTrue("no pref may change when the proxy is missing", log.isEmpty())
    }

    @Test fun enableSwitchesPrefsThenResetsSessions() = runBlocking {
        val log = ArrayList<String>()
        val tor = TorController(FakePrefs(log), FakeProbe(true), FakeIdentity(log), scope())
        val s = tor.enable()
        assertEquals(TorState(TorPhase.ON, true), s)
        assertEquals(listOf("prefs:1", "reset"), log)
        tor.shutdown()
    }

    @Test fun disableSwitchesBackAndResets() = runBlocking {
        val log = ArrayList<String>()
        val tor = TorController(FakePrefs(log), FakeProbe(true), FakeIdentity(log), scope())
        tor.enable()
        log.clear()
        val s = tor.disable()
        assertEquals(TorState(TorPhase.OFF, false), s)
        assertEquals(listOf("prefs:0", "reset"), log)
    }

    @Test fun watchdogFailsClosedAndRecovers() = runBlocking {
        val log = ArrayList<String>()
        val probe = FakeProbe(true)
        val prefs = FakePrefs(log)
        val tor = TorController(prefs, probe, FakeIdentity(log), scope(), watchdogMs = 20)
        tor.enable()
        val before = prefs.applied.size
        probe.up = false
        withTimeout(2_000) { while (tor.state.value.phase != TorPhase.UNREACHABLE) delay(5) }
        assertTrue("routing must stay wanted so nothing leaks", tor.state.value.want)
        assertEquals("prefs must not be touched when the proxy dies", before, prefs.applied.size)
        probe.up = true
        withTimeout(2_000) { while (tor.state.value.phase != TorPhase.ON) delay(5) }
        tor.shutdown()
    }

    @Test fun prefFailureLeavesRoutingWantedNotDirect() = runBlocking {
        val log = ArrayList<String>()
        val tor = TorController(FakePrefs(log, failOn = 0), FakeProbe(true), FakeIdentity(log), scope())
        val s = tor.enable()
        assertEquals(TorPhase.UNREACHABLE, s.phase)
        assertTrue(s.want)
        tor.shutdown()
    }

    @Test fun autostartAdoptsRoutedStart() = runBlocking {
        val log = ArrayList<String>()
        val probe = FakeProbe(false)
        val tor = TorController(FakePrefs(log), probe, FakeIdentity(log), scope(), watchdogMs = 20)
        assertEquals(TorPhase.UNREACHABLE, tor.adoptRoutedStart().phase)
        assertTrue(tor.wanted)
        probe.up = true
        withTimeout(2_000) { while (tor.state.value.phase != TorPhase.ON) delay(5) }
        assertEquals("the startup file is never trusted blindly: the prefs are written again at runtime", listOf("prefs:1"), log)
        assertTrue(tor.routingConfirmed)
        tor.shutdown()
    }

    @Test fun failedAutostartWriteIsRetriedByTheWatchdog() = runBlocking {
        val log = ArrayList<String>()
        val prefs = FakePrefs(log, failOn = 0)
        val tor = TorController(prefs, FakeProbe(true), FakeIdentity(log), scope(), watchdogMs = 20)
        val s = tor.adoptRoutedStart()
        assertEquals(TorPhase.UNREACHABLE, s.phase)
        assertFalse("must not claim routing it could not confirm", tor.routingConfirmed)
        withTimeout(2_000) { while (tor.state.value.phase != TorPhase.ON) delay(5) }
        assertTrue(tor.routingConfirmed)
        tor.shutdown()
    }

    @Test fun neverOnWhileThePrefWriteIsMissing() = runBlocking {
        val log = ArrayList<String>()
        val prefs = FakePrefs(log, failOn = 0)
        val tor = TorController(prefs, FakeProbe(true), FakeIdentity(log), scope(), watchdogMs = 20)
        val s = tor.enable()
        assertEquals(TorPhase.UNREACHABLE, s.phase)
        assertTrue(s.want)
        assertFalse(tor.routingConfirmed)
        assertTrue("open sessions are closed when the write fails", log.contains("reset"))
        withTimeout(2_000) { while (tor.state.value.phase != TorPhase.ON) delay(5) }
        assertTrue("the watchdog repeats the write before it says ON", tor.routingConfirmed)
        tor.shutdown()
    }

    @Test fun endpointChangeWhileRoutedRewritesThePrefs() = runBlocking {
        val log = ArrayList<String>()
        val prefs = FakePrefs(log)
        val tor = TorController(prefs, FakeProbe(true), FakeIdentity(log), scope(), watchdogMs = 5_000)
        tor.enable()
        tor.reconfigure("127.0.0.1", 9150)
        assertEquals(9150, prefs.applied.last()["network.proxy.socks_port"])
        tor.shutdown()
    }

    @Test fun endpointMustBeLoopback() {
        val tor = TorController(FakePrefs(ArrayList()), FakeProbe(true), FakeIdentity(ArrayList()), scope())
        try { tor.configure("10.0.0.1", 9050); throw AssertionError("accepted remote endpoint") } catch (_: IllegalArgumentException) {}
        tor.configure("127.0.0.1", 9150)
        assertEquals(9150, tor.port)
    }

    @Test fun socketProbeSpeaksSocks5() = runBlocking {
        // a fake SOCKS5 server answering the method negotiation
        val server = ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress())
        val t = Thread {
            repeat(1) {
                try {
                    server.accept().use { c ->
                        val b = ByteArray(3); var n = 0
                        while (n < 3) { val r = c.getInputStream().read(b, n, 3 - n); if (r < 0) break; n += r }
                        c.getOutputStream().apply { write(byteArrayOf(0x05, 0x00)); flush() }
                    }
                } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true; it.start() }
        val probe = SocketProxyProbe(timeoutMs = 800)
        assertTrue(probe.reachable("127.0.0.1", server.localPort))
        t.join(2_000)
        server.close()
        val freePort = ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress()).use { it.localPort }
        assertFalse("nothing listens on a freshly released port", probe.reachable("127.0.0.1", freePort))
        // something that is not SOCKS (HTTP-ish banner) must not count
        val http = ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress())
        val t2 = Thread { try { http.accept().use { it.getOutputStream().apply { write("HT".toByteArray()); flush() }; Thread.sleep(300) } } catch (_: Exception) {} }.also { it.isDaemon = true; it.start() }
        assertFalse(probe.reachable("127.0.0.1", http.localPort))
        http.close()
        t2.interrupt()
    }
}

private class FakeHost(val log: MutableList<String>) : PanicHost {
    var failAt: String? = null
    var hangEngine = false
    val gate = CompletableDeferred<Unit>()
    var gateOnClose = false

    private fun step(name: String) { log += name; if (failAt == name) throw IllegalStateException("boom $name") }
    override fun resetUiToBlank() = step("ui")
    override suspend fun closeAllSessions() { step("close"); if (gateOnClose) gate.await() }
    override suspend fun clearEngineData() { step("engine"); if (hangEngine) delay(60_000) }
    override fun wipeDisk() = step("disk")
    override fun clearClipboard() = step("clip")
    override suspend fun openBlankTab() = step("blank")
    override fun restartProcess() = step("restart")
}

class PanicCoordinatorTest {
    private fun scope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Test fun runsEverythingInOrder() = runBlocking {
        val log = ArrayList<String>()
        val p = PanicCoordinator(FakeHost(log), { PanicOptions(clearClipboard = true, restartProcess = false) }, scope())
        p.trigger().join()
        assertEquals(listOf("ui", "close", "engine", "disk", "clip", "blank"), log)
        assertTrue(p.lastReport.value!!.clean)
        assertFalse(p.running.value)
    }

    @Test fun uiIsBlankedSynchronouslyBeforeAnythingSlow() {
        val log = ArrayList<String>()
        val host = FakeHost(log).apply { gateOnClose = true }
        val p = PanicCoordinator(host, { PanicOptions() }, scope())
        val job = p.trigger()
        assertEquals("the instant part has run when trigger() returns", "ui", log.first())
        assertTrue(p.running.value)
        host.gate.complete(Unit)
        runBlocking { job.join() }
    }

    @Test fun failingStepDoesNotStopTheRest() = runBlocking {
        val log = ArrayList<String>()
        val host = FakeHost(log).apply { failAt = "close" }
        val p = PanicCoordinator(host, { PanicOptions(restartProcess = true) }, scope())
        p.trigger().join()
        assertEquals(listOf("ui", "close", "engine", "disk", "clip", "blank", "restart"), log)
        assertEquals(setOf(PanicStep.CLOSE_SESSIONS), p.lastReport.value!!.failed.keys)
    }

    @Test fun hungEngineClearTimesOutButWipeContinues() = runBlocking {
        val log = ArrayList<String>()
        val host = FakeHost(log).apply { hangEngine = true }
        val p = PanicCoordinator(host, { PanicOptions() }, scope(), engineDataTimeoutMs = 50)
        withTimeout(3_000) { p.trigger().join() }
        assertEquals("timeout", p.lastReport.value!!.failed[PanicStep.CLEAR_ENGINE_DATA])
        assertTrue(log.containsAll(listOf("disk", "clip", "blank")))
    }

    @Test fun reentrantTriggerReturnsRunningJob() {
        val log = ArrayList<String>()
        val host = FakeHost(log).apply { gateOnClose = true }
        val p = PanicCoordinator(host, { PanicOptions() }, scope())
        val a = p.trigger()
        val b = p.trigger()
        assertTrue(a === b)
        host.gate.complete(Unit)
        runBlocking { a.join() }
        assertEquals(1, log.count { it == "ui" })
    }

    @Test fun clipboardOptionIsHonoured() = runBlocking {
        val log = ArrayList<String>()
        PanicCoordinator(FakeHost(log), { PanicOptions(clearClipboard = false) }, scope()).trigger().join()
        assertFalse("clip" in log)
    }
}

class ProfileWiperTest {
    @Test fun removesContentsButNotRootsOrSymlinkTargets() {
        val base = Files.createTempDirectory("veil-wipe").toFile()
        try {
            val profile = File(base, "profile").apply { mkdirs() }
            File(profile, "a/b/c").mkdirs()
            File(profile, "a/b/c/cookies.sqlite").writeText("secret")
            File(profile, "prefs.js").writeText("x")
            File(profile, "keep.me").writeText("k")
            val outside = File(base, "outside").apply { mkdirs() }
            File(outside, "precious.txt").writeText("do not touch")
            Files.createSymbolicLink(File(profile, "link").toPath(), outside.toPath())
            val cache = File(base, "cache").apply { mkdirs() }
            File(cache, "x").writeText("y")

            val r = ProfileWiper.wipeContents(listOf(profile, cache, File(base, "missing")), keep = setOf("keep.me"))
            assertTrue(r.failed.isEmpty())
            assertTrue(profile.isDirectory && cache.isDirectory)
            assertEquals(listOf("keep.me"), profile.list()!!.toList())
            assertEquals(0, cache.list()!!.size)
            assertTrue("a symlink must be unlinked, never followed", File(outside, "precious.txt").exists())
        } finally {
            base.deleteRecursively()
        }
    }

    @Test fun readOnlyDirsAreReportedNotThrown() {
        val base = Files.createTempDirectory("veil-wipe-ro").toFile()
        try {
            val d = File(base, "d").apply { mkdirs() }
            File(d, "sub").mkdirs(); File(d, "sub/f").writeText("x")
            Files.setPosixFilePermissions(File(d, "sub").toPath(), PosixFilePermissions.fromString("r-xr-xr-x"))
            val r = ProfileWiper.wipeContents(listOf(d))
            // running as root the delete may succeed; either outcome must not throw
            assertTrue(r.deleted + r.failed.size >= 1)
            File(d, "sub").takeIf { it.exists() }?.let { Files.setPosixFilePermissions(it.toPath(), PosixFilePermissions.fromString("rwxr-xr-x")) }
        } finally {
            base.deleteRecursively()
        }
    }
}
