package app.veil.browser.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExtensionManifestTest {
    @Test fun convertedExtensionIsInstallable() {
        val i = ExtensionManifest.parse(
            """{"manifest_version":3,"name":"Hello","version":"1.2.3","permissions":["storage","tabs"],"host_permissions":["https://*/*"],
               "background":{"scripts":["bg.js"]},"browser_specific_settings":{"gecko":{"id":"hello@veil.local"}}}""",
        )!!
        assertEquals("hello@veil.local", i.id)
        assertTrue(i.installable)
        assertEquals(listOf("storage", "tabs"), i.permissions)
        assertEquals(listOf("https://*/*"), i.hostPermissions)
    }

    @Test fun chromeOnlyManifestIsFlaggedNotCrashing() {
        val i = ExtensionManifest.parse("""{"manifest_version":3,"name":"X","version":"1","background":{"service_worker":"sw.js"}}""")!!
        assertEquals(setOf(ExtensionProblem.NO_GECKO_ID, ExtensionProblem.SERVICE_WORKER_ONLY), i.problems.toSet())
        assertFalse(i.installable)
    }

    @Test fun serviceWorkerWithScriptsFallbackIsFine() {
        val i = ExtensionManifest.parse(
            """{"manifest_version":3,"name":"X","version":"1","background":{"service_worker":"sw.js","scripts":["sw.js"]},
               "applications":{"gecko":{"id":"{12345678-1234-1234-1234-123456789abc}"}}}""",
        )!!
        assertTrue(i.installable)
    }

    @Test fun localizedNames() {
        val i = ExtensionManifest.parse(
            """{"manifest_version":2,"name":"__MSG_extName__","version":"1","browser_specific_settings":{"gecko":{"id":"a@b.c"}}}""",
            """{"extName":{"message":"Mein Blocker"}}""",
        )!!
        assertEquals("Mein Blocker", i.name)
        assertEquals("extName", ExtensionManifest.parse("""{"manifest_version":2,"name":"__MSG_extName__","version":"1"}""")!!.name)
    }

    @Test fun hostileInputIsRejectedOrNeutralised() {
        assertNull(ExtensionManifest.parse("not json"))
        assertNull(ExtensionManifest.parse("""{"name":"x"}"""))
        assertNull(ExtensionManifest.parse("""{"manifest_version":3}"""))
        val bad = ExtensionManifest.parse("""{"manifest_version":3,"name":"x","version":"1","browser_specific_settings":{"gecko":{"id":"../../etc"}}}""")!!
        assertNull(bad.id)
        assertTrue(ExtensionProblem.NO_GECKO_ID in bad.problems)
        val v4 = ExtensionManifest.parse("""{"manifest_version":4,"name":"x","version":"1"}""")!!
        assertTrue(ExtensionProblem.UNSUPPORTED_MANIFEST_VERSION in v4.problems)
        assertNotNull(ExtensionManifest.parse("""{"manifest_version":3,"name":"${"n".repeat(500)}","version":"1"}"""))
        assertEquals(120, ExtensionManifest.parse("""{"manifest_version":3,"name":"${"n".repeat(500)}","version":"1"}""")!!.name.length)
    }

    @Test fun idShapes() {
        assertTrue(ExtensionManifest.validId("ublock@raymondhill.net"))
        assertTrue(ExtensionManifest.validId("{aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee}"))
        assertFalse(ExtensionManifest.validId("no-at-sign"))
        assertFalse(ExtensionManifest.validId("a@b/../c"))
    }
}
