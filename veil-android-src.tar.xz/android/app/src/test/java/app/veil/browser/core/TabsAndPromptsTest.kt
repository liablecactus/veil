package app.veil.browser.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TabsStateTest {
    private fun tabs(vararg ids: Long) = ids.fold(TabsState()) { s, id -> s.added(TabState(id)) }

    @Test fun addActivatesAndFirstTabAlwaysBecomesActive() {
        val s = TabsState().added(TabState(1), activate = false)
        assertEquals(1L, s.activeId)
        assertEquals(2L, s.added(TabState(2)).activeId)
        assertEquals(1L, s.added(TabState(2), activate = false).activeId)
    }

    @Test fun closingActiveSelectsParentThenNeighbourThenLast() {
        val s = TabsState().added(TabState(1)).added(TabState(2)).added(TabState(3, parentId = 1)).selected(3)
        assertEquals(1L, s.closed(3).activeId)                  // parent wins
        val noParent = tabs(1, 2, 3).selected(2)
        assertEquals(3L, noParent.closed(2).activeId)           // neighbour slides in
        assertEquals(2L, tabs(1, 2, 3).closed(3).activeId)      // last closed -> new last
        assertEquals(TabsState.NONE, tabs(1).closed(1).activeId)
        assertTrue(tabs(1).closed(1).tabs.isEmpty())
    }

    @Test fun closingOtherTabKeepsSelectionAndRelinksChildren() {
        val s = TabsState().added(TabState(1)).added(TabState(2, parentId = 1)).added(TabState(3, parentId = 2)).selected(3)
        val c = s.closed(2)
        assertEquals(3L, c.activeId)
        assertEquals(1L, c.tabs.first { it.id == 3L }.parentId)
        assertEquals(s, s.closed(99))
    }

    @Test fun updateIsNoOpWhenNothingChanges() {
        val s = tabs(1, 2)
        assertTrue(s === s.updated(1) { it })
        assertTrue(s === s.updated(9) { it.copy(title = "x") })
        assertEquals("x", s.updated(2) { it.copy(title = "x") }.tabs[1].title)
    }

    @Test fun moveClampsIndex() {
        assertEquals(listOf(2L, 3L, 1L), tabs(1, 2, 3).moved(1, 99).tabs.map { it.id })
        assertEquals(listOf(3L, 1L, 2L), tabs(1, 2, 3).moved(3, -5).tabs.map { it.id })
    }

    @Test fun derivedFlags() {
        assertTrue(TabState(1).isBlank)
        assertTrue(TabState(1, url = "http://abc.onion/x").isOnion)
        assertFalse(TabState(1, url = "https://example.com").isOnion)
        assertNull(TabState(1, url = "about:blank").host)
    }
}

class PromptBrokerTest {
    @Test fun cancelCompletesEngineSideExactlyOnce() {
        val b = PromptBroker()
        var cancelled = 0
        val id = b.nextId()
        b.post(UiPrompt.Alert(id, "a.example", "hi", done = {}, cancel = { cancelled++ }))
        b.cancel(id)
        b.cancel(id)
        assertEquals(1, cancelled)
        assertTrue(b.queue.value.isEmpty())
    }

    @Test fun cancelAllHitsEveryPromptAndSurvivesThrowingCallbacks() {
        val b = PromptBroker()
        var n = 0
        repeat(3) {
            b.post(UiPrompt.Confirm(b.nextId(), "o", "m", done = {}, cancel = { n++; if (it == 0) Unit }))
        }
        b.post(UiPrompt.Alert(b.nextId(), "o", "boom", done = {}, cancel = { throw IllegalStateException("x") }))
        b.post(UiPrompt.Alert(b.nextId(), "o", "after", done = {}, cancel = { n++ }))
        b.cancelAll()
        assertEquals(4, n)
        assertTrue(b.queue.value.isEmpty())
    }

    @Test fun resolveRemovesWithoutCancelling() {
        val b = PromptBroker()
        var cancelled = false
        val id = b.nextId()
        b.post(UiPrompt.Alert(id, "o", "m", done = {}, cancel = { cancelled = true }))
        b.resolve(id)
        assertFalse(cancelled)
        assertTrue(b.queue.value.isEmpty())
    }

    @Test fun cancelWhereOnlyTouchesMatching() {
        val b = PromptBroker()
        val hits = ArrayList<String>()
        b.post(UiPrompt.Alert(b.nextId(), "a.example", "1", done = {}, cancel = { hits += "a" }))
        b.post(UiPrompt.Alert(b.nextId(), "b.example", "2", done = {}, cancel = { hits += "b" }))
        b.cancelWhere { it.origin == "a.example" }
        assertEquals(listOf("a"), hits)
        assertEquals(1, b.queue.value.size)
    }
}

class ErrorPageTest {
    @Test fun escapesEverythingFromTheUrl() {
        val html = ErrorPage.html("https://\"><script>alert(1)</script>.example/", torActive = false, torPort = 9050, lang = "en")
        assertFalse(html.contains("<script>alert"))
        val raw = ErrorPage.html("javascript:alert('x')<b>", torActive = false, torPort = 9050, lang = "en")
        assertFalse(raw.contains("<b>"))
        assertTrue(raw.contains("&lt;b&gt;"))
    }

    @Test fun torHintOnlyWhenTorIsActiveAndLanguageSwitches() {
        assertTrue(ErrorPage.html("https://a.example", true, 9150, "de-DE").contains("Orbot"))
        assertTrue(ErrorPage.html("https://a.example", true, 9150, "de-DE").contains("9150"))
        assertFalse(ErrorPage.html("https://a.example", false, 9050, "en").contains("Orbot"))
        assertTrue(ErrorPage.html("https://a.example", false, 9050, "de").contains("nicht erreichbar"))
        assertTrue(ErrorPage.html("https://a.example", false, 9050, "fr").contains("can’t be reached"))
    }

    @Test fun embeddedTorDoesNotSendYouToOrbotAndShowsTheEngineError() {
        val html = ErrorPage.html("http://x.onion/", true, 40339, "de", embedded = true, detail = "ERROR_NET_TIMEOUT · ERROR_CATEGORY_NETWORK")
        assertFalse(html.contains("Orbot"))
        assertTrue(html.contains("40339"))
        assertTrue(html.contains("eingebaut"))
        assertTrue(html.contains("ERROR_NET_TIMEOUT"))
        val evil = ErrorPage.html("http://x.onion/", true, 1, "en", embedded = true, detail = "<script>alert(1)</script>")
        assertFalse(evil.contains("<script>alert"))
    }

    @Test fun pageCannotLoadAnything() {
        assertTrue(ErrorPage.html("https://a.example", false, 9050, "en").contains("default-src 'none'"))
    }
}
