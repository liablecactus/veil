package app.veil.browser.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OmniboxTest {
    private fun url(raw: String) = Omnibox.resolve(raw)

    @Test fun blankInput() {
        assertEquals(OmniboxResult.Blank, url(""))
        assertEquals(OmniboxResult.Blank, url("  about:blank "))
    }

    @Test fun domainsGetHttps() {
        assertEquals(OmniboxResult.Navigate("https://example.com"), url("example.com"))
        assertEquals(OmniboxResult.Navigate("https://example.com/a?b=1"), url("example.com/a?b=1"))
        assertEquals(OmniboxResult.Navigate("https://bücher.de"), url("bücher.de"))
    }

    @Test fun onionIsHttp() {
        assertEquals(OmniboxResult.Navigate("http://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion"),
            url("duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion"))
    }

    @Test fun localAddresses() {
        assertEquals(OmniboxResult.Navigate("http://localhost:8080"), url("localhost:8080"))
        assertEquals(OmniboxResult.Navigate("http://192.168.0.1/x"), url("192.168.0.1/x"))
        assertEquals(OmniboxResult.Navigate("http://[::1]:3000"), url("[::1]:3000"))
    }

    @Test fun explicitHttpSchemesPass() {
        assertEquals(OmniboxResult.Navigate("https://a.example/x"), url("https://a.example/x"))
        assertEquals(OmniboxResult.Navigate("http://a.example"), url("HTTP://a.example".replaceFirst("HTTP", "http")))
    }

    @Test fun dangerousSchemesAreSearches() {
        for (bad in listOf("javascript:alert(1)", "data:text/html,<b>x", "file:///etc/passwd", "view-source:https://x.y", "about:config",
            "intent://scan/#Intent;scheme=zxing;end", "ftp://example.com/a", "moz-extension://abc/page.html", "resource://gre/x")) {
            val r = url(bad)
            assertTrue("$bad -> $r", r is OmniboxResult.Search)
            assertTrue(r.url.startsWith("https://duckduckgo.com/?q="))
        }
    }

    @Test fun plainTextIsSearch() {
        assertEquals(OmniboxResult.Search("https://duckduckgo.com/?q=hello%20world%20%26%20more"), url("hello world & more"))
        assertEquals(OmniboxResult.Search("https://duckduckgo.com/?q=localhost%20tips"), url("localhost tips"))
    }

    @Test fun customTemplateAndFallback() {
        assertEquals("https://s.example/?q=a%20b", Omnibox.searchUrl("https://s.example/?q=%s", "a b"))
        assertEquals("https://duckduckgo.com/?q=a", Omnibox.searchUrl("https://no-placeholder.example", "a"))
    }

    @Test fun hostOf() {
        assertEquals("example.com", Omnibox.hostOf("https://User@Example.com:8443/path?q#f"))
        assertEquals("::1", Omnibox.hostOf("http://[::1]:3000/"))
        assertEquals("evil.com", Omnibox.hostOf("https://evil.com\\@good.com/"))   // "\\" ends the authority
        assertNull(Omnibox.hostOf("about:blank"))
        assertNull(Omnibox.hostOf("file:///x"))
        assertTrue(Omnibox.isOnionHost("abc.onion."))
        assertFalse(Omnibox.isOnionHost("onion.example"))
    }
}

class SiteRulesTest {
    @Test fun defaultsAreConservative() {
        val d = SiteRules()
        assertEquals(Setting.BLOCK, d.popups)
        assertEquals(Setting.BLOCK, d.thirdPartyCookies)
        assertEquals(Setting.BLOCK, d.notifications)
        assertEquals(Setting.ASK, d.camera)
        assertEquals(Setting.ASK, d.microphone)
        assertEquals(Setting.ALLOW, d.javascript)
    }

    @Test fun precedenceExactThenLongestSuffix() {
        val data = SiteRuleData()
            .withOverride("[*.]example.com", RuleKey.JAVASCRIPT, Setting.BLOCK)
            .withOverride("[*.]shop.example.com", RuleKey.JAVASCRIPT, Setting.ALLOW)
            .withOverride("a.shop.example.com", RuleKey.JAVASCRIPT, Setting.BLOCK)
        assertEquals(Setting.BLOCK, data.resolve("example.com").javascript)
        assertEquals(Setting.BLOCK, data.resolve("www.example.com").javascript)
        assertEquals(Setting.ALLOW, data.resolve("shop.example.com").javascript)
        assertEquals(Setting.ALLOW, data.resolve("b.shop.example.com").javascript)
        assertEquals(Setting.BLOCK, data.resolve("a.shop.example.com").javascript)
        assertEquals(Setting.ALLOW, data.resolve("other.org").javascript)
        assertEquals(Setting.ALLOW, data.resolve(null).javascript)
    }

    @Test fun invalidValuesAreRejected() {
        val d = SiteRuleData()
        try { d.withDefault(RuleKey.JAVASCRIPT, Setting.ASK); throw AssertionError("expected failure") } catch (_: IllegalArgumentException) {}
        try { d.withOverride("example.com", RuleKey.THIRD_PARTY_COOKIES, Setting.ALLOW); throw AssertionError("expected failure") } catch (_: IllegalArgumentException) {}
        try { d.withOverride("", RuleKey.CAMERA, Setting.ALLOW); throw AssertionError("expected failure") } catch (_: IllegalArgumentException) {}
    }

    @Test fun patternNormalisation() {
        assertEquals("example.com", normalizePattern(" HTTPS://Example.com:443/a?b "))
        assertEquals("[*.]example.com", normalizePattern("*.example.com"))
        assertEquals("[*.]xn--bcher-kva.de", normalizePattern("[*.]bücher.de"))
        assertNull(normalizePattern("a..b"))
        assertNull(normalizePattern(""))
        assertNull(normalizePattern(".example.com"))
    }

    @Test fun clearAndExplain() {
        var d = SiteRuleData().withOverride("example.com", RuleKey.CAMERA, Setting.ALLOW).withOverride("example.com", RuleKey.GEOLOCATION, Setting.BLOCK)
        assertEquals(Setting.ALLOW to "example.com", d.explain("example.com", RuleKey.CAMERA))
        assertEquals(Setting.ASK to "default", d.explain("example.com", RuleKey.MICROPHONE))
        d = d.cleared("example.com", RuleKey.CAMERA)
        assertEquals(Setting.ASK, d.resolve("example.com").camera)
        assertEquals(Setting.BLOCK, d.resolve("example.com").geolocation)
        d = d.cleared("example.com")
        assertTrue(d.overrides.isEmpty())
    }

    @Test fun jsonRoundTripAndLenientLoad() {
        val d = SiteRuleData()
            .withDefault(RuleKey.POPUPS, Setting.ALLOW)
            .withOverride("[*.]example.com", RuleKey.MICROPHONE, Setting.BLOCK)
        assertEquals(d, SiteRuleData.fromJson(d.toJson()))

        val hostile = """{"defaults":{"javascript":"ask","camera":"maybe","popups":"allow","evil":"allow"},
            "overrides":{"example.com":{"camera":"allow","thirdPartyCookies":"allow","javascript":"nope"},"..":{"camera":"allow"},"x.y":"str"}}"""
        val l = SiteRuleData.fromJson(hostile)
        assertEquals(Setting.ALLOW, l.defaults.javascript)        // "ask" invalid for javascript -> default stays
        assertEquals(Setting.ASK, l.defaults.camera)              // "maybe" invalid
        assertEquals(Setting.ALLOW, l.defaults.popups)
        assertEquals(mapOf(RuleKey.CAMERA to Setting.ALLOW), l.overrides["example.com"])
        assertEquals(1, l.overrides.size)
        assertEquals(SiteRuleData(), SiteRuleData.fromJson("not json"))
        assertEquals(SiteRuleData(), SiteRuleData.fromJson(null))
    }

    @Test fun storePersistsOnEveryChange() {
        val writes = ArrayList<String>()
        val store = SiteRuleStore(persist = { writes += it })
        store.setOverride("example.com", RuleKey.CAMERA, Setting.ALLOW)
        store.setDefault(RuleKey.POPUPS, Setting.ALLOW)
        store.clear("example.com")
        assertEquals(3, writes.size)
        assertNotNull(store.resolve("example.com"))
        assertEquals(Setting.ALLOW, store.resolve("example.com").popups)
        assertEquals(Setting.ASK, store.resolve("example.com").camera)
    }
}

class PermissionPolicyTest {
    @Test fun contentKinds() {
        val r = SiteRules()
        assertEquals(Decision.ASK, PermissionPolicy.decideContent(r, ContentKind.GEOLOCATION))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideContent(r, ContentKind.NOTIFICATIONS))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideContent(r, ContentKind.STORAGE_ACCESS))
        assertEquals(Decision.ALLOW, PermissionPolicy.decideContent(r.copy(thirdPartyCookies = Setting.ALLOW), ContentKind.STORAGE_ACCESS))
        assertEquals(Decision.ALLOW, PermissionPolicy.decideContent(r, ContentKind.AUTOPLAY_INAUDIBLE))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideContent(r, ContentKind.AUTOPLAY_AUDIBLE))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideContent(r, ContentKind.OTHER))
    }

    @Test fun mediaCombination() {
        val r = SiteRules(camera = Setting.ALLOW, microphone = Setting.BLOCK)
        assertEquals(Decision.ALLOW, PermissionPolicy.decideMedia(r, wantsVideo = true, wantsAudio = false))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideMedia(r, wantsVideo = true, wantsAudio = true))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideMedia(r, wantsVideo = false, wantsAudio = true))
        assertEquals(Decision.ASK, PermissionPolicy.decideMedia(SiteRules(), wantsVideo = true, wantsAudio = true))
        assertEquals(Decision.BLOCK, PermissionPolicy.decideMedia(SiteRules(), wantsVideo = false, wantsAudio = false))
        assertEquals(listOf(RuleKey.CAMERA, RuleKey.MICROPHONE), PermissionPolicy.keysForMedia(true, true))
    }
}
