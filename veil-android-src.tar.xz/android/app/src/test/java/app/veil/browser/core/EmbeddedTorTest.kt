package app.veil.browser.core

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Records every pref write as `type:port` (the proxy type is what decides between "direct" and "through the proxy"). */
private class RtPrefs(val log: MutableList<String>) : PrefsGateway {
    val applied = ArrayList<Map<String, Any>>()
    override suspend fun apply(values: Map<String, Any>) {
        applied += values
        log += "prefs:${values["network.proxy.type"] ?: "?"}:${values["network.proxy.socks_port"] ?: "-"}"
    }
}

private class RtProbe(@Volatile var up: Boolean = true) : ProxyProbe {
    override suspend fun reachable(host: String, port: Int) = up
}

private class RtIdentity(val log: MutableList<String>) : IdentityReset {
    override suspend fun reset() { log += "reset" }
}

private class FakeRuntime(val log: MutableList<String>, override var available: Boolean = true) : TorRuntime {
    var starts = 0
    var stops = 0
    var newnyms = 0
    var nextPort = 41000
    var steps: List<Int> = emptyList()
    var failWith: TorRuntimeException? = null

    /** How many of the next starts fail ([Int.MAX_VALUE] = all of them). */
    var failTimes = 0
    var gate: CompletableDeferred<Unit>? = null
    @Volatile private var stopSignal = CompletableDeferred<Unit>()
    @Volatile var exit: ((String?) -> Unit)? = null

    override suspend fun start(onProgress: (TorProgress) -> Unit): TorEndpoint {
        starts++
        log += "rt:start"
        val myStop = CompletableDeferred<Unit>().also { stopSignal = it }
        for (p in steps) onProgress(TorProgress(p, "t$p", "step $p"))
        gate?.let { g ->
            // like the real runtime: stop() while it waits for the bootstrap ends the start with ABORTED
            select<Unit> {
                g.onAwait { }
                myStop.onAwait { throw TorRuntimeException(TorRuntimeException.Code.ABORTED) }
            }
        }
        if (failTimes > 0) {
            if (failTimes != Int.MAX_VALUE) failTimes--
            throw failWith!!
        }
        return TorEndpoint("127.0.0.1", nextPort++)
    }

    override suspend fun stop() {
        stops++
        log += "rt:stop"
        stopSignal.complete(Unit)
    }

    override suspend fun newCircuits() { newnyms++; log += "rt:newnym" }
    override fun setOnExit(callback: ((String?) -> Unit)?) { exit = callback }
}

class EmbeddedTorTest {
    private fun scope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private fun controller(
        log: MutableList<String>, rt: FakeRuntime?, prefs: RtPrefs = RtPrefs(log), probe: RtProbe = RtProbe(),
        watchdogMs: Long = 5_000,
    ) = TorController(
        prefs, probe, RtIdentity(log), scope(), watchdogMs = watchdogMs, runtime = rt, mode = TorMode.EMBEDDED,
        recoveryDelaysMs = listOf(20L, 20L, 20L),
    )

    private suspend fun until(timeoutMs: Long = 3_000, cond: () -> Boolean) = withTimeout(timeoutMs) { while (!cond()) delay(5) }

    // ------------------------------------------------------------------------------------------- pure helpers

    @Test fun bootstrapLinesAreParsedStrictly() {
        val p = TorBootstrap.parseProgress("NOTICE BOOTSTRAP PROGRESS=40 TAG=loading_descriptors SUMMARY=\"Loading relay descriptors\"")
        assertEquals(TorProgress(40, "loading_descriptors", "Loading relay descriptors"), p)
        assertEquals(100, TorBootstrap.parseProgress("BOOTSTRAP PROGRESS=100 TAG=done SUMMARY=\"Done\"")?.percent)
        assertNull(TorBootstrap.parseProgress(null))
        assertNull(TorBootstrap.parseProgress("NOTICE CIRCUIT_ESTABLISHED"))
        assertNull(TorBootstrap.parseProgress("BOOTSTRAP PROGRESS=900 TAG=x"))
        assertNull(TorBootstrap.parseProgress("BOOTSTRAP TAG=x"))
        assertNull(TorBootstrap.parseProgress("BOOTSTRAP PROGRESS=1 " + "x".repeat(3000)))
    }

    @Test fun onlyLoopbackListenersAreAccepted() {
        assertEquals(9050, TorBootstrap.firstLoopbackPort("\"127.0.0.1:9050\""))
        assertEquals(41234, TorBootstrap.firstLoopbackPort("\"127.0.0.1:41234\" \"[::1]:41234\""))
        assertEquals(5, TorBootstrap.firstLoopbackPort("\"[::1]:5\""))
        assertNull(TorBootstrap.firstLoopbackPort("\"0.0.0.0:9050\""))
        assertNull(TorBootstrap.firstLoopbackPort("\"192.168.1.5:9050\""))
        assertNull(TorBootstrap.firstLoopbackPort("\"unix:/x/y\""))
        assertNull(TorBootstrap.firstLoopbackPort("\"127.0.0.1:0\""))
        assertNull(TorBootstrap.firstLoopbackPort("\"127.0.0.1:70000\""))
        assertNull(TorBootstrap.firstLoopbackPort(""))
        assertNull(TorBootstrap.firstLoopbackPort(null))
    }

    @Test fun torrcOverridesTheLibraryDefaultsAndTakesNoInput() {
        val rc = TorBootstrap.torrc()
        val lines = rc.lines().filter { it.isNotBlank() && !it.startsWith("#") }
        assertTrue("SocksPort auto" in lines)       // OS-chosen port instead of the library's 9050
        assertTrue("HTTPTunnelPort 0" in lines)     // no second proxy listener
        assertTrue("ClientOnly 1" in lines)
        assertTrue("AvoidDiskWrites 1" in lines)
        assertFalse("no relay/bridge/control options", lines.any { Regex("^(ORPort|ControlPort|Bridge|UseBridges|ExitRelay|DirPort|SocksPort 0\\.0\\.0\\.0)").containsMatchIn(it) })
        assertFalse("0.0.0.0" in rc)
    }

    @Test fun detailTokens() {
        assertEquals("engine-failed", torDetailToken("engine-failed: libtor.so not found"))
        assertEquals("bootstrap-timeout", torDetailToken("bootstrap-timeout: stuck at 40%"))
        assertEquals("engine-missing", torDetailToken("engine-missing"))
        assertNull(torDetailToken(null))
        assertNull(torDetailToken("Some Sentence Here: yes"))
    }

    @Test fun settingsKeepTheEngineChoiceAndDefaultToEmbedded() {
        assertEquals(TorMode.EMBEDDED, AppSettings().tor.mode)
        val s = AppSettings(tor = TorSettings("127.0.0.1", 9150, true, TorMode.EXTERNAL))
        assertEquals(TorMode.EXTERNAL, AppSettings.fromJson(s.toJson()).tor.mode)
        assertEquals(TorMode.EMBEDDED, AppSettings.fromJson("""{"tor":{"mode":"carrier-pigeon"}}""").tor.mode)
        assertEquals(TorMode.EMBEDDED, AppSettings.fromJson("""{"tor":{"host":"127.0.0.1","port":9050}}""").tor.mode)
        assertEquals(TorMode.EXTERNAL, AppSettings.fromJson("""{"tor":{"mode":"EXTERNAL"}}""").tor.mode)
    }

    // --------------------------------------------------------------------------------------------- controller

    @Test fun enableStartsTorFirstAndOnlyThenSwitchesTheEngine() = runBlocking {
        val log = ArrayList<String>()
        val gate = CompletableDeferred<Unit>()
        val rt = FakeRuntime(log).also { it.steps = listOf(10, 60); it.gate = gate }
        val tor = controller(log, rt)
        val on = scope().async { tor.enable() }
        until { tor.state.value.progress == 60 }
        // while tor boots: progress is visible, traffic is not routed (the engine keeps its current path) and nothing was touched
        assertEquals(TorPhase.CONNECTING, tor.state.value.phase)
        assertEquals("t60", tor.state.value.bootTag)
        assertFalse(tor.wanted)
        assertEquals(listOf("rt:start"), log)
        gate.complete(Unit)
        val s = withTimeout(3_000) { on.await() }
        assertEquals(TorPhase.ON, s.phase)
        assertTrue(s.want)
        assertNull(s.progress)
        assertEquals(41000, tor.port)
        // prefs (proxy on, the real port) only after tor is up, then the session reset
        assertEquals(listOf("rt:start", "prefs:1:41000", "reset"), log)
        assertTrue(tor.routingConfirmed)
        tor.shutdown()
    }

    @Test fun failedStartChangesNothingAndSaysWhy() = runBlocking {
        for ((code, token) in listOf(
            TorRuntimeException.Code.TIMEOUT to "bootstrap-timeout",
            TorRuntimeException.Code.START_FAILED to "engine-failed",
            TorRuntimeException.Code.NOT_AVAILABLE to "engine-missing",
        )) {
            val log = ArrayList<String>()
            val rt = FakeRuntime(log).also { it.failTimes = 1; it.failWith = TorRuntimeException(code, "boom") }
            val tor = controller(log, rt)
            val s = tor.enable()
            assertEquals(TorPhase.OFF, s.phase)
            assertFalse(s.want)
            assertEquals(token, torDetailToken(s.detail))
            assertTrue("no pref and no reset when tor did not start: $log", log.none { it.startsWith("prefs") || it == "reset" })
            assertTrue("tor is stopped again", log.contains("rt:stop"))
        }
    }

    @Test fun missingLibraryOrRuntimeIsReported() = runBlocking {
        val log = ArrayList<String>()
        assertEquals("engine-missing", controller(log, FakeRuntime(log, available = false)).enable().detail)
        assertEquals("engine-missing", controller(log, null).enable().detail)
        assertTrue(log.none { it.startsWith("prefs") })
    }

    @Test fun aProxyThatDoesNotAnswerIsNeverRoutedTo() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt, probe = RtProbe(false))
        val s = tor.enable()
        assertEquals(TorPhase.OFF, s.phase)
        assertEquals("engine-failed", torDetailToken(s.detail))
        assertTrue(log.none { it.startsWith("prefs") })
        assertTrue(log.contains("rt:stop"))
    }

    @Test fun switchingOffMidStartAbortsAndLeavesTheEngineAlone() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log).also { it.gate = CompletableDeferred() }
        val tor = controller(log, rt)
        val on = scope().async { tor.enable() }
        until { tor.state.value.phase == TorPhase.CONNECTING && rt.starts == 1 }
        assertFalse("a manual start does not route anything before tor is ready", tor.wanted)
        val off = withTimeout(3_000) { tor.disable() }
        assertEquals(TorPhase.OFF, off.phase)
        assertEquals(TorPhase.OFF, withTimeout(3_000) { on.await() }.phase)
        assertTrue(log.none { it == "prefs:1:41000" || it == "reset" })
        assertTrue(rt.stops >= 1)
    }

    @Test fun disableSwitchesTheEngineBackBeforeStoppingTor() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt)
        tor.enable()
        log.clear()
        val s = tor.disable()
        assertEquals(TorPhase.OFF, s.phase)
        assertEquals(listOf("prefs:0:0", "reset", "rt:stop"), log)
        // and it can be switched on again (new start, new port)
        tor.enable()
        assertEquals(41001, tor.port)
        tor.shutdown()
    }

    @Test fun autostartBlocksFirstThenPointsAtTor() = runBlocking {
        val log = ArrayList<String>()
        val gate = CompletableDeferred<Unit>()
        val rt = FakeRuntime(log).also { it.gate = gate }
        val tor = controller(log, rt)
        val s = withTimeout(3_000) { tor.adoptRoutedStart() }
        // returns once everything is blocked; tor boots in the background and does not hold the caller up
        assertEquals(TorPhase.CONNECTING, s.phase)
        assertEquals("prefs:1:${HardeningPrefs.TOR_BLOCKED_PORT}", log.first())
        assertTrue(tor.wanted)
        until { log.contains("rt:start") }
        assertEquals(TorPhase.CONNECTING, tor.state.value.phase)
        gate.complete(Unit)
        until { tor.state.value.phase == TorPhase.ON }
        assertEquals("prefs:1:41000", log.last { it.startsWith("prefs") })
        assertTrue("never direct", log.none { it.startsWith("prefs:0") })
        tor.shutdown()
    }

    @Test fun autostartThatNeverComesUpStaysBlockedAndKeepsTrying() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log).also { it.failWith = TorRuntimeException(TorRuntimeException.Code.START_FAILED, "no"); it.failTimes = Int.MAX_VALUE }
        val tor = controller(log, rt)
        tor.adoptRoutedStart()
        assertTrue(tor.wanted)
        until { rt.starts >= 4 } // 1 + three recovery attempts
        until { tor.state.value.phase == TorPhase.UNREACHABLE }
        assertEquals("engine-failed", torDetailToken(tor.state.value.detail))
        assertTrue("never switched to direct or to a real port: $log", log.filter { it.startsWith("prefs") }.all { it == "prefs:1:${HardeningPrefs.TOR_BLOCKED_PORT}" })
        tor.shutdown()
    }

    @Test fun switchingOffDuringAnAutostartBootAbortsIt() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log).also { it.gate = CompletableDeferred() }
        val tor = controller(log, rt)
        tor.adoptRoutedStart()
        until { rt.starts == 1 }
        val off = withTimeout(3_000) { tor.disable() }
        assertEquals(TorPhase.OFF, off.phase)
        assertFalse(tor.wanted)
        assertEquals("prefs:0:0", log.last { it.startsWith("prefs") })
        delay(100)
        assertEquals("no restart after the user switched off", 1, rt.starts)
        assertTrue(rt.stops >= 1)
    }

    @Test fun switchingOffBeforeTheBackgroundBootStartsKeepsTorOff() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt)
        tor.adoptRoutedStart()
        tor.disable() // may win the lock before the background start does
        delay(150)
        assertFalse(tor.wanted)
        assertEquals(TorPhase.OFF, tor.state.value.phase)
        assertTrue("whatever started was stopped again", rt.starts == rt.stops || rt.starts == 0)
    }

    @Test fun aDyingTorBlocksTheEngineAndIsRestartedOnANewPort() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt)
        tor.enable()
        assertEquals(41000, tor.port)
        log.clear()
        rt.exit!!.invoke("tor stopped")
        until { log.contains("prefs:1:${HardeningPrefs.TOR_BLOCKED_PORT}") }
        assertTrue("fail closed: still wanted", tor.wanted)
        until { tor.state.value.phase == TorPhase.ON }
        assertEquals(41001, tor.port)
        assertEquals("prefs:1:41001", log.last { it.startsWith("prefs") })
        assertTrue("blocked port first, then the new one, never direct", log.filter { it.startsWith("prefs") } == listOf("prefs:1:${HardeningPrefs.TOR_BLOCKED_PORT}", "prefs:1:41001"))
        tor.shutdown()
    }

    @Test fun theWatchdogBlocksAnEmbeddedProxyThatStopsAnswering() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val probe = RtProbe(true)
        val tor = controller(log, rt, probe = probe, watchdogMs = 20)
        tor.enable()
        log.clear()
        probe.up = false
        until { log.contains("prefs:1:${HardeningPrefs.TOR_BLOCKED_PORT}") }
        probe.up = true
        until { tor.state.value.phase == TorPhase.ON && tor.port > 41000 }
        tor.shutdown()
    }

    @Test fun ourOwnStopIsNotTreatedAsACrash() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt)
        tor.enable()
        tor.disable()
        assertNull("exit callback is unregistered before tor is stopped", rt.exit)
        delay(100)
        assertEquals(1, rt.starts)
    }

    @Test fun newIdentityRequestsCircuitsThenDropsTheSessions() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val tor = controller(log, rt)
        assertFalse("nothing to do while tor is off", tor.newIdentity())
        tor.enable()
        log.clear()
        assertTrue(tor.newIdentity())
        assertEquals(listOf("rt:newnym", "reset"), log)
        tor.shutdown()
    }

    @Test fun endpointSettingsDoNotApplyToTheEmbeddedTor() = runBlocking {
        val log = ArrayList<String>()
        val rt = FakeRuntime(log)
        val prefs = RtPrefs(log)
        val tor = controller(log, rt, prefs)
        tor.enable()
        val before = prefs.applied.size
        tor.reconfigure("127.0.0.1", 9150)
        assertEquals(before, prefs.applied.size)
        assertEquals(41000, tor.port)
        tor.shutdown()
    }
}
