# Bundled extensions

Every sub-folder here is installed as a **built-in extension** at app start (no signature needed – it ships inside the
APK) and is switched on for private tabs. The folder must contain a `manifest.json` with
`browser_specific_settings.gecko.id`.

Chrome Web Store packages are not directly usable (GeckoView requires signed add-ons at runtime and Gecko runs MV3
background code as an event page, not a service worker). Convert them first:

```sh
node tools/crx2gecko.mjs path/to/extension.crx          # or an unpacked folder
```

The tool verifies the CRX3 signature, adds the Gecko id, turns `background.service_worker` into
`background.scripts`, removes `update_url`/`key`, and lists Chrome-only APIs that will not work. Then rebuild the app.
Folders that cannot be installed are listed with the reason under *Settings → Extensions*.
