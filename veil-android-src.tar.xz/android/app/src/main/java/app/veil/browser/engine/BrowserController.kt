package app.veil.browser.engine

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import app.veil.browser.core.AppSettings
import app.veil.browser.core.BLANK_URL
import app.veil.browser.core.FilePickRequest
import app.veil.browser.core.HardeningPrefs
import app.veil.browser.core.IdentityReset
import app.veil.browser.core.Omnibox
import app.veil.browser.core.OmniboxResult
import app.veil.browser.core.PanicCoordinator
import app.veil.browser.core.PanicHost
import app.veil.browser.core.PanicOptions
import app.veil.browser.core.ProfileWiper
import app.veil.browser.core.PromptBroker
import app.veil.browser.core.RuleKey
import app.veil.browser.core.Setting
import app.veil.browser.core.SettingsStore
import app.veil.browser.core.SiteRuleData
import app.veil.browser.core.SiteRuleStore
import app.veil.browser.core.SiteRules
import app.veil.browser.core.SocketProxyProbe
import app.veil.browser.core.TabState
import app.veil.browser.core.TabsState
import app.veil.browser.core.TorController
import app.veil.browser.core.TorMode
import app.veil.browser.core.TorPhase
import app.veil.browser.core.TorState
import app.veil.browser.core.UiMessage
import app.veil.browser.extensions.ExtensionManager
import java.io.File
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession

/** Where the app keeps its own (non-browsing) files. Never inside the engine profile, which is wiped. */
class AppFiles(private val app: Application) {
    val configDir: File get() = File(app.noBackupFilesDir, "veil").also { it.mkdirs() }
    val settingsFile: File get() = File(configDir, "settings.json")
    val siteRulesFile: File get() = File(configDir, "site-rules.json")
    val geckoConfig: File get() = File(configDir, "gecko-startup.yaml")

    /** What gets deleted at every start (before the engine exists) and on panic where safe. */
    fun profileRoots(): List<File> = listOf(app.filesDir, app.cacheDir)

    fun readOrNull(f: File): String? = try { if (f.isFile && f.length() < 1_000_000) f.readText() else null } catch (_: Exception) { null }
}

/**
 * The browser's single composition root on Android: owns the engine objects and exposes plain flows to the UI.
 * Lives as long as the process (see [app.veil.browser.VeilApplication]), so rotating the screen or recreating the
 * activity never touches tabs or sessions.
 */
class BrowserController(
    private val app: Application,
    override val runtime: GeckoRuntime,
    val settingsStore: SettingsStore,
    private val siteStore: SiteRuleStore,
    private val files: AppFiles,
) : TabEnv {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override val appContext: Context get() = app
    override val prompts = PromptBroker()
    override val language: String get() = Locale.getDefault().language
    override val torPort: Int get() = tor.port

    // ----------------------------------------------------------------------------------------- observable state

    val settings: StateFlow<AppSettings> = settingsStore.state
    val siteRules: StateFlow<SiteRuleData> = siteStore.state

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8, onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    private val _fileRequests = MutableSharedFlow<FilePickRequest>(extraBufferCapacity = 1)
    val fileRequests: SharedFlow<FilePickRequest> = _fileRequests.asSharedFlow()

    private val _fullscreen = MutableStateFlow(false)
    val fullscreen: StateFlow<Boolean> = _fullscreen.asStateFlow()

    /** Set by the activity while it exists: asks Android for runtime permissions (camera, microphone, location). */
    @Volatile var permissionRequester: ((List<String>, (Boolean) -> Unit) -> Unit)? = null

    // ---------------------------------------------------------------------------------------------- engine parts

    private val storage = GeckoStorageGateway(runtime)

    val tabManager = TabManager(env = { this }, newSession = { EngineHost.newSession(settingsStore.current.strictTrackingProtection) })
    val tabs: StateFlow<TabsState> = tabManager.state
    val thumbnails = tabManager.thumbnails

    private val identity = object : IdentityReset {
        override suspend fun reset() {
            withContext(Dispatchers.Main.immediate) {
                prompts.cancelAll()
                tabManager.beginReset()
                _fullscreen.value = false
                tabManager.closeStaleSessions()
            }
            try {
                storage.clearAll() // bounded: a wedged engine must not hold the Tor mutex forever
            } finally {
                withContext(NonCancellable + Dispatchers.Main.immediate) { tabManager.openBlankTab() }
            }
        }
    }

    /** Veil's own tor (Guardian Project TorService). Only started when Tor mode is on and the mode is EMBEDDED. */
    private val embeddedTor = EmbeddedTor(app)

    val tor = TorController(
        prefs = GeckoPrefsGateway(),
        probe = SocketProxyProbe(),
        identity = identity,
        scope = scope,
        host = settingsStore.current.tor.host,
        port = settingsStore.current.tor.port,
        runtime = embeddedTor,
        mode = settingsStore.current.tor.mode,
    )
    val torState: StateFlow<TorState> = tor.state

    val extensions = ExtensionManager(app, runtime, settingsStore, prompts) { _messages.tryEmit(it) }

    private val panicHost = object : PanicHost {
        override fun resetUiToBlank() {
            prompts.cancelAll()
            tabManager.beginReset()
            _fullscreen.value = false
        }

        override suspend fun closeAllSessions() = tabManager.closeStaleSessions()

        override suspend fun clearEngineData() {
            // The exceptions list reveals visited hosts: it only survives panic if the user opted in to remembering it.
            // First, so a hanging or failing engine cannot keep it alive.
            if (!settingsStore.current.rememberSiteSettings) siteStore.clearAll()
            // embedded tor: later connections must not share circuits with what was just wiped (a quick control command)
            withTimeoutOrNull(1_500) { tor.newCircuits() }
            storage.clearAll()
        }

        override fun wipeDisk() {
            ProfileWiper.wipeContents(listOf(app.cacheDir), keep = setOf("mozilla"))
        }

        override fun clearClipboard() {
            val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        }

        override suspend fun openBlankTab() { tabManager.openBlankTab() }

        override fun restartProcess() = ProcessRestart.restart(app)
    }

    val panic = PanicCoordinator(
        host = panicHost,
        options = { settingsStore.current.panic.let { PanicOptions(it.clearClipboard, it.restartProcess) } },
        scope = scope,
    )
    val panicRunning: StateFlow<Boolean> = panic.running

    // -------------------------------------------------------------------------------------------------- lifecycle

    /** Called once after construction. Opens the first tab and brings extensions / Tor autostart up. */
    fun start(initialUrl: String?) {
        val routedStart = settingsStore.current.tor.autoStart
        // With Tor autostart the first page waits until the routing prefs are confirmed (see below).
        tabManager.create(if (routedStart) null else initialUrl)
        scope.launch {
            panic.lastReport.filterNotNull().collect {
                _messages.tryEmit(UiMessage(if (it.clean) UiMessage.Kind.PANIC_DONE else UiMessage.Kind.PANIC_PARTIAL))
            }
        }
        scope.launch {
            // A tab that changes or closes cannot keep the bar hidden behind a fullscreen page that is gone.
            tabs.map { it.activeId }.distinctUntilChanged().collect { _fullscreen.value = false }
        }
        scope.launch {
            // The startup YAML is the first line of defense, but nothing reads it back: write the same prefs again
            // through the runtime API (idempotent) so a silently ignored file cannot weaken the posture.
            if (routedStart) {
                try { tor.adoptRoutedStart() } catch (_: Exception) { }
                if (initialUrl != null) {
                    // embedded tor is still starting in the background: the page cannot load yet, say so instead of failing silently
                    if (tor.state.value.phase == TorPhase.ON) navigate(initialUrl) else _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_STARTING))
                }
            }
            try { GeckoPrefsGateway().apply(HardeningPrefs.baseline) } catch (_: Exception) { }
            try { extensions.start() } catch (_: Exception) { }
        }
    }

    fun onForeground() { tabManager.activeTab?.setActive(true) }
    fun onBackground() { tabManager.activeTab?.setActive(false) }

    // ------------------------------------------------------------------------------------------------ navigation

    val activeState: TabState? get() = tabs.value.active

    fun navigate(input: String) {
        val tab = tabManager.activeTab ?: tabManager.create()
        when (val r = Omnibox.resolve(input, settingsStore.current.searchEngine)) {
            is OmniboxResult.Blank -> tab.load(BLANK_URL)
            is OmniboxResult.Navigate -> tab.load(blockOnionWithoutTor(r.url))
            is OmniboxResult.Search -> tab.load(blockOnionWithoutTor(r.url))
        }
    }

    /**
     * .onion without Tor can never resolve (and must not hit a DNS resolver): send it to the error page instead.
     * With Tor routing wanted, the SOCKS proxy resolves it.
     */
    private fun blockOnionWithoutTor(url: String): String {
        val host = Omnibox.hostOf(url)
        // Tor wanted but the routing prefs are not confirmed in the engine: nothing may start a load now.
        if (tor.wanted && !tor.routingConfirmed) {
            _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_UNREACHABLE))
            return BLANK_URL
        }
        // embedded tor still bootstrapping (autostart): the engine points at a dead port, a load would only fail – say why instead
        if (tor.wanted && tor.state.value.phase == TorPhase.CONNECTING) {
            _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_STARTING))
            return BLANK_URL
        }
        if (host == null || !Omnibox.isOnionHost(host) || tor.wanted) return url
        _messages.tryEmit(UiMessage(UiMessage.Kind.ONION_NEEDS_TOR, host))
        return BLANK_URL
    }

    fun openFromIntent(url: String) {
        if (Omnibox.hostOf(url) == null || url.any { it.isWhitespace() }) return
        val current = tabs.value.active
        if (current != null && current.isBlank) navigate(url) else newTab(url)
    }

    fun newTab(url: String? = null) {
        val parent = tabs.value.activeId.takeIf { it != TabsState.NONE }
        tabManager.create(url?.let(::blockOnionWithoutTor), activate = true, parent = parent)
    }

    fun selectTab(id: Long) = tabManager.select(id)
    fun selectRelative(delta: Int) = tabManager.selectRelative(delta)
    fun back() { tabManager.activeTab?.goBack() }
    fun forward() { tabManager.activeTab?.goForward() }
    fun reload() { tabManager.activeTab?.reload() }
    fun stop() { tabManager.activeTab?.stop() }
    fun setDesktopSite(on: Boolean) { tabManager.activeTab?.setDesktopSite(on) }
    fun exitFullscreen() {
        tabManager.activeTab?.exitFullscreen()
        _fullscreen.value = false
    }
    fun closeAllTabs() { tabs.value.tabs.map { it.id }.forEach(tabManager::close) }
    fun moveTab(id: Long, toIndex: Int) = tabManager.move(id, toIndex)

    // ------------------------------------------------------------------------------------------ privacy actions

    fun triggerPanic() { panic.trigger() }

    fun toggleTor() {
        scope.launch {
            val before = tor.state.value
            // pressed while the embedded tor is still starting = abort (disable() interrupts the start)
            val aborting = before.phase == TorPhase.CONNECTING
            val after = if (before.want || aborting) tor.disable() else tor.enable()
            when {
                aborting -> _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_OFF))
                !before.want && after.phase == TorPhase.OFF && tor.mode == TorMode.EMBEDDED ->
                    _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_START_FAILED, after.detail))
                !before.want && after.phase == TorPhase.OFF -> _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_UNREACHABLE))
                after.phase == TorPhase.ON -> _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_ON))
                after.phase == TorPhase.OFF -> _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_OFF))
                after.phase == TorPhase.UNREACHABLE -> _messages.tryEmit(UiMessage(UiMessage.Kind.TOR_UNREACHABLE))
            }
        }
    }

    /** New Tor circuits, then every tab and all session data go (embedded and external alike; only embedded gets NEWNYM). */
    fun newIdentity() {
        scope.launch {
            if (tor.state.value.phase == TorPhase.ON) tor.newIdentity()
        }
    }

    // ---------------------------------------------------------------------------------------------- settings

    fun updateSettings(f: (AppSettings) -> AppSettings) {
        val before = settingsStore.current
        settingsStore.update(f)
        val after = settingsStore.current
        if (after.tor.mode != before.tor.mode) {
            // the proxy changes hands (own tor <-> external): Tor mode is switched off first, the user switches it on again
            scope.launch {
                if (tor.wanted || tor.state.value.phase == TorPhase.CONNECTING) tor.disable()
                tor.mode = after.tor.mode
                if (after.tor.mode == TorMode.EXTERNAL) runCatching { tor.configure(after.tor.host, after.tor.port) }
            }
        } else if (after.tor.host != before.tor.host || after.tor.port != before.tor.port) {
            scope.launch { runCatching { tor.reconfigure(after.tor.host, after.tor.port) } }
        }
        if (before.rememberSiteSettings != after.rememberSiteSettings) {
            if (after.rememberSiteSettings) persistSites(siteStore.current.toJson()) else files.siteRulesFile.delete()
        }
        applyToEngine()
    }

    private fun applyToEngine() {
        EngineHost.apply(runtime, settingsStore.current, siteStore.current.defaults.thirdPartyCookies, systemDark())
    }

    private fun systemDark(): Boolean =
        (app.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES

    fun persistSites(json: String) {
        if (!settingsStore.current.rememberSiteSettings) return
        runCatching { files.siteRulesFile.writeText(json) }
    }

    fun setSiteDefault(key: RuleKey, value: Setting) {
        siteStore.setDefault(key, value)
        if (key == RuleKey.THIRD_PARTY_COOKIES) applyToEngine()
        if (key == RuleKey.JAVASCRIPT) tabManager.activeTab?.applyRulesAndReload()
    }

    fun setSiteOverride(host: String, key: RuleKey, value: Setting) {
        // hosts the pattern grammar refuses (IPv6 literals, odd labels) are ignored instead of crashing a click handler
        runCatching { siteStore.setOverride(host, key, value) }.onFailure { return }
        if (key == RuleKey.JAVASCRIPT) tabManager.activeTab?.applyRulesAndReload()
    }

    fun clearSiteOverride(host: String, key: RuleKey) {
        siteStore.clear(host, key)
        if (key == RuleKey.JAVASCRIPT) tabManager.activeTab?.applyRulesAndReload()
    }

    fun clearSiteOverrides(host: String) {
        siteStore.clear(host)
        tabManager.activeTab?.applyRulesAndReload()
    }

    fun clearAllSiteOverrides() {
        siteStore.clearAll()
        tabManager.activeTab?.applyRulesAndReload()
    }

    // ------------------------------------------------------------------------------------------------ TabEnv

    override fun rulesFor(host: String?): SiteRules = siteStore.resolve(host)
    override fun rememberRule(host: String, key: RuleKey, value: Setting) { runCatching { siteStore.setOverride(host, key, value) } }
    override fun update(id: Long, f: (TabState) -> TabState) = tabManager.update(id, f)

    override fun newChildSession(parent: GeckoTab, uri: String?): GeckoSession? = tabManager.createChild(parent, uri)

    override fun openInNewTab(url: String, parent: Long) {
        tabManager.create(blockOnionWithoutTor(url), activate = true, parent = parent)
    }

    override fun closeTab(id: Long) = tabManager.close(id)

    override fun requestAndroidPermissions(permissions: List<String>, done: (Boolean) -> Unit) {
        val r = permissionRequester
        if (r == null || permissions.isEmpty()) done(permissions.isEmpty()) else r(permissions, done)
    }

    override fun requestFile(request: FilePickRequest) {
        // tryEmit succeeds even when nobody listens (activity not started): that request would hang forever
        if (_fileRequests.subscriptionCount.value == 0 || !_fileRequests.tryEmit(request)) request.cancel()
    }

    /** Picker / permission requests in flight live here, not in the activity: a recreated activity can still answer them. */
    @Volatile var pendingFilePick: FilePickRequest? = null
    @Volatile var pendingPermission: ((Boolean) -> Unit)? = null

    override fun sessionReopened(id: Long) { tabManager.bumpEpoch() }

    override fun torState(): TorState = tor.state.value
    override fun onFullscreen(id: Long, on: Boolean) { if (tabs.value.activeId == id) _fullscreen.value = on }
    override fun message(msg: UiMessage) { _messages.tryEmit(msg) }
}
