package app.veil.browser.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

enum class ThemeChoice { DARK, LIGHT, SYSTEM }

data class TorSettings(
    val host: String = HardeningPrefs.TOR_HOST,
    val port: Int = HardeningPrefs.TOR_PORT,
    /** Start the engine with the proxy prefs already set (fail-closed autostart). */
    val autoStart: Boolean = false,
    /** [TorMode.EMBEDDED]: Veil runs its own tor (host/port are unused). [TorMode.EXTERNAL]: a proxy the user runs. */
    val mode: TorMode = TorMode.EMBEDDED,
)

data class PanicSettings(
    val clearClipboard: Boolean = true,
    /** Kill every engine process and relaunch after the wipe. Most thorough, but visibly restarts the app. */
    val restartProcess: Boolean = false,
)

/** Preferences contain no browsing data. Per-site exceptions are only persisted when the user opts in. */
data class AppSettings(
    val theme: ThemeChoice = ThemeChoice.DARK,
    val searchEngine: String = Omnibox.DEFAULT_SEARCH,
    /** FLAG_SECURE: no screenshots, screen recording or app-switcher thumbnails of page content. */
    val secureWindow: Boolean = true,
    val httpsOnly: Boolean = true,
    val strictTrackingProtection: Boolean = true,
    val globalPrivacyControl: Boolean = true,
    val rememberSiteSettings: Boolean = false,
    val tor: TorSettings = TorSettings(),
    val panic: PanicSettings = PanicSettings(),
    /** Ids of bundled extensions the user switched off (the engine profile is wiped at start, so we remember it). */
    val disabledExtensions: Set<String> = emptySet(),
) {
    fun toJson(): String = buildJsonObject {
        put("schemaVersion", 1)
        put("theme", theme.name.lowercase())
        put("searchEngine", searchEngine)
        put("secureWindow", secureWindow)
        put("httpsOnly", httpsOnly)
        put("strictTrackingProtection", strictTrackingProtection)
        put("globalPrivacyControl", globalPrivacyControl)
        put("rememberSiteSettings", rememberSiteSettings)
        put("tor", buildJsonObject { put("host", tor.host); put("port", tor.port); put("autoStart", tor.autoStart); put("mode", tor.mode.name.lowercase()) })
        put("panic", buildJsonObject { put("clearClipboard", panic.clearClipboard); put("restartProcess", panic.restartProcess) })
        put("disabledExtensions", JsonArray(disabledExtensions.sorted().map { JsonPrimitive(it) }))
    }.toString()

    companion object {
        private fun JsonObject.bool(k: String, d: Boolean) = (this[k] as? JsonPrimitive)?.booleanOrNull ?: d

        /** Lenient: the settings file is untrusted input, anything invalid falls back to the default. */
        fun fromJson(text: String?): AppSettings {
            val d = AppSettings()
            if (text.isNullOrBlank()) return d
            val r = try { Json.parseToJsonElement(text).jsonObject } catch (_: Exception) { return d }
            val torObj = r["tor"] as? JsonObject ?: JsonObject(emptyMap())
            val panicObj = r["panic"] as? JsonObject ?: JsonObject(emptyMap())

            var host = d.tor.host
            var port = d.tor.port
            val h = (torObj["host"] as? JsonPrimitive)?.contentOrNull
            val p = (torObj["port"] as? JsonPrimitive)?.intOrNull
            if (h != null && p != null && HardeningPrefs.validTorEndpoint(h, p)) { host = h.trim().lowercase(); port = p }

            val search = (r["searchEngine"] as? JsonPrimitive)?.contentOrNull
                ?.takeIf { it.startsWith("https://") && it.contains("%s") && it.length < 512 && it.none(Char::isWhitespace) }
                ?: d.searchEngine
            val theme = ThemeChoice.entries.firstOrNull { it.name.equals((r["theme"] as? JsonPrimitive)?.contentOrNull, true) } ?: d.theme

            return AppSettings(
                theme = theme,
                searchEngine = search,
                secureWindow = r.bool("secureWindow", d.secureWindow),
                httpsOnly = r.bool("httpsOnly", d.httpsOnly),
                strictTrackingProtection = r.bool("strictTrackingProtection", d.strictTrackingProtection),
                globalPrivacyControl = r.bool("globalPrivacyControl", d.globalPrivacyControl),
                rememberSiteSettings = r.bool("rememberSiteSettings", d.rememberSiteSettings),
                tor = TorSettings(
                    host, port, torObj.bool("autoStart", d.tor.autoStart),
                    TorMode.entries.firstOrNull { it.name.equals((torObj["mode"] as? JsonPrimitive)?.contentOrNull, true) } ?: d.tor.mode,
                ),
                panic = PanicSettings(panicObj.bool("clearClipboard", d.panic.clearClipboard), panicObj.bool("restartProcess", d.panic.restartProcess)),
                disabledExtensions = (r["disabledExtensions"] as? JsonArray).orEmpty()
                    .mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.filter(ExtensionManifest::validId).take(200).toSet(),
            )
        }
    }
}

class SettingsStore(initial: AppSettings = AppSettings(), private val persist: (String) -> Unit = {}) {
    private val _state = MutableStateFlow(initial)
    val state: StateFlow<AppSettings> = _state.asStateFlow()
    val current: AppSettings get() = _state.value

    fun update(f: (AppSettings) -> AppSettings) {
        _state.update(f)
        persist(_state.value.toJson())
    }
}
