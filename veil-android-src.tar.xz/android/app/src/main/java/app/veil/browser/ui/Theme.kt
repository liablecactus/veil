package app.veil.browser.ui

import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import app.veil.browser.ui.theme.VeilPalette
import app.veil.browser.ui.theme.VeilTokens

val LocalPalette = staticCompositionLocalOf { VeilTokens.Dark }

/** Shorthand for the active palette: `V.c.text`. */
object V {
    val c: VeilPalette
        @Composable @ReadOnlyComposable get() = LocalPalette.current
}

@Composable
fun VeilTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalPalette provides (if (dark) VeilTokens.Dark else VeilTokens.Light)) { content() }
}

/** Foundation-only text (no Material dependency) with the app's default metrics. */
@Composable
fun VText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = V.c.text,
    size: TextUnit = 15.sp,
    weight: FontWeight = FontWeight.Normal,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign = TextAlign.Start,
    lineHeight: TextUnit = TextUnit.Unspecified,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(color = color, fontSize = size, fontWeight = weight, textAlign = align, lineHeight = lineHeight),
        maxLines = maxLines,
        overflow = if (maxLines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis,
    )
}
