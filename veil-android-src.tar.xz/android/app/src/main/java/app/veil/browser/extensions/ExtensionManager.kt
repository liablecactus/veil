package app.veil.browser.extensions

import android.content.Context
import app.veil.browser.R
import app.veil.browser.core.ExtensionInfo
import app.veil.browser.core.ExtensionManifest
import app.veil.browser.core.PromptBroker
import app.veil.browser.core.SettingsStore
import app.veil.browser.core.UiMessage
import app.veil.browser.core.UiPrompt
import app.veil.browser.engine.await
import app.veil.browser.engine.awaitWithin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

data class ExtensionEntry(
    val id: String,
    val name: String,
    val version: String,
    val builtIn: Boolean,
    val enabled: Boolean,
    val permissions: List<String>,
)

/** An extension folder in assets/extensions that cannot be installed, with the reason (shown in the UI). */
data class SkippedExtension(val dir: String, val info: ExtensionInfo?)

/**
 * Extensions on Android/GeckoView:
 *  - Bundled ones (assets/extensions/<dir>/, prepared with tools/crx2gecko.mjs) are installed as built-ins at every
 *    start. No signature is needed because they ship inside the APK. The engine profile is wiped at start, so
 *    the user's on/off choice is kept in [SettingsStore].
 *  - Signed XPI files (addons.mozilla.org) can be installed at runtime and live until the next start (RAM-only).
 *  - Unsigned Chrome Web Store packages cannot be installed at runtime: release GeckoView enforces signatures.
 */
class ExtensionManager(
    private val app: Context,
    private val runtime: GeckoRuntime,
    private val settings: SettingsStore,
    private val prompts: PromptBroker,
    private val message: (UiMessage) -> Unit,
) {
    private val controller get() = runtime.webExtensionController

    private val _entries = MutableStateFlow<List<ExtensionEntry>>(emptyList())
    val entries: StateFlow<List<ExtensionEntry>> = _entries.asStateFlow()
    private val _skipped = MutableStateFlow<List<SkippedExtension>>(emptyList())
    val skipped: StateFlow<List<SkippedExtension>> = _skipped.asStateFlow()

    private val promptDelegate = object : WebExtensionController.PromptDelegate {
        override fun onInstallPromptRequest(
            extension: WebExtension,
            permissions: Array<out String>,
            origins: Array<out String>,
            dataCollectionPermissions: Array<out String>,
        ): GeckoResult<WebExtension.PermissionPromptResponse>? {
            val result = GeckoResult<WebExtension.PermissionPromptResponse>()
            val all = (permissions.toList() + origins.toList()).joinToString("\n• ", prefix = "• ").ifBlank { "–" }
            prompts.post(UiPrompt.Confirm(
                id = prompts.nextId(),
                origin = extension.metaData.name ?: extension.id,
                message = app.getString(R.string.ext_install_prompt, extension.metaData.name ?: extension.id, all),
                // all sessions are private: an extension that is not allowed there would do nothing
                done = { yes -> result.complete(WebExtension.PermissionPromptResponse(yes, yes, false)) },
                cancel = { result.complete(WebExtension.PermissionPromptResponse(false, false, false)) },
            ))
            return result
        }
    }

    /** Reads assets/extensions/<dir>/manifest.json for every bundled folder. */
    fun scanBundled(): List<Pair<String, ExtensionInfo?>> {
        val dirs = app.assets.list(ASSET_DIR).orEmpty().sorted()
        return dirs.mapNotNull { dir ->
            val manifest = runCatching { app.assets.open("$ASSET_DIR/$dir/manifest.json").bufferedReader().use { it.readText() } }.getOrNull()
                ?: return@mapNotNull null // a plain file such as README.md, not an extension folder
            var info = ExtensionManifest.parse(manifest)
            val locale = info?.defaultLocale
            if (info != null && locale != null) {
                // names like __MSG_extName__ live in _locales/<default_locale>/messages.json
                val msgs = runCatching { app.assets.open("$ASSET_DIR/$dir/_locales/$locale/messages.json").bufferedReader().use { it.readText() } }.getOrNull()
                if (msgs != null) info = ExtensionManifest.parse(manifest, msgs)
            }
            dir to info
        }
    }

    /** Called once after the engine is up. Never throws: a broken extension must not stop the browser. */
    suspend fun start() {
        controller.setPromptDelegate(promptDelegate)
        val skipped = ArrayList<SkippedExtension>()
        for ((dir, info) in scanBundled()) {
            if (info == null || !info.installable || info.id == null) { skipped += SkippedExtension(dir, info); continue }
            try {
                val ext = controller.ensureBuiltIn("resource://android/assets/$ASSET_DIR/$dir/", info.id).awaitWithin(15_000, "install ${info.id}")
                if (ext != null) {
                    controller.setAllowedInPrivateBrowsing(ext, true).await()
                    if (info.id in settings.current.disabledExtensions) controller.disable(ext, WebExtensionController.EnableSource.USER).await()
                }
            } catch (e: Exception) {
                skipped += SkippedExtension(dir, info)
                message(UiMessage(UiMessage.Kind.EXTENSION_FAILED, info.name))
            }
        }
        _skipped.value = skipped
        refresh()
    }

    suspend fun refresh() {
        val list = controller.list().awaitWithin(10_000, "list extensions").orEmpty()
        _entries.value = list.map {
            ExtensionEntry(
                id = it.id,
                name = it.metaData.name ?: it.id,
                version = it.metaData.version,
                builtIn = it.isBuiltIn,
                enabled = it.metaData.enabled,
                permissions = (it.metaData.requiredPermissions.toList() + it.metaData.requiredOrigins.toList()),
            )
        }.sortedBy { it.name.lowercase() }
    }

    private suspend fun find(id: String): WebExtension? =
        controller.list().awaitWithin(10_000, "list extensions").orEmpty().firstOrNull { it.id == id }

    suspend fun setEnabled(id: String, enabled: Boolean) {
        val ext = find(id) ?: return
        if (enabled) controller.enable(ext, WebExtensionController.EnableSource.USER).await()
        else controller.disable(ext, WebExtensionController.EnableSource.USER).await()
        if (ext.isBuiltIn) settings.update { s -> s.copy(disabledExtensions = if (enabled) s.disabledExtensions - id else s.disabledExtensions + id) }
        refresh()
    }

    /** Signed XPI from addons.mozilla.org (or anywhere else the engine accepts). Lives until the next start. */
    suspend fun installFromUrl(url: String) {
        require(url.startsWith("https://")) { "https only" }
        try {
            controller.install(url).awaitWithin(120_000, "install")?.let { controller.setAllowedInPrivateBrowsing(it, true).await() }
            message(UiMessage(UiMessage.Kind.EXTENSION_INSTALLED))
        } catch (e: Exception) {
            message(UiMessage(UiMessage.Kind.EXTENSION_FAILED, e.message))
        }
        refresh()
    }

    suspend fun uninstall(id: String) {
        val ext = find(id) ?: return
        if (ext.isBuiltIn) return
        controller.uninstall(ext).await()
        refresh()
    }

    companion object {
        const val ASSET_DIR = "extensions"
    }
}
