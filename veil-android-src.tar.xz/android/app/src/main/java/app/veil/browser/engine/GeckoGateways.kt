package app.veil.browser.engine

import app.veil.browser.core.PrefsGateway
import org.mozilla.geckoview.GeckoPreferenceController
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.StorageController

/**
 * Runtime preference switching through GeckoPreferenceController. Every write is awaited: if the engine
 * rejects or ignores one, [TorController][app.veil.browser.core.TorController] must hear about it.
 */
class GeckoPrefsGateway(private val timeoutMs: Long = 5_000) : PrefsGateway {
    override suspend fun apply(values: Map<String, Any>) {
        for ((name, value) in values) {
            val result = when (value) {
                is Boolean -> GeckoPreferenceController.setGeckoPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER)
                is Int -> GeckoPreferenceController.setGeckoPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER)
                is String -> GeckoPreferenceController.setGeckoPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER)
                else -> throw IllegalArgumentException("unsupported pref type for $name")
            }
            result.awaitWithin(timeoutMs, "set $name")
        }
    }
}

/** Everything the engine stores for sessions: cookies, caches, DOM storage, permissions, auth sessions. */
class GeckoStorageGateway(private val runtime: GeckoRuntime, private val timeoutMs: Long = 5_000) {
    suspend fun clearAll() {
        runtime.storageController.clearData(StorageController.ClearFlags.ALL).awaitWithin(timeoutMs, "clear storage")
    }
}
