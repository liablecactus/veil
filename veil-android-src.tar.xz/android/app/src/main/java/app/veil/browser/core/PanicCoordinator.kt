package app.veil.browser.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Everything the panic sequence needs from the app. Each member must be safe to call in any state. */
interface PanicHost {
    /** Synchronous and instant: the UI shows a blank, empty browser before any slow step starts. */
    fun resetUiToBlank()

    /** Close every GeckoSession (cancels loads, drops tab state and thumbnails). */
    suspend fun closeAllSessions()

    /** Cookies, caches, DOM storage, permissions, auth sessions – everything the engine keeps. */
    suspend fun clearEngineData()

    /** Delete cache/profile leftovers on disk that the engine does not own. */
    fun wipeDisk()

    fun clearClipboard()

    /** Open a fresh tab on about:blank. */
    suspend fun openBlankTab()

    /** Kill all engine processes and start the app again (optional, most thorough). */
    fun restartProcess()
}

data class PanicOptions(val clearClipboard: Boolean = true, val restartProcess: Boolean = false)

enum class PanicStep { UI_RESET, CLOSE_SESSIONS, CLEAR_ENGINE_DATA, WIPE_DISK, CLEAR_CLIPBOARD, OPEN_BLANK_TAB, RESTART }

/** [seq] makes every report distinct: an identical clean report must still be announced (StateFlow drops equal values). */
data class PanicReport(val failed: Map<PanicStep, String>, val seq: Long = 0) {
    val clean: Boolean get() = failed.isEmpty()
}

/**
 * The hard panic button. Order matters: the UI is blanked first (instant), then everything is torn down.
 * A failing step never stops the following ones – a half-wiped browser that stopped halfway is the worst outcome.
 * Re-entrant: pressing the button again while it runs returns the running job.
 */
class PanicCoordinator(
    private val host: PanicHost,
    private val options: () -> PanicOptions,
    private val scope: CoroutineScope,
    private val engineDataTimeoutMs: Long = 4_000,
) {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    private val _lastReport = MutableStateFlow<PanicReport?>(null)
    val lastReport: StateFlow<PanicReport?> = _lastReport.asStateFlow()

    private var job: Job? = null
    private var seq = 0L

    /** Call on the main thread: the instant part runs synchronously before this returns. */
    fun trigger(): Job {
        job?.takeIf { it.isActive }?.let { return it }
        val failed = LinkedHashMap<PanicStep, String>()
        fun guard(step: PanicStep, block: () -> Unit) {
            try { block() } catch (e: Exception) { failed[step] = e.message ?: e::class.simpleName.orEmpty() }
        }
        _running.value = true
        guard(PanicStep.UI_RESET) { host.resetUiToBlank() }
        val opts = options()
        val j = scope.launch {
            try {
                try { host.closeAllSessions() } catch (e: Exception) { failed[PanicStep.CLOSE_SESSIONS] = e.message.orEmpty() }
                try {
                    // clearData can hang if the engine is already wedged; do not let that block the rest
                    val done = withTimeoutOrNull(engineDataTimeoutMs) { host.clearEngineData(); true }
                    if (done == null) failed[PanicStep.CLEAR_ENGINE_DATA] = "timeout"
                } catch (e: Exception) { failed[PanicStep.CLEAR_ENGINE_DATA] = e.message.orEmpty() }
                try { withContext(Dispatchers.IO) { host.wipeDisk() } } catch (e: Exception) { failed[PanicStep.WIPE_DISK] = e.message ?: e::class.simpleName.orEmpty() }
                if (opts.clearClipboard) guard(PanicStep.CLEAR_CLIPBOARD) { host.clearClipboard() }
                try { host.openBlankTab() } catch (e: Exception) { failed[PanicStep.OPEN_BLANK_TAB] = e.message.orEmpty() }
                _lastReport.value = PanicReport(failed.toMap(), ++seq)
            } finally {
                _running.value = false
            }
            if (opts.restartProcess) guard(PanicStep.RESTART) { host.restartProcess() }
        }
        job = j
        return j
    }
}
