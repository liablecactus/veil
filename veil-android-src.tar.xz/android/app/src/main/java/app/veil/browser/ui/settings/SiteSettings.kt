package app.veil.browser.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.RuleKey
import app.veil.browser.core.Setting
import app.veil.browser.core.normalizePattern
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.Callout
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.FieldBox
import app.veil.browser.ui.FieldKind
import app.veil.browser.ui.IconBtn
import app.veil.browser.ui.PrivateTextField
import app.veil.browser.ui.Route
import app.veil.browser.ui.ScreenFrame
import app.veil.browser.ui.SectionTitle
import app.veil.browser.ui.Segmented
import app.veil.browser.ui.SettingsRow
import app.veil.browser.ui.V
import app.veil.browser.ui.VButton
import app.veil.browser.ui.VText
import app.veil.browser.ui.VeilIcons

@Composable
private fun keyTitle(k: RuleKey): String = stringResource(
    when (k) {
        RuleKey.JAVASCRIPT -> R.string.site_javascript
        RuleKey.POPUPS -> R.string.site_popups
        RuleKey.THIRD_PARTY_COOKIES -> R.string.site_cookies3p
        RuleKey.CAMERA -> R.string.site_camera
        RuleKey.MICROPHONE -> R.string.site_microphone
        RuleKey.GEOLOCATION -> R.string.site_geolocation
        RuleKey.NOTIFICATIONS -> R.string.site_notifications
    },
)

@Composable
private fun keyDescription(k: RuleKey): String = stringResource(
    when (k) {
        RuleKey.JAVASCRIPT -> R.string.site_desc_javascript
        RuleKey.POPUPS -> R.string.site_desc_popups
        RuleKey.THIRD_PARTY_COOKIES -> R.string.site_desc_cookies3p
        RuleKey.CAMERA -> R.string.site_desc_camera
        RuleKey.MICROPHONE -> R.string.site_desc_microphone
        RuleKey.GEOLOCATION -> R.string.site_desc_geolocation
        RuleKey.NOTIFICATIONS -> R.string.site_desc_notifications
    },
)

private fun keyIcon(k: RuleKey) = when (k) {
    RuleKey.JAVASCRIPT -> VeilIcons.Code
    RuleKey.POPUPS -> VeilIcons.Fullscreen
    RuleKey.THIRD_PARTY_COOKIES -> VeilIcons.Folder
    RuleKey.CAMERA -> VeilIcons.Eye
    RuleKey.MICROPHONE -> VeilIcons.Volume
    RuleKey.GEOLOCATION -> VeilIcons.Globe
    RuleKey.NOTIFICATIONS -> VeilIcons.Info
}

@Composable
private fun settingLabel(s: Setting): String = stringResource(
    when (s) {
        Setting.ALLOW -> R.string.opt_allow
        Setting.ASK -> R.string.opt_ask
        Setting.BLOCK -> R.string.opt_block
    },
)

@Composable
private fun settingOptions(key: RuleKey): List<Pair<Setting, String>> =
    Setting.entries.filter(key::accepts).map { it to settingLabel(it) }

/** Chrome-like list of categories, then the sites that have their own exceptions. */
@Composable
fun SiteSettingsScreen(controller: BrowserController, onBack: () -> Unit, onOpen: (Route) -> Unit) {
    val data by controller.siteRules.collectAsState()
    ScreenFrame(stringResource(R.string.settings_sites), onBack) {
        SettingsPage {
            SectionTitle(stringResource(R.string.sites_defaults))
            CardColumn {
                RuleKey.entries.forEachIndexed { i, key ->
                    if (i > 0) Divider()
                    SettingsRow(
                        title = keyTitle(key),
                        description = settingLabel(data.defaults[key]),
                        icon = keyIcon(key),
                        onClick = { onOpen(Route.SiteCategory(key)) },
                        trailing = { Chevron() },
                    )
                }
            }

            SectionTitle(stringResource(R.string.sites_exceptions))
            if (data.overrides.isEmpty()) {
                Hint(stringResource(R.string.sites_exceptions_empty))
            } else {
                CardColumn {
                    data.overrides.keys.sorted().forEachIndexed { i, pattern ->
                        if (i > 0) Divider()
                        SettingsRow(
                            title = pattern,
                            description = stringResource(R.string.sites_exceptions_count, data.overrides[pattern]?.size ?: 0),
                            icon = VeilIcons.Globe,
                            onClick = { onOpen(Route.SiteHost(pattern)) },
                            trailing = { Chevron() },
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
                    VButton(stringResource(R.string.sites_clear_all), controller::clearAllSiteOverrides, filled = false, danger = true)
                }
            }
        }
    }
}

/** One category: the global default, plus – where it makes sense – exceptions for individual sites. */
@Composable
fun SiteCategoryScreen(controller: BrowserController, key: RuleKey, onBack: () -> Unit) {
    val data by controller.siteRules.collectAsState()
    val current = data.defaults[key]
    val exceptions = data.overrides.filter { key in it.value }.toSortedMap()

    ScreenFrame(keyTitle(key), onBack) {
        SettingsPage {
            Hint(keyDescription(key))
            if (!key.perSite) Callout(stringResource(R.string.site_cookies_note))

            SectionTitle(stringResource(R.string.sites_default_title))
            CardColumn {
                val options = Setting.entries.filter(key::accepts)
                options.forEachIndexed { i, option ->
                    if (i > 0) Divider()
                    RadioRow(settingLabel(option), selected = current == option, onSelect = { controller.setSiteDefault(key, option) })
                }
            }

            if (key.perSite) {
                SectionTitle(stringResource(R.string.sites_exceptions))
                if (exceptions.isEmpty()) {
                    Hint(stringResource(R.string.sites_exceptions_empty))
                } else {
                    CardColumn {
                        exceptions.entries.forEachIndexed { i, (pattern, rules) ->
                            if (i > 0) Divider()
                            SettingsRow(
                                title = pattern,
                                description = rules[key]?.let { settingLabel(it) },
                                icon = VeilIcons.Globe,
                                trailing = { IconBtn(VeilIcons.Close, stringResource(R.string.action_remove), { controller.clearSiteOverride(pattern, key) }, size = 36.dp, tint = V.c.textMuted) },
                            )
                        }
                    }
                }
                AddException(controller, key)
            }
        }
    }
}

@Composable
private fun AddException(controller: BrowserController, key: RuleKey) {
    var pattern by remember { mutableStateOf("") }
    var value by remember { mutableStateOf(if (key.canAsk) Setting.ASK else Setting.ALLOW) }
    val normalized = normalizePattern(pattern)
    val invalid = pattern.isNotBlank() && normalized == null

    SectionTitle(stringResource(R.string.site_add_exception))
    CardColumn {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            FieldBox { PrivateTextField(pattern, { pattern = it }, Modifier.fillMaxWidth(), hint = stringResource(R.string.site_pattern_hint), kind = FieldKind.Url) }
            if (invalid) {
                Spacer(Modifier.height(6.dp))
                VText(stringResource(R.string.site_pattern_invalid), color = V.c.danger, size = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Segmented(settingOptions(key), value, { value = it })
                VButton(stringResource(R.string.site_add), {
                    controller.setSiteOverride(normalized ?: return@VButton, key, value)
                    pattern = ""
                }, enabled = normalized != null)
            }
        }
    }
}

/** Everything one site (or `[*.]domain` pattern) may do, with a switch-style selector per permission. */
@Composable
fun SiteHostScreen(controller: BrowserController, host: String, onBack: () -> Unit) {
    val data by controller.siteRules.collectAsState()
    val pattern = normalizePattern(host) ?: host
    val own = data.overrides[pattern].orEmpty()
    val effective = data.resolve(pattern.removePrefix("[*.]"))

    ScreenFrame(host, onBack) {
        SettingsPage {
            Callout(stringResource(R.string.site_memory_note), color = V.c.accent)
            SectionTitle(stringResource(R.string.site_permissions))
            CardColumn {
                val keys = RuleKey.entries.filter { it.perSite }
                keys.forEachIndexed { i, key ->
                    if (i > 0) Divider()
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VText(keyTitle(key), modifier = Modifier.weight(1f))
                            if (key !in own) VText(stringResource(R.string.site_is_default), color = V.c.textFaint, size = 12.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Segmented(settingOptions(key), effective[key], { controller.setSiteOverride(pattern, key, it) })
                    }
                }
            }
            if (own.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
                    VButton(stringResource(R.string.site_reset), { controller.clearSiteOverrides(pattern) }, filled = false, danger = true)
                }
            }
        }
    }
}
