package app.veil.browser.engine

import android.graphics.Bitmap
import org.mozilla.geckoview.GeckoView

/** Renders the visible page into a small RAM-only bitmap for the tab switcher. Never touches the disk. */
object ThumbnailCapture {
    private const val TARGET_WIDTH = 480

    suspend fun capture(view: GeckoView, id: Long, into: Thumbnails) {
        val full = try { view.capturePixels().awaitWithin(1_500, "capture tab thumbnail") } catch (_: Exception) { null } ?: return
        val w = full.width
        val h = full.height
        if (w <= 0 || h <= 0) { full.recycle(); return }
        val scale = (TARGET_WIDTH.toFloat() / w).coerceAtMost(1f)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(full, (w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), true) else full
        if (small !== full) full.recycle()
        into.put(id, small)
    }
}
