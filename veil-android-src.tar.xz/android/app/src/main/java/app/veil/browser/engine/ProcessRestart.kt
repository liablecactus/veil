package app.veil.browser.engine

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Process

/**
 * Hard restart: kill every process of this app (the engine's content/GPU processes are separate pids) and start
 * the launcher activity again. The relaunch runs in a helper process (`:restart`, see the manifest) so it survives
 * the death of the main process.
 */
object ProcessRestart {
    private const val EXTRA_INTENT = "relaunch"
    private const val EXTRA_PID = "kill_pid"

    fun restart(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK) ?: return
        context.startActivity(
            Intent(context, RestartActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(EXTRA_INTENT, launch)
                .putExtra(EXTRA_PID, Process.myPid()),
        )
    }

    /** Kills all other processes of our uid, then the given main pid. */
    internal fun killAll(context: Context, mainPid: Int) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val self = Process.myPid()
        am.runningAppProcesses.orEmpty()
            .filter { it.pid != self && it.pid != mainPid }
            .forEach { runCatching { Process.killProcess(it.pid) } }
        runCatching { Process.killProcess(mainPid) }
    }

    internal fun relaunchIntent(extras: Bundle?): Intent? =
        @Suppress("DEPRECATION") extras?.getParcelable(EXTRA_INTENT)

    internal fun mainPid(extras: Bundle?): Int = extras?.getInt(EXTRA_PID, -1) ?: -1
}

/** Runs in the `:restart` process: no engine, no UI – just kill and relaunch. */
class RestartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = ProcessRestart.mainPid(intent.extras)
        val relaunch = ProcessRestart.relaunchIntent(intent.extras)
        if (pid > 0) ProcessRestart.killAll(this, pid)
        if (relaunch != null) startActivity(relaunch)
        finish()
        Process.killProcess(Process.myPid())
    }
}
