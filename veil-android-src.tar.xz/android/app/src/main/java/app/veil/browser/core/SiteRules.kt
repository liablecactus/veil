package app.veil.browser.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

/** Chrome-style "site settings": one value per category, with per-site exceptions on top of the defaults. */
enum class Setting {
    ALLOW, ASK, BLOCK;

    val json: String get() = name.lowercase()

    companion object {
        fun parse(s: String?): Setting? = entries.firstOrNull { it.json == s }
    }
}

enum class RuleKey(val json: String, val canAsk: Boolean, val perSite: Boolean) {
    JAVASCRIPT("javascript", canAsk = false, perSite = true),
    POPUPS("popups", canAsk = false, perSite = true),

    /** Engine-wide on Android (GeckoView has no per-site cookie policy); see docs/SECURITY.md. */
    THIRD_PARTY_COOKIES("thirdPartyCookies", canAsk = false, perSite = false),
    CAMERA("camera", canAsk = true, perSite = true),
    MICROPHONE("microphone", canAsk = true, perSite = true),
    GEOLOCATION("geolocation", canAsk = true, perSite = true),
    NOTIFICATIONS("notifications", canAsk = true, perSite = true);

    fun accepts(v: Setting): Boolean = v != Setting.ASK || canAsk

    companion object {
        fun parse(s: String): RuleKey? = entries.firstOrNull { it.json == s }
    }
}

data class SiteRules(
    val javascript: Setting = Setting.ALLOW,
    val popups: Setting = Setting.BLOCK,
    val thirdPartyCookies: Setting = Setting.BLOCK,
    val camera: Setting = Setting.ASK,
    val microphone: Setting = Setting.ASK,
    val geolocation: Setting = Setting.ASK,
    val notifications: Setting = Setting.BLOCK,
) {
    operator fun get(key: RuleKey): Setting = when (key) {
        RuleKey.JAVASCRIPT -> javascript
        RuleKey.POPUPS -> popups
        RuleKey.THIRD_PARTY_COOKIES -> thirdPartyCookies
        RuleKey.CAMERA -> camera
        RuleKey.MICROPHONE -> microphone
        RuleKey.GEOLOCATION -> geolocation
        RuleKey.NOTIFICATIONS -> notifications
    }

    fun with(key: RuleKey, value: Setting): SiteRules = when (key) {
        RuleKey.JAVASCRIPT -> copy(javascript = value)
        RuleKey.POPUPS -> copy(popups = value)
        RuleKey.THIRD_PARTY_COOKIES -> copy(thirdPartyCookies = value)
        RuleKey.CAMERA -> copy(camera = value)
        RuleKey.MICROPHONE -> copy(microphone = value)
        RuleKey.GEOLOCATION -> copy(geolocation = value)
        RuleKey.NOTIFICATIONS -> copy(notifications = value)
    }
}

/** Canonical pattern: `example.com` (exact) or `[*.]example.com` (domain and all subdomains). */
fun normalizePattern(input: String): String? {
    var p = input.trim().lowercase()
    if (p.isEmpty()) return null
    var wildcard = false
    when {
        p.startsWith("[*.]") -> { wildcard = true; p = p.substring(4) }
        p.startsWith("*.") -> { wildcard = true; p = p.substring(2) }
    }
    p = p.replace(Regex("^[a-z][a-z0-9+.-]*://"), "")
        .replace(Regex("[/?#].*$"), "")
        .replace(Regex(":\\d+$"), "")
        .trimEnd('.')
    if (p.isEmpty() || p.length > 253 || p.startsWith(".") || p.contains("..")) return null
    if (!Regex("^[a-z0-9.-]+$").matches(p)) {
        // IDN input → punycode via java.net.IDN
        p = try { java.net.IDN.toASCII(p, java.net.IDN.ALLOW_UNASSIGNED).lowercase() } catch (_: Exception) { return null }
        if (!Regex("^[a-z0-9.-]+$").matches(p)) return null
    }
    return if (wildcard) "[*.]$p" else p
}

/** Immutable snapshot of defaults + exceptions; `resolve` is the hot path (called on every navigation). */
data class SiteRuleData(
    val defaults: SiteRules = SiteRules(),
    val overrides: Map<String, Map<RuleKey, Setting>> = emptyMap(),
) {
    /** Precedence: exact host > longest `[*.]suffix` > defaults. */
    fun resolve(hostname: String?): SiteRules {
        val host = hostname?.lowercase()?.trimEnd('.').orEmpty()
        if (host.isEmpty() || overrides.isEmpty()) return defaults
        val chain = ArrayList<Map<RuleKey, Setting>?>(8)
        chain += overrides[host]
        val labels = host.split('.')
        for (i in labels.indices) chain += overrides["[*.]" + labels.drop(i).joinToString(".")]
        var out = defaults
        for (key in RuleKey.entries) {
            if (!key.perSite) continue
            val v = chain.firstNotNullOfOrNull { it?.get(key) }
            if (v != null) out = out.with(key, v)
        }
        return out
    }

    /** Which layer decided a value – used by the site-info sheet. */
    fun explain(hostname: String, key: RuleKey): Pair<Setting, String> {
        val host = hostname.lowercase().trimEnd('.')
        val labels = host.split('.')
        val candidates = listOf(host) + labels.indices.map { "[*.]" + labels.drop(it).joinToString(".") }
        for (c in candidates) overrides[c]?.get(key)?.let { return it to c }
        return defaults[key] to "default"
    }

    fun withDefault(key: RuleKey, value: Setting): SiteRuleData {
        require(key.accepts(value)) { "invalid value for ${key.json}" }
        return copy(defaults = defaults.with(key, value))
    }

    fun withOverride(pattern: String, key: RuleKey, value: Setting): SiteRuleData {
        val p = requireNotNull(normalizePattern(pattern)) { "invalid site pattern" }
        require(key.perSite && key.accepts(value)) { "invalid value for ${key.json}" }
        val cur = overrides[p].orEmpty() + (key to value)
        return copy(overrides = overrides + (p to cur))
    }

    /** Remove one key (or all keys) of a pattern. */
    fun cleared(pattern: String, key: RuleKey? = null): SiteRuleData {
        val p = normalizePattern(pattern) ?: return this
        val cur = overrides[p] ?: return this
        val next = if (key == null) emptyMap() else cur - key
        return copy(overrides = if (next.isEmpty()) overrides - p else overrides + (p to next))
    }

    fun clearedAll(): SiteRuleData = copy(overrides = emptyMap())

    fun toJson(): String {
        val obj = buildJsonObject {
            put("defaults", buildJsonObject { for (k in RuleKey.entries) put(k.json, defaults[k].json) })
            put("overrides", buildJsonObject {
                for ((pattern, rules) in overrides.toSortedMap()) {
                    put(pattern, buildJsonObject { for ((k, v) in rules) put(k.json, v.json) })
                }
            })
        }
        return obj.toString()
    }

    companion object {
        /** Lenient loader: unknown keys/values are dropped rather than throwing (config files are untrusted input). */
        fun fromJson(text: String?): SiteRuleData {
            if (text.isNullOrBlank()) return SiteRuleData()
            val root = try { Json.parseToJsonElement(text).jsonObject } catch (_: Exception) { return SiteRuleData() }
            var defaults = SiteRules()
            (root["defaults"] as? JsonObject)?.let { d ->
                for (k in RuleKey.entries) {
                    val v = Setting.parse((d[k.json] as? JsonPrimitive)?.contentOrNull)
                    if (v != null && k.accepts(v)) defaults = defaults.with(k, v)
                }
            }
            val overrides = LinkedHashMap<String, Map<RuleKey, Setting>>()
            (root["overrides"] as? JsonObject)?.forEach { (rawPattern, rules) ->
                val p = normalizePattern(rawPattern) ?: return@forEach
                val r = rules as? JsonObject ?: return@forEach
                val clean = LinkedHashMap<RuleKey, Setting>()
                for ((rk, rv) in r) {
                    val key = RuleKey.parse(rk) ?: continue
                    val value = Setting.parse((rv as? JsonPrimitive)?.contentOrNull) ?: continue
                    if (key.perSite && key.accepts(value)) clean[key] = value
                }
                if (clean.isNotEmpty()) overrides[p] = clean
            }
            return SiteRuleData(defaults, overrides)
        }
    }
}

/** Observable holder; `persist` is called after every change (debounced by the caller if needed). */
class SiteRuleStore(initial: SiteRuleData = SiteRuleData(), private val persist: (String) -> Unit = {}) {
    private val _state = MutableStateFlow(initial)
    val state: StateFlow<SiteRuleData> = _state.asStateFlow()
    val current: SiteRuleData get() = _state.value

    private fun mutate(f: (SiteRuleData) -> SiteRuleData) {
        _state.update(f)
        persist(_state.value.toJson())
    }

    fun setDefault(key: RuleKey, value: Setting) = mutate { it.withDefault(key, value) }
    fun setOverride(pattern: String, key: RuleKey, value: Setting) = mutate { it.withOverride(pattern, key, value) }
    fun clear(pattern: String, key: RuleKey? = null) = mutate { it.cleared(pattern, key) }
    fun clearAll() = mutate { it.clearedAll() }
    fun resolve(host: String?): SiteRules = _state.value.resolve(host)
}
