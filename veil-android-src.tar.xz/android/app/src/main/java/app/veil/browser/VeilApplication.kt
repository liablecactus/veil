package app.veil.browser

import android.app.Application
import android.content.res.Configuration
import app.veil.browser.core.AppSettings
import app.veil.browser.core.ProfileWiper
import app.veil.browser.core.SettingsStore
import app.veil.browser.core.SiteRuleData
import app.veil.browser.core.SiteRuleStore
import app.veil.browser.engine.AppFiles
import app.veil.browser.engine.BrowserController
import app.veil.browser.engine.EngineHost
import java.io.File

class VeilApplication : Application() {
    /** Null in the helper processes (engine child processes, restart helper): they must not start a browser. */
    var controller: BrowserController? = null
        private set

    override fun onCreate() {
        super.onCreate()
        // Gecko's content/GPU processes and our :restart helper instantiate the Application class as well.
        if (!isMainProcess()) return

        val files = AppFiles(this)

        // 1. Whatever the engine left on disk in an earlier run (profile, caches) goes first – before an engine exists.
        ProfileWiper.wipeContents(files.profileRoots())

        // 2. Our own small files: settings (no browsing data) and, only on opt-in, the per-site exceptions.
        val settingsStore = SettingsStore(AppSettings.fromJson(files.readOrNull(files.settingsFile))) { json ->
            runCatching { files.settingsFile.writeText(json) }
        }
        val s = settingsStore.current
        val sites = if (s.rememberSiteSettings) SiteRuleData.fromJson(files.readOrNull(files.siteRulesFile)) else SiteRuleData()
        val siteStore = SiteRuleStore(sites) { json ->
            if (settingsStore.current.rememberSiteSettings) runCatching { files.siteRulesFile.writeText(json) }
        }

        // 3. Privacy baseline (and Tor, if autostart is on) is in the engine's startup prefs before it starts.
        EngineHost.writeStartupConfig(files.geckoConfig, s)
        val systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val runtime = EngineHost.createRuntime(this, s, sites.defaults.thirdPartyCookies, files.geckoConfig, systemDark)

        controller = BrowserController(this, runtime, settingsStore, siteStore, files).also { it.start(initialUrl = null) }
    }

    private fun isMainProcess(): Boolean = try {
        File("/proc/self/cmdline").readText().trimEnd('\u0000') == packageName
    } catch (_: Exception) {
        true
    }
}
