package app.veil.browser.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.HardeningPrefs
import app.veil.browser.core.TorMode
import app.veil.browser.core.TorPhase
import app.veil.browser.core.torDetailToken
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.Callout
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.FieldBox
import app.veil.browser.ui.FieldKind
import app.veil.browser.ui.PrivateTextField
import app.veil.browser.ui.ScreenFrame
import app.veil.browser.ui.SectionTitle
import app.veil.browser.ui.V
import app.veil.browser.ui.VButton
import app.veil.browser.ui.VText
import app.veil.browser.ui.VeilIcons
import app.veil.browser.ui.torDetailText

private val EMBEDDED_TOKENS = setOf("engine-missing", "engine-failed", "engine-exited", "bootstrap-timeout")

@Composable
fun TorScreen(controller: BrowserController, onBack: () -> Unit) {
    val tor by controller.torState.collectAsState()
    val s by controller.settings.collectAsState()
    val embedded = s.tor.mode == TorMode.EMBEDDED

    var host by remember(s.tor.host) { mutableStateOf(s.tor.host) }
    var port by remember(s.tor.port) { mutableStateOf(s.tor.port.toString()) }
    val portNumber = port.toIntOrNull()
    val valid = portNumber != null && HardeningPrefs.validTorEndpoint(host.trim(), portNumber)
    val changed = host.trim().lowercase() != s.tor.host || portNumber != s.tor.port

    val statusText = when (tor.phase) {
        TorPhase.ON -> stringResource(R.string.tor_status_on)
        TorPhase.CONNECTING ->
            if (embedded) stringResource(R.string.tor_status_starting, tor.progress ?: 0) else stringResource(R.string.tor_status_connecting)
        TorPhase.UNREACHABLE -> stringResource(R.string.tor_status_unreachable)
        TorPhase.OFF -> stringResource(R.string.tor_status_off)
    }
    val statusColor = when (tor.phase) {
        TorPhase.ON, TorPhase.CONNECTING -> V.c.tor
        TorPhase.UNREACHABLE -> V.c.warn
        TorPhase.OFF -> V.c.textMuted
    }

    ScreenFrame(stringResource(R.string.settings_tor), onBack) {
        SettingsPage {
            CardColumn {
                SwitchRow(
                    title = stringResource(R.string.tor_mode),
                    description = statusText,
                    icon = VeilIcons.Onion,
                    checked = tor.want || tor.phase == TorPhase.CONNECTING,
                    onChange = { controller.toggleTor() },
                    accent = V.c.tor,
                )
                if (embedded && tor.phase == TorPhase.ON) {
                    Divider()
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            VText(stringResource(R.string.tor_new_identity), size = 15.sp)
                            VText(stringResource(R.string.tor_new_identity_desc), color = V.c.textMuted, size = 12.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        VButton(stringResource(R.string.tor_new_identity_button), { controller.newIdentity() }, filled = false)
                    }
                }
            }
            tor.detail?.let {
                val text = if (torDetailToken(it) in EMBEDDED_TOKENS) torDetailText(it) else it
                VText(text, color = statusColor, size = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            }

            SectionTitle(stringResource(R.string.tor_engine))
            CardColumn {
                RadioRow(
                    title = stringResource(R.string.tor_engine_embedded),
                    description = stringResource(R.string.tor_engine_embedded_desc),
                    selected = embedded,
                    onSelect = { if (!embedded) controller.updateSettings { it.copy(tor = it.tor.copy(mode = TorMode.EMBEDDED)) } },
                )
                Divider()
                RadioRow(
                    title = stringResource(R.string.tor_engine_external),
                    description = stringResource(R.string.tor_engine_external_desc),
                    selected = !embedded,
                    onSelect = { if (embedded) controller.updateSettings { it.copy(tor = it.tor.copy(mode = TorMode.EXTERNAL)) } },
                )
            }

            if (embedded) {
                Callout(stringResource(R.string.tor_embedded_info), color = V.c.tor)
            } else {
                Callout(stringResource(R.string.tor_needs_proxy, s.tor.host, s.tor.port), color = V.c.tor)
                SectionTitle(stringResource(R.string.tor_endpoint))
                CardColumn {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FieldBox(Modifier.weight(1f)) { PrivateTextField(host, { host = it }, Modifier.fillMaxWidth(), hint = stringResource(R.string.tor_host), kind = FieldKind.Url) }
                            Spacer(Modifier.width(10.dp))
                            FieldBox(Modifier.width(96.dp)) { PrivateTextField(port, { port = it.filter(Char::isDigit).take(5) }, Modifier.fillMaxWidth(), hint = stringResource(R.string.tor_port), kind = FieldKind.Number) }
                        }
                        if (!valid) {
                            Spacer(Modifier.height(6.dp))
                            VText(stringResource(R.string.tor_endpoint_invalid), color = V.c.danger, size = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            VButton(stringResource(R.string.action_save), {
                                val p = portNumber ?: return@VButton
                                controller.updateSettings { it.copy(tor = it.tor.copy(host = host.trim().lowercase(), port = p)) }
                            }, enabled = valid && changed)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            CardColumn {
                SwitchRow(
                    title = stringResource(R.string.tor_autostart),
                    description = stringResource(if (embedded) R.string.tor_autostart_desc_embedded else R.string.tor_autostart_desc),
                    checked = s.tor.autoStart,
                    onChange = { v -> controller.updateSettings { it.copy(tor = it.tor.copy(autoStart = v)) } },
                )
            }

            SectionTitle(stringResource(R.string.tor_how_title))
            Hint(stringResource(R.string.tor_how_body))
            if (embedded) Hint(stringResource(R.string.tor_how_embedded))
        }
    }
}
