package app.veil.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.veil.browser.R
import app.veil.browser.ui.theme.VeilTokens

// ----------------------------------------------------------------------------------------------------- feedback

/**
 * Press feedback used by every tappable thing: a springy scale-down plus a soft highlight that fades in and out.
 * No ripple dependency, and it works the same on every Android version.
 */
fun Modifier.touchable(
    onClick: () -> Unit,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(VeilTokens.RadiusMd),
    pressedScale: Float = 0.94f,
    role: Role = Role.Button,
    description: String? = null,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press-scale",
    )
    val glow by animateFloatAsState(if (pressed && enabled) 1f else 0f, tween(if (pressed) VeilTokens.MotionFast else VeilTokens.MotionBase), label = "press-glow")
    val tint = V.c.text
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(shape)
        .drawBehind { if (glow > 0f) drawRect(tint.copy(alpha = 0.10f * glow)) }
        .semantics { this.role = role; if (description != null) contentDescription = description }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

// ------------------------------------------------------------------------------------------------------- icons

@Composable
fun VIcon(icon: ImageVector, tint: Color = V.c.text, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Image(icon, contentDescription = null, modifier = modifier.size(size), colorFilter = ColorFilter.tint(tint))
}

@Composable
fun IconBtn(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = V.c.text,
    background: Color = Color.Transparent,
    size: Dp = 40.dp,
    enabled: Boolean = true,
) {
    Box(
        modifier = modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(background)
            .touchable(onClick, enabled, CircleShape, description = description),
        contentAlignment = Alignment.Center,
    ) { VIcon(icon, tint, 22.dp) }
}

// --------------------------------------------------------------------------------------------------- controls

@Composable
fun VSwitch(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier, accent: Color = V.c.accent) {
    val thumbX by animateDpAsState(if (checked) 20.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow), label = "thumb")
    val track by animateColorAsState(if (checked) accent else V.c.surfaceActive, tween(VeilTokens.MotionBase), label = "track")
    val thumb by animateColorAsState(if (checked) V.c.accentOn else V.c.textMuted, tween(VeilTokens.MotionBase), label = "thumb-color")
    Box(
        modifier
            .size(width = 48.dp, height = 28.dp)
            .clip(CircleShape)
            .background(track)
            .semantics { role = Role.Switch }
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onChange(!checked) }
            .padding(4.dp),
    ) {
        Box(Modifier.offset(x = thumbX).size(20.dp).clip(CircleShape).background(thumb))
    }
}

/** Segmented control: one pill that slides between the options. */
@Composable
fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(VeilTokens.RadiusPill)).background(V.c.surface).padding(3.dp)) {
        for ((value, label) in options) {
            val on = value == selected
            val bg by animateColorAsState(if (on) V.c.surfaceActive else Color.Transparent, tween(VeilTokens.MotionBase), label = "seg-bg")
            val fg by animateColorAsState(if (on) V.c.text else V.c.textMuted, tween(VeilTokens.MotionBase), label = "seg-fg")
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(bg)
                    .touchable({ onSelect(value) }, shape = CircleShape, pressedScale = 0.96f, role = Role.RadioButton)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) { VText(label, color = fg, size = 13.sp, weight = FontWeight.Medium, maxLines = 1) }
        }
    }
}

@Composable
fun VButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, filled: Boolean = true, danger: Boolean = false, enabled: Boolean = true) {
    val bg = when { !filled -> Color.Transparent; danger -> V.c.danger; else -> V.c.accent }
    val fg = when { !filled -> if (danger) V.c.danger else V.c.accent; danger -> V.c.dangerOn; else -> V.c.accentOn }
    Box(
        modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(VeilTokens.RadiusPill))
            .background(bg)
            .touchable(onClick, enabled, RoundedCornerShape(VeilTokens.RadiusPill))
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { VText(text, color = fg, size = 14.sp, weight = FontWeight.Medium, maxLines = 1) }
}

// --------------------------------------------------------------------------------------------------- dialogs

/** Centered, animated dialog surface (scale + fade in). `onDismiss` is called for back press and outside taps. */
@Composable
fun VDialog(onDismiss: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } },
            contentAlignment = Alignment.Center,
        ) {
            AnimatedVisibility(
                visible = shown,
                enter = fadeIn(tween(VeilTokens.MotionBase)) + scaleIn(initialScale = 0.92f, animationSpec = tween(VeilTokens.MotionBase, easing = VeilTokens.EaseOut)),
                exit = fadeOut(tween(VeilTokens.MotionFast)) + scaleOut(targetScale = 0.96f, animationSpec = tween(VeilTokens.MotionFast)),
            ) {
                Column(
                    modifier
                        .padding(24.dp)
                        .widthIn(max = 420.dp)
                        .clip(RoundedCornerShape(VeilTokens.RadiusLg + 6.dp))
                        .background(V.c.toolbar)
                        .border(1.dp, V.c.outline, RoundedCornerShape(VeilTokens.RadiusLg + 6.dp))
                        .pointerInput(Unit) { detectTapGestures { } } // taps inside must not dismiss
                        .padding(20.dp),
                ) { content() }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ settings kit

@Composable
fun ScreenFrame(title: String, onBack: () -> Unit, modifier: Modifier = Modifier, actions: @Composable () -> Unit = {}, content: @Composable () -> Unit) {
    Column(modifier.fillMaxSize().background(V.c.frame)) {
        Row(
            Modifier.fillMaxWidth().background(V.c.toolbar).windowInsetsPadding(WindowInsets.statusBars).height(56.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBtn(VeilIcons.Back, stringResource(R.string.action_back), onBack)
            Spacer(Modifier.size(4.dp))
            VText(title, size = 20.sp, weight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
            actions()
        }
        Box(Modifier.weight(1f).windowInsetsPadding(WindowInsets.navigationBars)) { content() }
    }
}

@Composable
fun SectionTitle(text: String) {
    VText(text.uppercase(), color = V.c.accent, size = 12.sp, weight = FontWeight.Medium, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 8.dp))
}

@Composable
fun CardColumn(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier.padding(horizontal = 12.dp).fillMaxWidth().clip(RoundedCornerShape(VeilTokens.RadiusLg)).background(V.c.toolbar)) { content() }
}

/** One settings row: icon, title, optional description, trailing control. Tappable when `onClick` is given. */
@Composable
fun SettingsRow(
    title: String,
    modifier: Modifier = Modifier,
    description: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = V.c.textMuted,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {},
) {
    val base = if (onClick != null) modifier.touchable(onClick, shape = RoundedCornerShape(0.dp), pressedScale = 0.985f) else modifier
    Row(base.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { VIcon(icon, iconTint, 22.dp); Spacer(Modifier.size(16.dp)) }
        Column(Modifier.weight(1f)) {
            VText(title, size = 16.sp)
            if (description != null) VText(description, color = V.c.textMuted, size = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.size(12.dp))
        trailing()
    }
}

@Composable
fun Divider() {
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(1.dp).background(V.c.outline.copy(alpha = 0.5f)))
}

@Composable
fun Callout(text: String, modifier: Modifier = Modifier, color: Color = V.c.warn) {
    Row(
        modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(VeilTokens.RadiusMd))
            .background(color.copy(alpha = 0.12f)).padding(14.dp),
    ) {
        VIcon(VeilIcons.Info, color, 20.dp)
        Spacer(Modifier.size(12.dp))
        VText(text, color = V.c.text, size = 13.sp, lineHeight = 19.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
fun BottomSpace() { Spacer(Modifier.height(32.dp)) }
