package app.veil.browser.ui.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.SettingsRow
import app.veil.browser.ui.V
import app.veil.browser.ui.VIcon
import app.veil.browser.ui.VSwitch
import app.veil.browser.ui.VText
import app.veil.browser.ui.VeilIcons
import app.veil.browser.ui.theme.VeilTokens

/** Right-pointing disclosure arrow (the icon set only has the downward chevron). */
@Composable
fun Chevron() {
    VIcon(VeilIcons.Chevron, V.c.textFaint, 22.dp, Modifier.graphicsLayer { rotationZ = -90f })
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, description: String? = null, icon: ImageVector? = null, accent: Color = V.c.accent) {
    SettingsRow(
        title = title,
        description = description,
        icon = icon,
        onClick = { onChange(!checked) },
        trailing = { VSwitch(checked, onChange, accent = accent) },
    )
}

@Composable
fun RadioRow(title: String, selected: Boolean, onSelect: () -> Unit, description: String? = null) {
    SettingsRow(
        title = title,
        description = description,
        onClick = onSelect,
        trailing = {
            val ring by animateColorAsState(if (selected) V.c.accent else V.c.textFaint, tween(VeilTokens.MotionBase), label = "radio-ring")
            val dot by animateFloatAsState(if (selected) 1f else 0f, tween(VeilTokens.MotionBase), label = "radio-dot")
            Box(Modifier.size(22.dp).clip(CircleShape).border(2.dp, ring, CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(10.dp).graphicsLayer { scaleX = dot; scaleY = dot; alpha = dot }.clip(CircleShape).background(V.c.accent))
            }
        },
    )
}

/** Scrolling body of a settings page. */
@Composable
fun SettingsPage(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 4.dp)) {
        content()
        Spacer(Modifier.size(32.dp))
    }
}

/** Rows of a card with dividers in between. */
@Composable
fun Rows(vararg rows: @Composable () -> Unit) {
    CardColumn {
        rows.forEachIndexed { i, row ->
            if (i > 0) Divider()
            row()
        }
    }
}

@Composable
fun Hint(text: String, modifier: Modifier = Modifier) {
    VText(text, color = V.c.textMuted, size = 13.sp, lineHeight = 19.sp, modifier = modifier.padding(horizontal = 20.dp, vertical = 8.dp))
}
