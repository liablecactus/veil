package app.veil.browser.core

/** Short-lived notices (snackbar/toast). The UI maps [kind] onto localized strings. */
data class UiMessage(val kind: Kind, val arg: String? = null) {
    enum class Kind {
        DOWNLOAD_BLOCKED,
        POPUP_BLOCKED,
        PANIC_DONE,
        PANIC_PARTIAL,
        TOR_ON,
        TOR_OFF,
        TOR_UNREACHABLE,
        TOR_STARTING,
        TOR_START_FAILED,
        EXTENSION_FAILED,
        EXTENSION_INSTALLED,
        LINK_COPIED,
        ONION_NEEDS_TOR,
    }
}
