package app.veil.browser.core

import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Applies Gecko preferences (implemented on top of GeckoPreferenceController). Must fail loudly, never silently. */
interface PrefsGateway {
    suspend fun apply(values: Map<String, Any>)
}

/** Is something speaking SOCKS5 on this endpoint? */
interface ProxyProbe {
    suspend fun reachable(host: String, port: Int): Boolean
}

/** Makes sessions pick up the new network path: closes all tabs/sessions, clears engine data, opens a blank tab. */
interface IdentityReset {
    suspend fun reset()
}

enum class TorPhase {
    OFF,

    /** Preferences are being switched / waiting for the proxy to appear. */
    CONNECTING,
    ON,

    /** Routing is on but the proxy is gone: traffic is *blocked*, not leaked (fail closed). */
    UNREACHABLE,
}

data class TorState(
    val phase: TorPhase = TorPhase.OFF,
    val want: Boolean = false,
    val detail: String? = null,
    /** Embedded tor only: bootstrap progress 0..100 while [TorPhase.CONNECTING] / recovering. */
    val progress: Int? = null,
    val bootTag: String? = null,
) {
    val routed: Boolean get() = phase != TorPhase.OFF
}

/**
 * Tor mode = engine-wide SOCKS5 proxy on a loopback endpoint, switched at runtime. The proxy is either Veil's own
 * embedded tor ([TorMode.EMBEDDED], started and stopped through [TorRuntime]) or one the user runs ([TorMode.EXTERNAL]).
 *
 * Fail-closed rules, mirroring the desktop implementation:
 *  - enable: probe first (nothing changes when there is no proxy), then switch prefs, then reset sessions so
 *    nothing opened before the switch survives.
 *  - while enabled, a watchdog keeps probing; if the proxy disappears the state turns UNREACHABLE but the prefs
 *    stay as they are, so requests fail instead of falling back to a direct connection.
 *  - disable: prefs back to direct, then reset sessions again.
 */
class TorController(
    private val prefs: PrefsGateway,
    private val probe: ProxyProbe,
    private val identity: IdentityReset,
    private val scope: CoroutineScope,
    private val watchdogMs: Long = 3_000,
    @Volatile var host: String = HardeningPrefs.TOR_HOST,
    @Volatile var port: Int = HardeningPrefs.TOR_PORT,
    private val runtime: TorRuntime? = null,
    @Volatile var mode: TorMode = TorMode.EXTERNAL,
    private val recoveryDelaysMs: List<Long> = RECOVERY_DELAYS_MS,
) {
    private val _state = MutableStateFlow(TorState())
    val state: StateFlow<TorState> = _state.asStateFlow()
    private val lock = Mutex()
    private var watchdog: Job? = null
    private var recovery: Job? = null

    /** The engine is known to hold the complete set of routing prefs (wanted is not enough: a write may have failed). */
    @Volatile private var applied = false
    val routingConfirmed: Boolean get() = applied

    /** True when the user wants Tor; the UI must not let *any* load through a direct path while this is set. */
    val wanted: Boolean get() = _state.value.want

    fun configure(host: String, port: Int) {
        require(HardeningPrefs.validTorEndpoint(host, port)) { "Tor endpoint must be on loopback" }
        this.host = host
        this.port = port
    }

    /** Returns the resulting state. [TorPhase.OFF] with a detail means "could not enable, nothing changed". */
    suspend fun enable(): TorState = lock.withLock {
        if (_state.value.phase == TorPhase.ON) return _state.value
        if (mode == TorMode.EMBEDDED) return enableEmbedded()
        _state.value = TorState(TorPhase.CONNECTING, want = false)
        if (!probe.reachable(host, port)) {
            _state.value = TorState(TorPhase.OFF, want = false, detail = "unreachable")
            return _state.value
        }
        _state.value = TorState(TorPhase.CONNECTING, want = true)
        try {
            prefs.apply(HardeningPrefs.torOn(host, port))
            applied = true
        } catch (e: Exception) {
            // Prefs may be half applied: keep routing wanted (the UI refuses direct loads), close every open session,
            // and let the watchdog repeat the write until it sticks.
            applied = false
            runCatching { identity.reset() }
            _state.value = TorState(TorPhase.UNREACHABLE, want = true, detail = e.message ?: "prefs failed")
            startWatchdog()
            return _state.value
        }
        try {
            identity.reset()
        } catch (e: Exception) {
            _state.value = TorState(TorPhase.UNREACHABLE, want = true, detail = e.message ?: "reset failed")
            startWatchdog()
            return _state.value
        }
        _state.value = TorState(TorPhase.ON, want = true)
        startWatchdog()
        _state.value
    }

    suspend fun disable(): TorState {
        // A start that is still waiting for tor holds the lock for as long as the bootstrap takes: abort it first.
        if (booting) {
            abortRequested = true
            runCatching { runtime?.stop() }
        }
        return disableLocked()
    }

    private suspend fun disableLocked(): TorState = lock.withLock {
        watchdog?.cancel()
        watchdog = null
        recovery?.cancel()
        recovery = null
        if (_state.value.phase == TorPhase.OFF && !_state.value.want) { stopRuntime(); return _state.value }
        // want = false first, so the UI stops treating the path as Tor while the prefs flip
        _state.value = TorState(TorPhase.CONNECTING, want = false)
        try {
            prefs.apply(HardeningPrefs.torOff)
            applied = false
            blocked = false
            identity.reset()
            // only now: the engine no longer points at the embedded tor, so stopping it cannot open a direct path
            stopRuntime()
            _state.value = TorState(TorPhase.OFF, want = false)
        } catch (e: Exception) {
            _state.value = TorState(TorPhase.UNREACHABLE, want = true, detail = e.message ?: "prefs failed")
            startWatchdog()
        }
        _state.value
    }

    /**
     * Autostart: the engine already started with the proxy prefs from the config file, so only the state
     * and the watchdog need to catch up. UNREACHABLE until the proxy shows up – requests fail meanwhile.
     */
    suspend fun adoptRoutedStart(): TorState = lock.withLock {
        if (mode == TorMode.EMBEDDED) return adoptEmbedded()
        _state.value = TorState(TorPhase.CONNECTING, want = true)
        // The config file is only trusted as the first line of defense: whether the engine really honoured it is
        // never read back, so the same prefs are written again through the runtime API (idempotent).
        applied = try { prefs.apply(HardeningPrefs.torOn(host, port)); true } catch (_: Exception) { false }
        _state.value = when {
            !applied -> TorState(TorPhase.UNREACHABLE, true, "prefs failed")
            probe.reachable(host, port) -> TorState(TorPhase.ON, true)
            else -> TorState(TorPhase.UNREACHABLE, true, "unreachable")
        }
        startWatchdog()
        _state.value
    }

    /** The endpoint changed: while routing is wanted the engine has to be pointed at the new one, not just the probe. */
    suspend fun reconfigure(host: String, port: Int): TorState = lock.withLock {
        // the embedded tor picks its own port: the configured endpoint only matters for an external proxy
        if (mode == TorMode.EMBEDDED) return _state.value
        configure(host, port)
        if (_state.value.want) {
            applied = false
            try {
                prefs.apply(HardeningPrefs.torOn(host, port))
                applied = true
            } catch (e: Exception) {
                _state.value = TorState(TorPhase.UNREACHABLE, true, e.message ?: "prefs failed")
            }
        }
        _state.value
    }

    companion object {
        val RECOVERY_DELAYS_MS: List<Long> = listOf(1_500L, 5_000L, 12_000L)
    }

    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(watchdogMs)
                if (!_state.value.want) return@launch
                // embedded tor is down and the engine is blocked: the recovery loop owns the state until tor is back
                if (blocked) continue
                val up = probe.reachable(host, port)
                lock.withLock {
                    val s = _state.value
                    if (!s.want) return@launch
                    if (!applied && up) {
                        // the routing prefs never fully reached the engine: repeat the write before anything may be called ON
                        try {
                            prefs.apply(HardeningPrefs.torOn(host, port))
                            applied = true
                            runCatching { identity.reset() }
                        } catch (e: Exception) {
                            _state.value = TorState(TorPhase.UNREACHABLE, true, e.message ?: "prefs failed")
                        }
                    }
                    val now = _state.value
                    if (applied) {
                        if (up && now.phase == TorPhase.UNREACHABLE) _state.value = TorState(TorPhase.ON, true)
                        else if (!up && now.phase == TorPhase.ON) {
                            _state.value = TorState(TorPhase.UNREACHABLE, true, "unreachable")
                            // its port is free now: nothing else may be reachable through it, and tor has to come back
                            if (mode == TorMode.EMBEDDED) { blockRouting(); scheduleRecovery() }
                        }
                    }
                }
            }
        }
    }

    fun shutdown() {
        watchdog?.cancel()
        watchdog = null
        recovery?.cancel()
        recovery = null
        runtime?.setOnExit(null)
    }

    // ------------------------------------------------------------------------------------------ embedded tor

    /** Fresh circuits for new connections (embedded tor only; an external proxy is not ours to signal). */
    suspend fun newCircuits() {
        val rt = runtime ?: return
        if (mode == TorMode.EMBEDDED && _state.value.phase == TorPhase.ON) runCatching { rt.newCircuits() }
    }

    /** "New identity": new circuits, then all sessions and engine data go. */
    suspend fun newIdentity(): Boolean = lock.withLock {
        if (_state.value.phase != TorPhase.ON) return false
        newCircuits()
        runCatching { identity.reset() }.isSuccess
    }

    private suspend fun enableEmbedded(): TorState {
        val rt = runtime
        if (rt == null || !rt.available) {
            _state.value = TorState(TorPhase.OFF, want = false, detail = "engine-missing")
            return _state.value
        }
        // want = false while tor boots: the engine keeps its current path until there is a proxy to switch to
        _state.value = TorState(TorPhase.CONNECTING, want = false, progress = 0)
        val endpoint = try {
            boot(rt) { p -> _state.update { if (it.phase == TorPhase.CONNECTING && !it.want) it.copy(progress = p.percent, bootTag = p.tag) else it } }
        } catch (e: TorRuntimeException) {
            runCatching { rt.stop() }
            _state.value = TorState(TorPhase.OFF, want = false, detail = if (e.code == TorRuntimeException.Code.ABORTED) null else detailOf(e))
            return _state.value
        } catch (e: kotlinx.coroutines.CancellationException) {
            withContext(NonCancellable) { runCatching { rt.stop() } }
            _state.value = TorState(TorPhase.OFF, want = false)
            throw e
        } catch (e: Exception) {
            runCatching { rt.stop() }
            _state.value = TorState(TorPhase.OFF, want = false, detail = "engine-failed: ${e.message.orEmpty().take(120)}")
            return _state.value
        }
        // never route the engine to a port that was merely reported: something has to answer SOCKS5 there
        if (!proxyAnswers(endpoint.host, endpoint.port)) {
            runCatching { rt.stop() }
            _state.value = TorState(TorPhase.OFF, want = false, detail = "engine-failed: proxy not answering")
            return _state.value
        }
        host = endpoint.host
        port = endpoint.port
        rt.setOnExit(::onRuntimeExit)
        _state.value = TorState(TorPhase.CONNECTING, want = true)
        blocked = false
        try {
            prefs.apply(HardeningPrefs.torOn(host, port))
            applied = true
        } catch (e: Exception) {
            applied = false
            runCatching { identity.reset() }
            _state.value = TorState(TorPhase.UNREACHABLE, want = true, detail = e.message ?: "prefs failed")
            startWatchdog()
            return _state.value
        }
        try {
            identity.reset()
        } catch (e: Exception) {
            _state.value = TorState(TorPhase.UNREACHABLE, want = true, detail = e.message ?: "reset failed")
            startWatchdog()
            return _state.value
        }
        _state.value = TorState(TorPhase.ON, want = true)
        startWatchdog()
        return _state.value
    }

    /**
     * Autostart with the embedded tor. The engine began with its proxy prefs pointing at a dead loopback port (see
     * [HardeningPrefs.TOR_BLOCKED_PORT]) – no request can leave the device. Returns as soon as that is confirmed; tor boots in
     * the background and, once it is up, the same prefs are written again with its real port. If it never comes up, nothing
     * is ever sent directly.
     */
    private suspend fun adoptEmbedded(): TorState {
        _state.value = TorState(TorPhase.CONNECTING, want = true, progress = 0)
        applied = blockRouting()
        if (!applied) {
            _state.value = TorState(TorPhase.UNREACHABLE, true, "prefs failed")
            startWatchdog()
            return _state.value
        }
        val rt = runtime
        if (rt == null || !rt.available) {
            _state.value = TorState(TorPhase.UNREACHABLE, true, "engine-missing")
            return _state.value
        }
        rt.setOnExit(::onRuntimeExit)
        // The bootstrap takes seconds to minutes and holds the lock all that time: it runs in the background so the app
        // (baseline prefs, extensions, UI) is not held up. Everything is blocked meanwhile (see above). The lock is free
        // again for a moment between here and the launch, so "switched off in the meantime" is checked once it is held.
        scope.launch {
            lock.withLock {
                val s = _state.value
                if (mode != TorMode.EMBEDDED || !s.want || s.phase != TorPhase.CONNECTING) return@withLock
                if (!startEmbeddedLocked(rt)) scheduleRecovery()
            }
        }
        return _state.value
    }

    /** Starts tor and points the engine at it. Locked callers only. Leaves a fail-closed state and returns false on failure. */
    private suspend fun startEmbeddedLocked(rt: TorRuntime): Boolean {
        val endpoint = try {
            boot(rt) { p -> _state.update { if (it.want && it.phase != TorPhase.ON) it.copy(progress = p.percent, bootTag = p.tag) else it } }
        } catch (e: TorRuntimeException) {
            // ABORTED = the user switched Tor off while it was starting: disable() takes over, nothing to recover
            if (e.code == TorRuntimeException.Code.ABORTED) return true
            _state.value = TorState(TorPhase.UNREACHABLE, true, detailOf(e))
            return false
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.value = TorState(TorPhase.UNREACHABLE, true, "engine-failed: ${e.message.orEmpty().take(120)}")
            return false
        }
        // the user may have switched Tor off while it was starting
        if (!_state.value.want) { runCatching { rt.stop() }; return true }
        if (!proxyAnswers(endpoint.host, endpoint.port)) {
            _state.value = TorState(TorPhase.UNREACHABLE, true, "engine-failed: proxy not answering")
            return false
        }
        host = endpoint.host
        port = endpoint.port
        applied = try { prefs.apply(HardeningPrefs.torOn(host, port)); true } catch (_: Exception) { false }
        if (!applied) {
            _state.value = TorState(TorPhase.UNREACHABLE, true, "prefs failed")
            startWatchdog()
            return false
        }
        blocked = false
        _state.value = TorState(TorPhase.ON, true)
        startWatchdog()
        return true
    }

    /** The engine points at [HardeningPrefs.TOR_BLOCKED_PORT]: the embedded tor is down and being restarted. */
    @Volatile private var blocked = false
    @Volatile private var booting = false
    @Volatile private var abortRequested = false

    private suspend fun boot(rt: TorRuntime, onProgress: (TorProgress) -> Unit): TorEndpoint {
        abortRequested = false
        booting = true
        try {
            val endpoint = rt.start(onProgress)
            if (abortRequested) {
                runCatching { rt.stop() }
                throw TorRuntimeException(TorRuntimeException.Code.ABORTED)
            }
            return endpoint
        } finally {
            booting = false
        }
    }

    private suspend fun proxyAnswers(host: String, port: Int): Boolean {
        repeat(5) {
            if (probe.reachable(host, port)) return true
            delay(300)
        }
        return false
    }

    /** Points the engine at a loopback port nothing can listen on: requests fail, they never go out directly. */
    private suspend fun blockRouting(): Boolean =
        try {
            prefs.apply(HardeningPrefs.torOn(HardeningPrefs.TOR_HOST, HardeningPrefs.TOR_BLOCKED_PORT))
            blocked = true
            true
        } catch (_: Exception) { false }

    private fun onRuntimeExit(reason: String?) {
        scope.launch {
            lock.withLock {
                val s = _state.value
                if (mode != TorMode.EMBEDDED || !s.want || (s.phase != TorPhase.ON && s.phase != TorPhase.UNREACHABLE)) return@withLock
                _state.value = TorState(TorPhase.UNREACHABLE, true, "engine-exited${reason?.let { ": ${it.take(120)}" } ?: ""}")
                blockRouting()
                scheduleRecovery()
            }
        }
    }

    /** tor is gone but Tor mode is wanted: try to bring it back (new port), with growing pauses, never routing directly. */
    private fun scheduleRecovery() {
        recovery?.cancel()
        recovery = scope.launch {
            for (d in recoveryDelaysMs) {
                delay(d)
                val done = lock.withLock {
                    val rt = runtime
                    if (rt == null || mode != TorMode.EMBEDDED || !_state.value.want) return@withLock true
                    runCatching { rt.stop() }
                    if (!blocked) blockRouting()
                    _state.value = _state.value.copy(phase = TorPhase.UNREACHABLE, progress = 0)
                    startEmbeddedLocked(rt)
                }
                if (done) return@launch
            }
        }
    }

    private suspend fun stopRuntime() {
        val rt = runtime ?: return
        rt.setOnExit(null)
        runCatching { rt.stop() }
    }

    private fun detailOf(e: TorRuntimeException): String = e.token + (e.message?.takeIf { it.isNotBlank() }?.let { ": ${it.take(160)}" } ?: "")
}

/** SOCKS5 method negotiation (`05 01 00` → `05 xx`): proves a SOCKS5 server answers, without sending any target. */
class SocketProxyProbe(
    private val timeoutMs: Int = 1_500,
    private val io: CoroutineDispatcher = Dispatchers.IO,
) : ProxyProbe {
    override suspend fun reachable(host: String, port: Int): Boolean = withContext(io) {
        try {
            Socket().use { s ->
                s.soTimeout = timeoutMs
                s.connect(InetSocketAddress(host, port), timeoutMs)
                s.getOutputStream().apply { write(byteArrayOf(0x05, 0x01, 0x00)); flush() }
                val reply = ByteArray(2)
                var n = 0
                val input = s.getInputStream()
                while (n < 2) {
                    val r = input.read(reply, n, 2 - n)
                    if (r < 0) return@use false
                    n += r
                }
                reply[0] == 0x05.toByte()
            }
        } catch (_: Exception) {
            false
        }
    }
}
