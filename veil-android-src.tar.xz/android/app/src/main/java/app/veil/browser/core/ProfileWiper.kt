package app.veil.browser.core

import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

data class WipeResult(val deleted: Int, val failed: List<String>)

/**
 * Removes the *contents* of directories (never the directories themselves, never anything behind a symlink).
 * Used at every start (before the engine exists) and on panic (for the parts that are not engine-owned).
 *
 * Flash storage and journaling file systems make "secure deletion" a best-effort statement – see docs/SECURITY.md.
 */
object ProfileWiper {
    fun wipeContents(roots: Collection<File>, keep: Set<String> = emptySet()): WipeResult {
        var deleted = 0
        val failed = ArrayList<String>()
        for (root in roots) {
            val rootPath = root.toPath()
            if (!Files.isDirectory(rootPath, LinkOption.NOFOLLOW_LINKS)) continue
            val children = try { Files.newDirectoryStream(rootPath).use { it.toList() } } catch (e: IOException) { failed += root.path; continue }
            for (child in children) {
                if (child.fileName.toString() in keep) continue
                try {
                    deleteTree(child)
                    deleted++
                } catch (e: IOException) {
                    failed += child.toString()
                }
            }
        }
        return WipeResult(deleted, failed)
    }

    private fun deleteTree(path: Path) {
        Files.walkFileTree(path, object : SimpleFileVisitor<Path>() {
            // walkFileTree does not follow symbolic links by default: a link is visited as a file and unlinked.
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.deleteIfExists(file)
                return FileVisitResult.CONTINUE
            }

            override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult = FileVisitResult.CONTINUE

            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                Files.deleteIfExists(dir)
                return FileVisitResult.CONTINUE
            }
        })
    }
}
