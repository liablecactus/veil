package app.veil.browser.ui

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView

enum class FieldKind { Text, Url, Password, Number }

/**
 * Text input for everything the user types in this app (address bar, prompts, exception patterns, passwords).
 *
 * It wraps a platform EditText instead of a Compose text field for one reason: only the platform view can ask the
 * keyboard not to learn what is typed (IME_FLAG_NO_PERSONALIZED_LEARNING – "incognito keyboard"). In a privacy
 * browser the keyboard's personal dictionary must not collect visited URLs and search terms. Keyboards are free to
 * ignore the flag; Gboard, SwiftKey and AOSP's LatinIME honour it.
 */
@Composable
fun PrivateTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    hint: String = "",
    kind: FieldKind = FieldKind.Text,
    focusOnShow: Boolean = false,
    selectAllOnFocus: Boolean = false,
    sizeSp: Float = 16f,
    onGo: (() -> Unit)? = null,
) {
    val c = V.c
    val change by rememberUpdatedState(onValueChange)
    val go by rememberUpdatedState(onGo)
    var field by remember { mutableStateOf<EditText?>(null) }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            EditText(ctx).apply {
                background = null
                setPadding(0, 0, 0, 0)
                setSingleLine(true)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
                isLongClickable = true
                importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO
                inputType = when (kind) {
                    FieldKind.Text -> InputType.TYPE_CLASS_TEXT
                    FieldKind.Url -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                    FieldKind.Password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    FieldKind.Number -> InputType.TYPE_CLASS_NUMBER
                }
                imeOptions = (if (onGo != null) EditorInfo.IME_ACTION_GO else EditorInfo.IME_ACTION_DONE) or
                    EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                    override fun afterTextChanged(s: Editable?) { change(s?.toString().orEmpty()) }
                })
                setOnEditorActionListener { _, actionId, _ ->
                    if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { go?.invoke(); true } else false
                }
                field = this
            }
        },
        update = { et ->
            et.setTextColor(c.text.toArgb())
            et.setHintTextColor(c.textFaint.toArgb())
            et.highlightColor = c.accent.copy(alpha = 0.35f).toArgb()
            et.hint = hint
            if (et.text.toString() != value) {
                et.setText(value)
                et.setSelection(et.text.length)
            }
        },
        onRelease = { it.setOnEditorActionListener(null); field = null },
    )

    LaunchedEffect(field, focusOnShow) {
        val et = field ?: return@LaunchedEffect
        if (!focusOnShow) return@LaunchedEffect
        et.requestFocus()
        if (selectAllOnFocus) et.selectAll()
        val imm = et.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
    }
}

/** Opaque layers must swallow touches, otherwise they fall through to the web view underneath. */
fun Modifier.blockTouches(): Modifier = pointerInput(Unit) { detectTapGestures { } }
