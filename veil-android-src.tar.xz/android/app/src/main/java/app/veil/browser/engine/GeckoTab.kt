package app.veil.browser.engine

import android.content.Context
import android.net.Uri
import app.veil.browser.core.BLANK_URL
import app.veil.browser.core.ChoiceOption
import app.veil.browser.core.ContentKind
import app.veil.browser.core.Decision
import app.veil.browser.core.ErrorPage
import app.veil.browser.core.FilePickRequest
import app.veil.browser.core.Omnibox
import app.veil.browser.core.PermissionKind
import app.veil.browser.core.PermissionPolicy
import app.veil.browser.core.PromptBroker
import app.veil.browser.core.RuleKey
import app.veil.browser.core.Setting
import app.veil.browser.core.SiteRules
import app.veil.browser.core.TabState
import app.veil.browser.core.TorState
import app.veil.browser.core.UiMessage
import app.veil.browser.core.UiPrompt
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.ContentPermission
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.MediaSource
import org.mozilla.geckoview.GeckoSession.PromptDelegate
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebRequestError
import org.mozilla.geckoview.WebResponse

/** What a tab needs from the rest of the app. Kept narrow so tabs stay easy to reason about. */
interface TabEnv {
    val appContext: Context
    val runtime: GeckoRuntime
    val prompts: PromptBroker
    val language: String
    fun rulesFor(host: String?): SiteRules
    fun rememberRule(host: String, key: RuleKey, value: Setting)
    fun update(id: Long, f: (TabState) -> TabState)
    /** A page opened a window: return the (unopened) session for it, or null to refuse. */
    fun newChildSession(parent: GeckoTab, uri: String?): GeckoSession?
    fun openInNewTab(url: String, parent: Long)
    fun closeTab(id: Long)
    fun requestAndroidPermissions(permissions: List<String>, done: (Boolean) -> Unit)
    fun requestFile(request: FilePickRequest)
    fun torState(): TorState
    val torPort: Int

    /** The proxy is Veil's own tor (not Orbot or another external one). */
    val torEmbedded: Boolean
    fun onFullscreen(id: Long, on: Boolean)
    fun message(msg: UiMessage)

    /** The tab closed and reopened its session (crash recovery): the view has to attach to it again. */
    fun sessionReopened(id: Long)
}

/**
 * One tab = one private GeckoSession plus the delegates that translate engine events into [TabState]
 * updates, site-rule decisions and prompts. All callbacks arrive on the UI thread.
 */
class GeckoTab(val id: Long, val session: GeckoSession, private val env: TabEnv, openNow: Boolean) {
    @Volatile private var lastUrl: String = BLANK_URL
    private var scriptReloadFor: String? = null
    private var closed = false
    private var recoveries = 0

    // ---------------------------------------------------------------------------------------- commands

    fun load(url: String) {
        lastUrl = url
        syncJavascript(url)
        session.load(GeckoSession.Loader().uri(url))
    }

    fun reload() = session.reload()
    fun stop() = session.stop()
    fun goBack() = session.goBack()
    fun goForward() = session.goForward()
    fun exitFullscreen() { if (session.isOpen) session.exitFullScreen() }

    fun setDesktopSite(on: Boolean) {
        session.settings.userAgentMode = if (on) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        session.settings.viewportMode = if (on) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        env.update(id) { it.copy(desktopSite = on) }
        session.reload()
    }

    fun setActive(active: Boolean) {
        if (session.isOpen) {
            session.setActive(active)
            if (active) session.setFocused(true)
        }
    }

    /** Re-evaluates the JavaScript rule for the current page (after the user changed it in the site sheet). */
    fun applyRulesAndReload() {
        val url = lastUrl
        if (syncJavascript(url)) session.reload()
    }

    fun close() {
        closed = true
        env.prompts.cancelOwned(id)
        if (session.isOpen) session.close()
    }

    private fun post(p: UiPrompt) = env.prompts.post(p, owner = id)

    private fun originOf(url: String) = Omnibox.hostOf(url) ?: url

    /** Returns true when the session setting changed (and a reload is needed for it to take effect). */
    private fun syncJavascript(url: String): Boolean {
        val host = Omnibox.hostOf(url) ?: return false
        val allow = env.rulesFor(host).javascript != Setting.BLOCK
        env.update(id) { it.copy(scriptsBlocked = !allow) }
        if (session.settings.allowJavascript == allow) return false
        session.settings.allowJavascript = allow
        return true
    }

    // ----------------------------------------------------------------------------------------- navigation

    private val navigation = object : GeckoSession.NavigationDelegate {
        override fun onLocationChange(
            session: GeckoSession,
            url: String?,
            perms: List<ContentPermission>,
            hasUserGesture: Boolean,
        ) {
            val u = url ?: BLANK_URL
            lastUrl = u
            env.update(id) { it.copy(url = u, trackersBlocked = if (it.url == u) it.trackersBlocked else 0) }
            // The setting is applied when a load starts; if the page we landed on (redirects!) has another
            // rule, fix it up once and reload. The guard prevents reload loops.
            if (syncJavascript(u) && scriptReloadFor != u) {
                scriptReloadFor = u
                session.reload()
            }
        }

        override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) = env.update(id) { it.copy(canGoBack = canGoBack) }
        override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) = env.update(id) { it.copy(canGoForward = canGoForward) }

        override fun onLoadRequest(session: GeckoSession, request: GeckoSession.NavigationDelegate.LoadRequest): GeckoResult<AllowOrDeny>? {
            val scheme = request.uri.substringBefore(':', "").lowercase()
            // Pages must not be able to hand the user over to other apps (intent:, market:, tel:, …) or to engine internals.
            val ok = scheme == "http" || scheme == "https" || scheme == "blob" || scheme == "moz-extension" ||
                request.uri.equals(BLANK_URL, ignoreCase = true)
            if (!ok) return GeckoResult.fromValue(AllowOrDeny.DENY)
            syncJavascript(request.uri)
            return GeckoResult.fromValue(AllowOrDeny.ALLOW)
        }

        override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? =
            GeckoResult.fromValue<GeckoSession>(env.newChildSession(this@GeckoTab, uri))

        override fun onLoadError(session: GeckoSession, uri: String?, error: WebRequestError): GeckoResult<String>? {
            val tor = env.torState()
            val html = ErrorPage.html(uri, tor.routed, env.torPort, env.language, env.torEmbedded, describe(error))
            return GeckoResult.fromValue("data:text/html;charset=utf-8," + Uri.encode(html))
        }

        /** The engine's error constant name (e.g. ERROR_UNKNOWN_HOST) plus its category, looked up by value. Never throws. */
        private fun describe(error: WebRequestError): String = try {
            fun nameOf(prefix: String, value: Int, categories: Boolean): String? =
                WebRequestError::class.java.fields.firstOrNull { f ->
                    f.type == Int::class.javaPrimitiveType && f.name.startsWith(prefix) &&
                        f.name.startsWith("ERROR_CATEGORY_") == categories && f.getInt(null) == value
                }?.name
            val code = nameOf("ERROR_", error.code, categories = false) ?: "code ${error.code}"
            val category = nameOf("ERROR_CATEGORY_", error.category, categories = true) ?: "category ${error.category}"
            "$code · $category"
        } catch (_: Throwable) {
            "code ${error.code}"
        }
    }

    // ------------------------------------------------------------------------------------------- progress

    private val progress = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(session: GeckoSession, url: String) =
            env.update(id) { it.copy(loading = true, progress = 5, crashed = false, trackersBlocked = 0) }

        override fun onPageStop(session: GeckoSession, success: Boolean) =
            env.update(id) { it.copy(loading = false, progress = 0) }

        override fun onProgressChange(session: GeckoSession, progress: Int) =
            env.update(id) { it.copy(progress = progress.coerceIn(0, 100)) }

        override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) =
            env.update(id) { it.copy(secure = securityInfo.isSecure) }
    }

    // -------------------------------------------------------------------------------------------- content

    private val content = object : GeckoSession.ContentDelegate {
        override fun onTitleChange(session: GeckoSession, title: String?) = env.update(id) { it.copy(title = title.orEmpty()) }
        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) = env.onFullscreen(id, fullScreen)
        override fun onCloseRequest(session: GeckoSession) = env.closeTab(id)

        override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
            // Downloads would write to disk, which this browser refuses on principle.
            runCatching { response.body?.close() }
            env.message(UiMessage(UiMessage.Kind.DOWNLOAD_BLOCKED))
        }

        override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {
            val link = element.linkUri?.takeIf { Omnibox.hostOf(it) != null }
            val image = element.srcUri?.takeIf { Omnibox.hostOf(it) != null }
            if (link == null && image == null) return
            val pid = env.prompts.nextId()
            post(UiPrompt.ContextMenu(pid, originOf(lastUrl), link, image,
                openInNewTab = { env.openInNewTab(it, id) }, cancel = {}))
        }

        override fun onCrash(session: GeckoSession) = recover()
        override fun onKill(session: GeckoSession) = recover()

        private fun recover() {
            // a late crash callback of a tab that was closed (panic, identity reset) must not bring its session back
            if (closed) return
            env.update(id) { it.copy(crashed = true, loading = false, progress = 0) }
            // crash loop: stop reloading and leave the crash page up, the user decides
            if (++recoveries > 3) return
            session.close()
            session.open(env.runtime)
            env.sessionReopened(id)
            if (lastUrl != BLANK_URL) session.load(GeckoSession.Loader().uri(lastUrl))
        }
    }

    private val blocking = object : ContentBlocking.Delegate {
        override fun onContentBlocked(session: GeckoSession, event: ContentBlocking.BlockEvent) =
            env.update(id) { it.copy(trackersBlocked = it.trackersBlocked + 1) }
    }

    // ---------------------------------------------------------------------------------------- permissions

    private val permissions = object : GeckoSession.PermissionDelegate {
        override fun onAndroidPermissionsRequest(
            session: GeckoSession,
            permissions: Array<out String>?,
            callback: GeckoSession.PermissionDelegate.Callback,
        ) {
            env.requestAndroidPermissions(permissions.orEmpty().toList()) { granted -> if (granted) callback.grant() else callback.reject() }
        }

        override fun onContentPermissionRequest(session: GeckoSession, perm: ContentPermission): GeckoResult<Int>? {
            val host = Omnibox.hostOf(perm.uri) ?: return GeckoResult.fromValue(ContentPermission.VALUE_DENY)
            val kind = when (perm.permission) {
                GeckoSession.PermissionDelegate.PERMISSION_GEOLOCATION -> ContentKind.GEOLOCATION
                GeckoSession.PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> ContentKind.NOTIFICATIONS
                GeckoSession.PermissionDelegate.PERMISSION_STORAGE_ACCESS -> ContentKind.STORAGE_ACCESS
                GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE -> ContentKind.AUTOPLAY_INAUDIBLE
                GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE -> ContentKind.AUTOPLAY_AUDIBLE
                else -> ContentKind.OTHER
            }
            return when (PermissionPolicy.decideContent(env.rulesFor(host), kind)) {
                Decision.ALLOW -> GeckoResult.fromValue(ContentPermission.VALUE_ALLOW)
                Decision.BLOCK -> GeckoResult.fromValue(ContentPermission.VALUE_DENY)
                Decision.ASK -> {
                    val pk = when (kind) {
                        ContentKind.GEOLOCATION -> PermissionKind.GEOLOCATION
                        else -> PermissionKind.NOTIFICATIONS
                    }
                    val result = GeckoResult<Int>()
                    post(UiPrompt.Permission(env.prompts.nextId(), host, listOf(pk),
                        done = { allow, remember ->
                            if (remember) PermissionPolicy.keysFor(kind).forEach { env.rememberRule(host, it, if (allow) Setting.ALLOW else Setting.BLOCK) }
                            result.complete(if (allow) ContentPermission.VALUE_ALLOW else ContentPermission.VALUE_DENY)
                        },
                        cancel = { result.complete(ContentPermission.VALUE_DENY) }))
                    result
                }
            }
        }

        override fun onMediaPermissionRequest(
            session: GeckoSession,
            uri: String,
            video: Array<out MediaSource>?,
            audio: Array<out MediaSource>?,
            callback: GeckoSession.PermissionDelegate.MediaCallback,
        ) {
            val host = Omnibox.hostOf(uri)
            val cam = video?.firstOrNull()
            val mic = audio?.firstOrNull()
            if (host == null || (cam == null && mic == null)) { callback.reject(); return }

            fun grantWithAndroidPermissions() {
                val needed = buildList {
                    if (cam != null) add(android.Manifest.permission.CAMERA)
                    if (mic != null) add(android.Manifest.permission.RECORD_AUDIO)
                }
                env.requestAndroidPermissions(needed) { ok -> if (ok) callback.grant(cam, mic) else callback.reject() }
            }

            when (PermissionPolicy.decideMedia(env.rulesFor(host), wantsVideo = cam != null, wantsAudio = mic != null)) {
                Decision.ALLOW -> grantWithAndroidPermissions()
                Decision.BLOCK -> callback.reject()
                Decision.ASK -> {
                    val kinds = buildList { if (cam != null) add(PermissionKind.CAMERA); if (mic != null) add(PermissionKind.MICROPHONE) }
                    post(UiPrompt.Permission(env.prompts.nextId(), host, kinds,
                        done = { allow, remember ->
                            if (remember) PermissionPolicy.keysForMedia(cam != null, mic != null)
                                .forEach { env.rememberRule(host, it, if (allow) Setting.ALLOW else Setting.BLOCK) }
                            if (allow) grantWithAndroidPermissions() else callback.reject()
                        },
                        cancel = { callback.reject() }))
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------- prompts

    private val prompts = object : PromptDelegate {
        private val origin get() = originOf(lastUrl)

        override fun onAlertPrompt(session: GeckoSession, prompt: PromptDelegate.AlertPrompt): GeckoResult<PromptDelegate.PromptResponse> {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            post(UiPrompt.Alert(env.prompts.nextId(), origin, prompt.message.orEmpty(),
                done = { res.complete(prompt.dismiss()) }, cancel = { res.complete(prompt.dismiss()) }))
            return res
        }

        override fun onButtonPrompt(session: GeckoSession, prompt: PromptDelegate.ButtonPrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            post(UiPrompt.Confirm(env.prompts.nextId(), origin, prompt.message.orEmpty(),
                done = { yes -> res.complete(prompt.confirm(if (yes) PromptDelegate.ButtonPrompt.Type.POSITIVE else PromptDelegate.ButtonPrompt.Type.NEGATIVE)) },
                cancel = { res.complete(prompt.dismiss()) }))
            return res
        }

        override fun onTextPrompt(session: GeckoSession, prompt: PromptDelegate.TextPrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            post(UiPrompt.Text(env.prompts.nextId(), origin, prompt.message.orEmpty(), prompt.defaultValue.orEmpty(),
                done = { text -> res.complete(prompt.confirm(text)) }, cancel = { res.complete(prompt.dismiss()) }))
            return res
        }

        override fun onAuthPrompt(session: GeckoSession, prompt: PromptDelegate.AuthPrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            val opts = prompt.authOptions
            val onlyPassword = (opts.flags and PromptDelegate.AuthPrompt.AuthOptions.Flags.ONLY_PASSWORD) != 0
            // the server asking is not necessarily the page in the address bar (cross-origin subresource)
            val asking = opts.uri?.let { Omnibox.hostOf(it) } ?: origin
            post(UiPrompt.Auth(env.prompts.nextId(), asking, needsUser = !onlyPassword, user = opts.username.orEmpty(),
                done = { user, pass -> res.complete(if (onlyPassword) prompt.confirm(pass) else prompt.confirm(user, pass)) },
                cancel = { res.complete(prompt.dismiss()) }))
            return res
        }

        override fun onChoicePrompt(session: GeckoSession, prompt: PromptDelegate.ChoicePrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            val multiple = prompt.type == PromptDelegate.ChoicePrompt.Type.MULTIPLE
            val options = ArrayList<ChoiceOption>()
            fun add(c: PromptDelegate.ChoicePrompt.Choice, indent: String) {
                options += ChoiceOption(c.id, indent + c.label.orEmpty(), c.selected, c.disabled, c.separator)
                c.items?.forEach { add(it, "$indent    ") }
            }
            prompt.choices.forEach { add(it, "") }
            post(UiPrompt.Choice(env.prompts.nextId(), origin, prompt.title.orEmpty(), options, multiple,
                done = { ids ->
                    res.complete(if (multiple) prompt.confirm(ids.toTypedArray()) else ids.firstOrNull()?.let { prompt.confirm(it) } ?: prompt.dismiss())
                },
                cancel = { res.complete(prompt.dismiss()) }))
            return res
        }

        override fun onPopupPrompt(session: GeckoSession, prompt: PromptDelegate.PopupPrompt): GeckoResult<PromptDelegate.PromptResponse> {
            val host = Omnibox.hostOf(lastUrl)
            val allow = host != null && env.rulesFor(host).popups == Setting.ALLOW
            if (!allow && host != null) env.message(UiMessage(UiMessage.Kind.POPUP_BLOCKED, host))
            return GeckoResult.fromValue(prompt.confirm(if (allow) AllowOrDeny.ALLOW else AllowOrDeny.DENY))
        }

        override fun onBeforeUnloadPrompt(session: GeckoSession, prompt: PromptDelegate.BeforeUnloadPrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            // "Leave site?" must never trap the panic button or a tab close: always leave.
            return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW))
        }

        override fun onRepostConfirmPrompt(session: GeckoSession, prompt: PromptDelegate.RepostConfirmPrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            post(UiPrompt.Confirm(env.prompts.nextId(), origin, "", // the UI shows its own fixed repost text
                done = { yes -> res.complete(prompt.confirm(if (yes) AllowOrDeny.ALLOW else AllowOrDeny.DENY)) },
                cancel = { res.complete(prompt.confirm(AllowOrDeny.DENY)) }))
            return res
        }

        override fun onFilePrompt(session: GeckoSession, prompt: PromptDelegate.FilePrompt): GeckoResult<PromptDelegate.PromptResponse>? {
            val res = GeckoResult<PromptDelegate.PromptResponse>()
            val multiple = prompt.type == PromptDelegate.FilePrompt.Type.MULTIPLE
            env.requestFile(FilePickRequest(multiple, prompt.mimeTypes?.toList().orEmpty(),
                done = { uris ->
                    val parsed = uris.map(Uri::parse)
                    res.complete(when {
                        parsed.isEmpty() -> prompt.dismiss()
                        multiple -> prompt.confirm(env.appContext, parsed.toTypedArray())
                        else -> prompt.confirm(env.appContext, parsed.first())
                    })
                },
                cancel = { res.complete(prompt.dismiss()) }))
            return res
        }
    }

    // Delegates are properties declared above: attach them only after all of them exist.
    init {
        session.setNavigationDelegate(navigation)
        session.setProgressDelegate(progress)
        session.setContentDelegate(content)
        session.setPermissionDelegate(permissions)
        session.setPromptDelegate(prompts)
        session.setContentBlockingDelegate(blocking)
        if (openNow) session.open(env.runtime)
    }
}
