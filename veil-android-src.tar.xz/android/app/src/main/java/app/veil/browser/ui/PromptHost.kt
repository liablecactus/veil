package app.veil.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.PermissionKind
import app.veil.browser.core.UiMessage
import app.veil.browser.core.torDetailToken
import app.veil.browser.core.UiPrompt
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.theme.VeilTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

/** Shows the oldest pending prompt (JS dialogs, permissions, auth, <select>, context menu). One at a time. */
@Composable
fun PromptHost(controller: BrowserController) {
    val queue by controller.prompts.queue.collectAsState()
    val head = queue.firstOrNull()
    if (head != null) key(head.id) { PromptDialog(head, controller) }
}

@Composable
private fun PromptDialog(p: UiPrompt, controller: BrowserController) {
    val broker = controller.prompts
    // answer first (completes the engine's pending result), then drop it from the queue
    fun answer(block: () -> Unit) { block(); broker.resolve(p.id) }
    val dismiss = { broker.cancel(p.id) }

    when (p) {
        is UiPrompt.Alert -> PromptFrame(stringResource(R.string.prompt_says, p.origin), dismiss,
            buttons = { VButton(stringResource(R.string.action_ok), { answer { p.done() } }) }) {
            VText(p.message, lineHeight = 22.sp)
        }

        is UiPrompt.Confirm -> PromptFrame(stringResource(R.string.prompt_says, p.origin), dismiss,
            buttons = {
                VButton(stringResource(R.string.action_cancel), { answer { p.done(false) } }, filled = false)
                VButton(stringResource(R.string.action_ok), { answer { p.done(true) } })
            }) {
            VText(p.message, lineHeight = 22.sp)
        }

        is UiPrompt.Text -> {
            var value by remember { mutableStateOf(p.default) }
            PromptFrame(stringResource(R.string.prompt_says, p.origin), dismiss,
                buttons = {
                    VButton(stringResource(R.string.action_cancel), { dismiss() }, filled = false)
                    VButton(stringResource(R.string.action_ok), { answer { p.done(value) } })
                }) {
                if (p.message.isNotBlank()) { VText(p.message, lineHeight = 22.sp); Spacer(Modifier.height(12.dp)) }
                FieldBox { PrivateTextField(value, { value = it }, Modifier.fillMaxWidth(), focusOnShow = true, selectAllOnFocus = true, onGo = { answer { p.done(value) } }) }
            }
        }

        is UiPrompt.Auth -> {
            var user by remember { mutableStateOf(p.user) }
            var pass by remember { mutableStateOf("") }
            PromptFrame(stringResource(R.string.prompt_auth_title, p.origin), dismiss,
                buttons = {
                    VButton(stringResource(R.string.action_cancel), { dismiss() }, filled = false)
                    VButton(stringResource(R.string.prompt_sign_in), { answer { p.done(user, pass) } })
                }) {
                if (p.needsUser) {
                    FieldBox { PrivateTextField(user, { user = it }, Modifier.fillMaxWidth(), hint = stringResource(R.string.prompt_username), focusOnShow = true) }
                    Spacer(Modifier.height(10.dp))
                }
                FieldBox { PrivateTextField(pass, { pass = it }, Modifier.fillMaxWidth(), hint = stringResource(R.string.prompt_password), kind = FieldKind.Password, focusOnShow = !p.needsUser, onGo = { answer { p.done(user, pass) } }) }
            }
        }

        is UiPrompt.Choice -> {
            val picked = remember { mutableStateListOf<String>().also { l -> l.addAll(p.options.filter { it.selected }.map { it.id }) } }
            PromptFrame(p.title.ifBlank { stringResource(R.string.prompt_choose) }, dismiss,
                buttons = {
                    VButton(stringResource(R.string.action_cancel), { dismiss() }, filled = false)
                    if (p.multiple) VButton(stringResource(R.string.action_ok), { answer { p.done(picked.toList()) } })
                }) {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    for (o in p.options) {
                        if (o.separator) { Divider(); continue }
                        val on = o.id in picked
                        Row(
                            Modifier.fillMaxWidth().touchable(
                                onClick = {
                                    if (p.multiple) { if (on) picked.remove(o.id) else picked.add(o.id) } else answer { p.done(listOf(o.id)) }
                                },
                                enabled = !o.disabled, shape = RoundedCornerShape(VeilTokens.RadiusSm), pressedScale = 0.985f,
                            ).padding(horizontal = 8.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            VText(o.label, color = if (o.disabled) V.c.textFaint else V.c.text, modifier = Modifier.weight(1f))
                            if (on) VIcon(VeilIcons.Check, V.c.accent, 20.dp)
                        }
                    }
                }
            }
        }

        is UiPrompt.Permission -> {
            var rememberChoice by remember { mutableStateOf(false) }
            val what = p.kinds.map { stringResource(permissionLabel(it)) }.joinToString(", ")
            PromptFrame(stringResource(R.string.perm_title, p.origin), dismiss,
                buttons = {
                    VButton(stringResource(R.string.perm_block), { answer { p.done(false, rememberChoice) } }, filled = false)
                    VButton(stringResource(R.string.perm_allow), { answer { p.done(true, rememberChoice) } })
                }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VIcon(permissionIcon(p.kinds.firstOrNull()), V.c.accent, 28.dp)
                    Spacer(Modifier.width(14.dp))
                    VText(stringResource(R.string.perm_wants, what), lineHeight = 22.sp, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    VText(stringResource(R.string.perm_remember), color = V.c.textMuted, size = 14.sp, modifier = Modifier.weight(1f))
                    VSwitch(rememberChoice, { rememberChoice = it })
                }
            }
        }

        is UiPrompt.ContextMenu -> {
            val clipboard = LocalClipboardManager.current
            val link = p.linkUri
            val image = p.imageUri
            fun copy(text: String) {
                clipboard.setText(AnnotatedString(text))
                controller.message(UiMessage(UiMessage.Kind.LINK_COPIED))
            }
            PromptFrame((link ?: image).orEmpty().take(80), dismiss, buttons = {}) {
                if (link != null) {
                    MenuRow(VeilIcons.Add, stringResource(R.string.ctx_open_new_tab)) { answer { p.openInNewTab(link) } }
                    MenuRow(VeilIcons.Code, stringResource(R.string.ctx_copy_link)) { answer { copy(link) } }
                }
                if (image != null) MenuRow(VeilIcons.Eye, stringResource(R.string.ctx_copy_image)) { answer { copy(image) } }
            }
        }
    }
}

private fun permissionLabel(k: PermissionKind): Int = when (k) {
    PermissionKind.CAMERA -> R.string.perm_camera
    PermissionKind.MICROPHONE -> R.string.perm_microphone
    PermissionKind.GEOLOCATION -> R.string.perm_geolocation
    PermissionKind.NOTIFICATIONS -> R.string.perm_notifications
}

private fun permissionIcon(k: PermissionKind?) = when (k) {
    PermissionKind.CAMERA -> VeilIcons.Eye
    PermissionKind.MICROPHONE -> VeilIcons.Volume
    PermissionKind.GEOLOCATION -> VeilIcons.Globe
    PermissionKind.NOTIFICATIONS -> VeilIcons.Info
    null -> VeilIcons.Info
}

@Composable
private fun PromptFrame(title: String, onDismiss: () -> Unit, buttons: @Composable () -> Unit, content: @Composable () -> Unit) {
    VDialog(onDismiss) {
        VText(title, size = 17.sp, weight = FontWeight.Medium, maxLines = 2)
        Spacer(Modifier.height(14.dp))
        content()
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) { buttons() }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().touchable(onClick, shape = RoundedCornerShape(VeilTokens.RadiusMd), pressedScale = 0.985f).padding(horizontal = 8.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        VIcon(icon, V.c.textMuted, 22.dp)
        Spacer(Modifier.width(16.dp))
        VText(label, modifier = Modifier.weight(1f))
    }
}

/** Rounded input surface used behind every [PrivateTextField]. */
@Composable
fun FieldBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.fillMaxWidth().clip(RoundedCornerShape(VeilTokens.RadiusMd)).background(V.c.surface).padding(horizontal = 14.dp, vertical = 12.dp)) { content() }
}

// ------------------------------------------------------------------------------------------------ notices

/** Short notices at the bottom (download blocked, panic done, Tor state …). New notices replace the current one. */
@Composable
fun MessageHost(controller: BrowserController, modifier: Modifier = Modifier) {
    var current by remember { mutableStateOf<UiMessage?>(null) }
    var last by remember { mutableStateOf<UiMessage?>(null) }

    LaunchedEffect(controller) {
        controller.messages.collectLatest { m ->
            last = m
            current = m
            delay(2800)
            current = null
        }
    }

    AnimatedVisibility(
        visible = current != null,
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars).padding(16.dp),
        enter = fadeIn(tween(VeilTokens.MotionBase)) + slideInVertically(tween(VeilTokens.MotionSlow, easing = VeilTokens.EaseOut)) { it / 2 },
        exit = fadeOut(tween(VeilTokens.MotionBase)) + slideOutVertically(tween(VeilTokens.MotionBase)) { it / 2 },
    ) {
        val m = last
        if (m != null) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(VeilTokens.RadiusLg))
                    .background(V.c.surfaceActive)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                VText(messageText(m), size = 14.sp, maxLines = 3)
            }
        }
    }
}

@Composable
private fun messageText(m: UiMessage): String {
    val arg = m.arg.orEmpty()
    return when (m.kind) {
        UiMessage.Kind.DOWNLOAD_BLOCKED -> stringResource(R.string.msg_download_blocked)
        UiMessage.Kind.POPUP_BLOCKED -> stringResource(R.string.msg_popup_blocked)
        UiMessage.Kind.PANIC_DONE -> stringResource(R.string.msg_panic_done)
        UiMessage.Kind.PANIC_PARTIAL -> stringResource(R.string.msg_panic_partial)
        UiMessage.Kind.TOR_ON -> stringResource(R.string.msg_tor_on)
        UiMessage.Kind.TOR_OFF -> stringResource(R.string.msg_tor_off)
        UiMessage.Kind.TOR_UNREACHABLE -> stringResource(R.string.msg_tor_unreachable)
        UiMessage.Kind.TOR_STARTING -> stringResource(R.string.msg_tor_starting)
        UiMessage.Kind.TOR_START_FAILED -> torDetailText(m.arg)
        UiMessage.Kind.EXTENSION_FAILED -> if (arg.isBlank()) stringResource(R.string.msg_extension_failed_generic) else stringResource(R.string.msg_extension_failed, arg)
        UiMessage.Kind.EXTENSION_INSTALLED -> stringResource(R.string.msg_extension_installed)
        UiMessage.Kind.LINK_COPIED -> stringResource(R.string.msg_link_copied)
        UiMessage.Kind.ONION_NEEDS_TOR -> stringResource(R.string.msg_onion_needs_tor, arg)
    }
}

/** Localized explanation for a [app.veil.browser.core.TorState.detail] token (embedded tor failures). */
@Composable
fun torDetailText(detail: String?): String = when (torDetailToken(detail)) {
    "engine-missing" -> stringResource(R.string.tor_err_missing)
    "bootstrap-timeout" -> stringResource(R.string.tor_err_timeout)
    "engine-exited" -> stringResource(R.string.tor_err_exited)
    "engine-failed" -> stringResource(R.string.tor_err_failed)
    else -> detail ?: stringResource(R.string.tor_err_failed)
}
