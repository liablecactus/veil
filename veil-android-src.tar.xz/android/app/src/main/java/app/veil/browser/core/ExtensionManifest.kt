package app.veil.browser.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject

enum class ExtensionProblem {
    /** No `browser_specific_settings.gecko.id`: Gecko cannot install it as a built-in. Run tools/crx2gecko.mjs. */
    NO_GECKO_ID,

    /** `background.service_worker` only: Gecko MV3 uses event pages (`background.scripts`). */
    SERVICE_WORKER_ONLY,
    UNSUPPORTED_MANIFEST_VERSION,
}

data class ExtensionInfo(
    val id: String?,
    val name: String,
    val version: String,
    val manifestVersion: Int,
    val defaultLocale: String?,
    val permissions: List<String>,
    val hostPermissions: List<String>,
    val problems: List<ExtensionProblem>,
) {
    val installable: Boolean get() = problems.isEmpty()
}

/** Reads what the app needs to know about a bundled extension. Lenient: garbage in → null, never an exception. */
object ExtensionManifest {
    fun parse(manifestJson: String, messagesJson: String? = null): ExtensionInfo? {
        val m = try { Json.parseToJsonElement(manifestJson).jsonObject } catch (_: Exception) { return null }
        val mv = (m["manifest_version"] as? JsonPrimitive)?.intOrNull ?: return null
        val rawName = (m["name"] as? JsonPrimitive)?.contentOrNull ?: return null
        val version = (m["version"] as? JsonPrimitive)?.contentOrNull ?: "0"

        val messages = messagesJson?.let { try { Json.parseToJsonElement(it).jsonObject } catch (_: Exception) { null } }
        val name = localized(rawName, messages).take(120)

        val gecko = ((m["browser_specific_settings"] ?: m["applications"]) as? JsonObject)?.get("gecko") as? JsonObject
        val id = (gecko?.get("id") as? JsonPrimitive)?.contentOrNull?.takeIf { validId(it) }

        val problems = ArrayList<ExtensionProblem>()
        if (mv != 2 && mv != 3) problems += ExtensionProblem.UNSUPPORTED_MANIFEST_VERSION
        if (id == null) problems += ExtensionProblem.NO_GECKO_ID
        val bg = m["background"] as? JsonObject
        if (bg != null && bg["service_worker"] != null && bg["scripts"] == null && bg["page"] == null) {
            problems += ExtensionProblem.SERVICE_WORKER_ONLY
        }
        return ExtensionInfo(
            id = id,
            name = name,
            version = version.take(40),
            manifestVersion = mv,
            defaultLocale = (m["default_locale"] as? JsonPrimitive)?.contentOrNull?.takeIf { Regex("^[A-Za-z_]{2,12}$").matches(it) },
            permissions = strings(m["permissions"]),
            hostPermissions = strings(m["host_permissions"]),
            problems = problems,
        )
    }

    /** `name@domain` or a `{uuid}` – the two shapes Gecko accepts. */
    fun validId(id: String): Boolean =
        id.length <= 100 && (Regex("^[A-Za-z0-9._+-]+@[A-Za-z0-9.-]+$").matches(id) || Regex("^\\{[0-9a-fA-F-]{36}}$").matches(id))

    private fun strings(e: Any?): List<String> {
        val arr = e as? JsonArray ?: return emptyList()
        return arr.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.take(200)
    }

    private fun localized(raw: String, messages: JsonObject?): String {
        val m = Regex("^__MSG_(.+)__$").find(raw) ?: return raw
        val key = m.groupValues[1]
        val entry = messages?.entries?.firstOrNull { it.key.equals(key, ignoreCase = true) }?.value as? JsonObject
        return (entry?.get("message") as? JsonPrimitive)?.contentOrNull ?: key
    }
}
