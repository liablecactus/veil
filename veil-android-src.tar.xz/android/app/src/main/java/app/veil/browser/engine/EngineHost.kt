package app.veil.browser.engine

import android.content.Context
import app.veil.browser.core.AppSettings
import app.veil.browser.core.GeckoConfigFile
import app.veil.browser.core.HardeningPrefs
import app.veil.browser.core.Setting
import app.veil.browser.core.ThemeChoice
import app.veil.browser.core.TorMode
import java.io.File
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

/** Creates and reconfigures the one GeckoRuntime of the main process. */
object EngineHost {
    /** `BLOCK` = no third-party cookies at all; `ALLOW` = allowed but partitioned per top-level site (Total Cookie Protection). */
    fun cookieBehavior(thirdParty: Setting): Int =
        if (thirdParty == Setting.ALLOW) ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
        else ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY

    private fun colorScheme(theme: ThemeChoice, systemDark: Boolean): Int = when (theme) {
        ThemeChoice.DARK -> GeckoRuntimeSettings.COLOR_SCHEME_DARK
        ThemeChoice.LIGHT -> GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
        ThemeChoice.SYSTEM -> if (systemDark) GeckoRuntimeSettings.COLOR_SCHEME_DARK else GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
    }

    /**
     * Writes the startup preference file *before* the engine exists: privacy baseline and, when Tor autostart is on,
     * the SOCKS5 proxy prefs – so there is no window in which the first request could go out directly.
     */
    fun writeStartupConfig(file: File, s: AppSettings) {
        val prefs = LinkedHashMap<String, Any>(HardeningPrefs.baseline)
        if (s.tor.autoStart) {
            // embedded: tor is not running yet, so the proxy points at a port nobody can listen on until it is (see TorController)
            if (s.tor.mode == TorMode.EMBEDDED) prefs.putAll(HardeningPrefs.torOn(HardeningPrefs.TOR_HOST, HardeningPrefs.TOR_BLOCKED_PORT))
            else prefs.putAll(HardeningPrefs.torOn(s.tor.host, s.tor.port))
        }
        file.parentFile?.mkdirs()
        file.writeText(GeckoConfigFile.render(prefs))
    }

    fun createRuntime(app: Context, s: AppSettings, thirdPartyCookies: Setting, configFile: File, systemDark: Boolean): GeckoRuntime {
        val cookies = cookieBehavior(thirdPartyCookies)
        val blocking = ContentBlocking.Settings.Builder()
            .antiTracking(if (s.strictTrackingProtection) ContentBlocking.AntiTracking.STRICT else ContentBlocking.AntiTracking.DEFAULT)
            .enhancedTrackingProtectionLevel(if (s.strictTrackingProtection) ContentBlocking.EtpLevel.STRICT else ContentBlocking.EtpLevel.DEFAULT)
            .safeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)
            .cookieBehavior(cookies)
            .cookieBehaviorPrivateMode(cookies)
            .cookiePurging(true)
            .strictSocialTrackingProtection(s.strictTrackingProtection)
            .emailTrackerBlockingPrivateMode(true)
            .queryParameterStrippingEnabled(true)
            .queryParameterStrippingPrivateBrowsingEnabled(true)
            .build()

        val runtimeSettings = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .remoteDebuggingEnabled(false)
            .aboutConfigEnabled(false)
            .consoleOutput(false)
            .debugLogging(false)
            .loginAutofillEnabled(false)
            .globalPrivacyControlEnabled(s.globalPrivacyControl)
            .allowInsecureConnections(if (s.httpsOnly) GeckoRuntimeSettings.HTTPS_ONLY else GeckoRuntimeSettings.ALLOW_ALL)
            .preferredColorScheme(colorScheme(s.theme, systemDark))
            .contentBlocking(blocking)
            .configFilePath(configFile.absolutePath)
            .build()
        // no crash handler on purpose: no crash report ever leaves the device
        return GeckoRuntime.create(app, runtimeSettings)
    }

    /** Applies changed settings to the running engine (everything here is switchable without a restart). */
    fun apply(runtime: GeckoRuntime, s: AppSettings, thirdPartyCookies: Setting, systemDark: Boolean) {
        val cookies = cookieBehavior(thirdPartyCookies)
        val rs = runtime.settings
        rs.setPreferredColorScheme(colorScheme(s.theme, systemDark))
        rs.setAllowInsecureConnections(if (s.httpsOnly) GeckoRuntimeSettings.HTTPS_ONLY else GeckoRuntimeSettings.ALLOW_ALL)
        rs.setGlobalPrivacyControl(s.globalPrivacyControl)
        rs.contentBlocking
            .setCookieBehavior(cookies)
            .setCookieBehaviorPrivateMode(cookies)
            .setAntiTracking(if (s.strictTrackingProtection) ContentBlocking.AntiTracking.STRICT else ContentBlocking.AntiTracking.DEFAULT)
            .setEnhancedTrackingProtectionLevel(if (s.strictTrackingProtection) ContentBlocking.EtpLevel.STRICT else ContentBlocking.EtpLevel.DEFAULT)
            .setStrictSocialTrackingProtection(s.strictTrackingProtection)
    }

    /** Every tab is a private session: cookies/cache/history stay in RAM, tracking protection follows the setting. */
    fun newSession(strictTracking: Boolean): GeckoSession {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(true)
            .useTrackingProtection(strictTracking)
            .allowJavascript(true)
            .suspendMediaWhenInactive(true)
            .build()
        return GeckoSession(settings)
    }
}
