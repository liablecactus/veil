@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)

package app.veil.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import app.veil.browser.R
import app.veil.browser.core.TabState
import app.veil.browser.core.TorPhase
import app.veil.browser.core.TorState
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.theme.VeilTokens
import kotlin.math.abs
import kotlinx.coroutines.launch

/**
 * Chrome-like top bar: [panic] [address pill] [tor] [tabs] [menu].
 * While the address is being edited the pill takes the whole row (the other buttons fold away).
 */
@Composable
fun TopBar(
    controller: BrowserController,
    tab: TabState?,
    tabCount: Int,
    tor: TorState,
    onOpenTabs: () -> Unit,
    onOpen: (Route) -> Unit,
) {
    var editing by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var focusAfterNewTab by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current

    fun startEditing() {
        text = if (tab == null || tab.isBlank) "" else tab.url
        editing = true
    }
    fun stopEditing() {
        editing = false
        keyboard?.hide()
    }

    // switching tabs always ends an edit; a brand-new tab opens straight into the address field (declared in this order)
    LaunchedEffect(tab?.id) { editing = false }
    LaunchedEffect(tab?.id, focusAfterNewTab) {
        if (focusAfterNewTab && tab?.isBlank == true) {
            focusAfterNewTab = false
            startEditing()
        }
    }

    androidx.activity.compose.BackHandler(enabled = editing) { stopEditing() }

    Row(
        Modifier.fillMaxWidth().background(V.c.toolbar).windowInsetsPadding(WindowInsets.statusBars).height(56.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SideSlot(visible = !editing) { PanicButton(onClick = controller::triggerPanic) }

        AddressPill(
            tab = tab,
            tabCount = tabCount,
            editing = editing,
            text = text,
            onText = { text = it },
            onStartEdit = ::startEditing,
            onSubmit = {
                val input = text
                stopEditing()
                controller.navigate(input)
            },
            onSite = { tab?.host?.let { onOpen(Route.SiteHost(it)) } },
            onSwipeTab = controller::selectRelative,
            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
        )

        SideSlot(visible = !editing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TorButton(tor, onClick = controller::toggleTor)
                TabCountButton(tabCount, onOpenTabs)
                Box {
                    IconBtn(VeilIcons.More, stringResource(R.string.action_menu), { menuOpen = true })
                    if (menuOpen) {
                        MenuPopup(
                            controller = controller,
                            tab = tab,
                            onDismiss = { menuOpen = false },
                            onNewTab = { controller.newTab(); focusAfterNewTab = true },
                            onOpen = onOpen,
                        )
                    }
                }
            }
        }
        SideSlot(visible = editing) { IconBtn(VeilIcons.Close, stringResource(R.string.action_cancel), ::stopEditing) }
    }
}

/** A group of buttons that folds in/out horizontally with a fade. */
@Composable
private fun SideSlot(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(VeilTokens.MotionBase)) + expandHorizontally(tween(VeilTokens.MotionBase, easing = VeilTokens.EaseOut), expandFrom = Alignment.CenterHorizontally),
        exit = fadeOut(tween(VeilTokens.MotionFast)) + shrinkHorizontally(tween(VeilTokens.MotionBase, easing = VeilTokens.EaseOut), shrinkTowards = Alignment.CenterHorizontally),
    ) { content() }
}

// ------------------------------------------------------------------------------------------------------ buttons

/** One tap, no confirmation: wipes cookies, caches, all tabs and lands on about:blank. */
@Composable
private fun PanicButton(onClick: () -> Unit) {
    val haptics = LocalHapticFeedback.current
    IconBtn(
        icon = VeilIcons.Bolt,
        description = stringResource(R.string.panic_button),
        onClick = {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            onClick()
        },
        tint = V.c.danger,
        background = V.c.danger.copy(alpha = 0.16f),
    )
}

@Composable
private fun TorButton(tor: TorState, onClick: () -> Unit) {
    val connecting = tor.phase == TorPhase.CONNECTING
    val bg by animateColorAsState(
        when (tor.phase) {
            TorPhase.ON -> V.c.tor
            TorPhase.UNREACHABLE -> V.c.warn.copy(alpha = 0.22f)
            TorPhase.CONNECTING -> V.c.tor.copy(alpha = 0.30f)
            TorPhase.OFF -> Color.Transparent
        },
        tween(VeilTokens.MotionBase), label = "tor-bg",
    )
    val fg by animateColorAsState(
        when (tor.phase) {
            TorPhase.ON -> V.c.torOn
            TorPhase.UNREACHABLE -> V.c.warn
            TorPhase.CONNECTING -> V.c.tor
            TorPhase.OFF -> V.c.textMuted
        },
        tween(VeilTokens.MotionBase), label = "tor-fg",
    )
    // the infinite animation only exists while connecting, so an idle button costs no frames
    val pulse: State<Float> = if (connecting) {
        rememberInfiniteTransition(label = "tor-pulse").animateFloat(0.35f, 1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "tor-pulse-a")
    } else remember { mutableStateOf(1f) }
    val state = when (tor.phase) {
        TorPhase.ON -> stringResource(R.string.tor_state_on)
        TorPhase.CONNECTING -> stringResource(R.string.tor_state_connecting)
        TorPhase.UNREACHABLE -> stringResource(R.string.tor_state_unreachable)
        TorPhase.OFF -> stringResource(R.string.tor_state_off)
    }
    Box(Modifier.graphicsLayer { alpha = pulse.value }) {
        IconBtn(VeilIcons.Onion, stringResource(R.string.tor_toggle, state), onClick, tint = fg, background = bg)
    }
}

@Composable
private fun TabCountButton(count: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).touchable(onClick, shape = CircleShape, description = stringResource(R.string.tabs_open, count)),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(24.dp).border(2.dp, V.c.text, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            VText(minOf(count, 99).toString(), size = 12.sp, weight = FontWeight.Bold, maxLines = 1)
        }
    }
}

// ------------------------------------------------------------------------------------------------ address pill

private fun displayUrl(tab: TabState?): String = when {
    tab == null || tab.isBlank -> ""
    tab.host != null -> tab.host!!
    else -> tab.url.take(60)
}

@Composable
private fun AddressPill(
    tab: TabState?,
    tabCount: Int,
    editing: Boolean,
    text: String,
    onText: (String) -> Unit,
    onStartEdit: () -> Unit,
    onSubmit: () -> Unit,
    onSite: () -> Unit,
    onSwipeTab: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val swipe = remember { Animatable(0f) }
    val threshold = with(LocalDensity.current) { 56.dp.toPx() }
    val outline by animateColorAsState(if (editing) V.c.accent else Color.Transparent, tween(VeilTokens.MotionBase), label = "pill-outline")
    val pill = RoundedCornerShape(VeilTokens.RadiusPill)

    val icon = when {
        tab == null || tab.isBlank -> VeilIcons.Search
        tab.isOnion -> VeilIcons.Onion
        tab.secure -> VeilIcons.Lock
        else -> VeilIcons.Warning
    }
    val iconTint = when {
        tab == null || tab.isBlank -> V.c.textMuted
        tab.isOnion -> V.c.tor
        tab.secure -> V.c.textMuted
        else -> V.c.warn
    }

    Row(
        modifier
            .height(40.dp)
            .graphicsLayer { translationX = swipe.value }
            .clip(pill)
            .background(V.c.surface)
            .border(1.5.dp, outline, pill)
            .pointerInput(tabCount, editing) {
                if (editing || tabCount < 2) return@pointerInput
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val v = swipe.value
                        scope.launch {
                            if (abs(v) > threshold) onSwipeTab(if (v < 0) 1 else -1)
                            swipe.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium))
                        }
                    },
                    onDragCancel = { scope.launch { swipe.animateTo(0f, spring()) } },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        scope.launch { swipe.snapTo((swipe.value + dx * 0.5f).coerceIn(-threshold * 1.6f, threshold * 1.6f)) }
                    },
                )
            },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp).touchable(onSite, enabled = !editing && tab?.host != null, shape = CircleShape, description = stringResource(R.string.site_info)),
            contentAlignment = Alignment.Center,
        ) { VIcon(icon, iconTint, 18.dp) }

        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
            if (editing) {
                PrivateTextField(
                    value = text,
                    onValueChange = onText,
                    modifier = Modifier.fillMaxWidth(),
                    hint = stringResource(R.string.omnibox_hint),
                    kind = FieldKind.Url,
                    focusOnShow = true,
                    selectAllOnFocus = true,
                    onGo = onSubmit,
                )
            } else {
                val shown = displayUrl(tab)
                Box(
                    Modifier.fillMaxWidth().fillMaxHeight().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onStartEdit),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (shown.isEmpty()) VText(stringResource(R.string.omnibox_hint), color = V.c.textFaint, maxLines = 1)
                    else VText(shown, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
    }
}

// ------------------------------------------------------------------------------------------------------ menu

@Composable
private fun MenuPopup(
    controller: BrowserController,
    tab: TabState?,
    onDismiss: () -> Unit,
    onNewTab: () -> Unit,
    onOpen: (Route) -> Unit,
) {
    val appear = remember { MutableTransitionState(false).apply { targetState = true } }
    val shape = RoundedCornerShape(VeilTokens.RadiusLg)

    fun act(block: () -> Unit): () -> Unit = { onDismiss(); block() }

    Popup(alignment = Alignment.TopEnd, onDismissRequest = onDismiss, properties = PopupProperties(focusable = true)) {
        AnimatedVisibility(
            visibleState = appear,
            enter = fadeIn(tween(VeilTokens.MotionBase)) + scaleIn(tween(VeilTokens.MotionBase, easing = VeilTokens.EaseOut), initialScale = 0.85f, transformOrigin = TransformOrigin(1f, 0f)),
            exit = fadeOut(tween(VeilTokens.MotionFast)),
        ) {
            Column(
                Modifier
                    .padding(8.dp)
                    .width(264.dp)
                    .shadow(12.dp, shape)
                    .clip(shape)
                    .background(V.c.toolbar)
                    .border(1.dp, V.c.outline, shape)
                    .padding(vertical = 8.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconBtn(VeilIcons.Back, stringResource(R.string.action_back), act(controller::back), enabled = tab?.canGoBack == true)
                    IconBtn(VeilIcons.Forward, stringResource(R.string.action_forward), act(controller::forward), enabled = tab?.canGoForward == true)
                    if (tab?.loading == true) IconBtn(VeilIcons.Close, stringResource(R.string.action_stop), act(controller::stop))
                    else IconBtn(VeilIcons.Reload, stringResource(R.string.action_reload), act(controller::reload), enabled = tab?.isBlank == false)
                }
                Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).height(1.dp).background(V.c.outline.copy(alpha = 0.5f)))
                MenuItem(VeilIcons.Add, stringResource(R.string.menu_new_tab), act(onNewTab))
                MenuItem(VeilIcons.Fullscreen, stringResource(R.string.menu_desktop_site), act { controller.setDesktopSite(tab?.desktopSite != true) },
                    trailing = { VSwitch(tab?.desktopSite == true, { onDismiss(); controller.setDesktopSite(it) }) })
                MenuItem(VeilIcons.Shield, stringResource(R.string.menu_site_settings), act { tab?.host?.let { onOpen(Route.SiteHost(it)) } }, enabled = tab?.host != null)
                MenuItem(VeilIcons.Extension, stringResource(R.string.menu_extensions), act { onOpen(Route.Extensions) })
                MenuItem(VeilIcons.Settings, stringResource(R.string.menu_settings), act { onOpen(Route.Settings) })
            }
        }
    }
}

@Composable
private fun MenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    trailing: @Composable () -> Unit = {},
) {
    Row(
        Modifier.fillMaxWidth().touchable(onClick, enabled, RoundedCornerShape(0.dp), pressedScale = 0.985f).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        VIcon(icon, if (enabled) V.c.textMuted else V.c.textFaint, 22.dp)
        Spacer(Modifier.width(16.dp))
        VText(label, color = if (enabled) V.c.text else V.c.textFaint, modifier = Modifier.weight(1f), maxLines = 1)
        trailing()
    }
}
