package app.veil.browser.core

/**
 * Gecko preferences that make up the browser's privacy posture. Values are Boolean, Int or String.
 *
 * - [baseline] is applied at engine start (through the YAML config file, see [GeckoConfigFile]) so that nothing
 *   is ever written or sent before the hardening is active.
 * - [torOn] / [torOff] flip the whole traffic path to SOCKS5 and back at runtime, without restarting.
 *   [torOff] holds *explicit* values instead of "clear the pref": prefs that arrived through the config file may
 *   live on a different branch than a runtime clear would reach, and a stale proxy setting must never survive
 *   a switch-off.
 */
object HardeningPrefs {
    const val TOR_HOST = "127.0.0.1"
    const val TOR_PORT = 9050

    /**
     * Where the engine's proxy points while the embedded tor is not (yet) running: a privileged loopback port that no app
     * can listen on, so requests fail at once instead of reaching whatever might have taken over a free port.
     */
    const val TOR_BLOCKED_PORT = 1

    val baseline: Map<String, Any> = linkedMapOf(
        // nothing persistent
        "browser.cache.disk.enable" to false,
        "browser.cache.disk_cache_ssl" to false,
        "browser.cache.memory.enable" to true,
        "browser.cache.offline.enable" to false,
        "browser.sessionstore.privacy_level" to 2,
        "browser.sessionstore.max_tabs_undo" to 0,
        "places.history.enabled" to false,
        "signon.rememberSignons" to false,
        "signon.autofillForms" to false,
        "browser.formfill.enable" to false,
        "network.cookie.lifetimePolicy" to 2,
        // no speculative / background traffic
        "network.dns.disablePrefetch" to true,
        "network.prefetch-next" to false,
        "network.predictor.enabled" to false,
        "network.http.speculative-parallel-limit" to 0,
        "network.captive-portal-service.enabled" to false,
        "network.connectivity-service.enabled" to false,
        // WebRTC: do not leak local interface addresses
        "media.peerconnection.ice.default_address_only" to true,
        "media.peerconnection.ice.no_host" to true,
        // telemetry
        "datareporting.healthreport.uploadEnabled" to false,
        "datareporting.policy.dataSubmissionEnabled" to false,
        "toolkit.telemetry.enabled" to false,
        "toolkit.telemetry.unified" to false,
        "browser.safebrowsing.downloads.remote.enabled" to false,
    )

    /** Everything that must change for traffic to go through the Tor SOCKS5 proxy (hostnames resolved by the proxy). */
    fun torOn(host: String = TOR_HOST, port: Int = TOR_PORT): Map<String, Any> = linkedMapOf(
        "network.proxy.socks" to host,
        "network.proxy.socks_port" to port,
        "network.proxy.socks_version" to 5,
        "network.proxy.socks_remote_dns" to true,
        "network.proxy.http" to "",
        "network.proxy.http_port" to 0,
        "network.proxy.ssl" to "",
        "network.proxy.ssl_port" to 0,
        "network.proxy.ftp" to "",
        "network.proxy.ftp_port" to 0,
        "network.proxy.no_proxies_on" to "",
        "network.proxy.failover_direct" to false,
        // anything that could open a path around the proxy
        "network.trr.mode" to 5,
        "media.peerconnection.enabled" to false,
        "network.http.http3.enable" to false,
        "network.dns.disableIPv6" to true,
        // Gecko refuses to resolve *.onion by default; with remote DNS the proxy (tor) resolves them. Same setting Tor Browser uses.
        "network.dns.blockDotOnion" to false,
        // the Android location API does not go through the proxy
        "geo.enabled" to false,
        // LAST on purpose: type=1 without a SOCKS host would mean "direct", so the switch only flips once everything
        // else is in place (the prefs are written one after the other, each awaited).
        "network.proxy.type" to 1,
    )

    val torOff: Map<String, Any> = linkedMapOf(
        "network.proxy.type" to 0,
        "network.proxy.socks" to "",
        "network.proxy.socks_port" to 0,
        "network.proxy.socks_remote_dns" to false,
        "network.proxy.http" to "",
        "network.proxy.http_port" to 0,
        "network.proxy.ssl" to "",
        "network.proxy.ssl_port" to 0,
        "network.trr.mode" to 0,
        "media.peerconnection.enabled" to true,
        "network.http.http3.enable" to true,
        "network.dns.disableIPv6" to false,
        "network.dns.blockDotOnion" to true,
        "geo.enabled" to true,
    )

    /** Loopback only: a misconfigured or malicious setting must not route all traffic through a remote host. */
    fun validTorEndpoint(host: String, port: Int): Boolean {
        val h = host.trim().lowercase()
        val loopback = h == "127.0.0.1" || h == "localhost" || Regex("^127(\\.(25[0-5]|2[0-4]\\d|1?\\d?\\d)){3}$").matches(h)
        return loopback && port in 1..65535
    }
}

/** Renders prefs into the YAML file GeckoView reads at startup (`GeckoRuntimeSettings.Builder.configFilePath`). */
object GeckoConfigFile {
    fun render(prefs: Map<String, Any>): String = buildString {
        appendLine("# generated at every start – do not edit")
        appendLine("prefs:")
        for ((k, v) in prefs.toSortedMap()) {
            require(Regex("^[A-Za-z0-9_.@-]+$").matches(k)) { "unsafe pref name: $k" }
            append("  ").append(k).append(": ")
            when (v) {
                is Boolean -> append(v.toString())
                is Int -> append(v.toString())
                is String -> append('\'').append(v.replace("'", "''")).append('\'')
                else -> throw IllegalArgumentException("unsupported pref type for $k: ${v::class.simpleName}")
            }
            appendLine()
        }
    }
}
