package app.veil.browser.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.TabState
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.theme.VeilTokens
import kotlin.math.abs
import kotlinx.coroutines.launch

/** Grid of tab cards: tap to switch, swipe a card sideways (or tap ×) to close it. */
@Composable
fun TabSwitcher(controller: BrowserController, onBack: () -> Unit, onDone: () -> Unit) {
    val tabs by controller.tabs.collectAsState()
    val thumbs by controller.thumbnails.map.collectAsState()

    ScreenFrame(
        title = stringResource(R.string.tabs_title, tabs.tabs.size),
        onBack = onBack,
        actions = {
            IconBtn(VeilIcons.Add, stringResource(R.string.menu_new_tab), { controller.newTab(); onDone() })
            IconBtn(VeilIcons.Trash, stringResource(R.string.tabs_close_all), { controller.closeAllTabs(); onDone() })
        },
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(tabs.tabs, key = { it.id }) { tab ->
                TabCard(
                    tab = tab,
                    active = tab.id == tabs.activeId,
                    thumbnail = thumbs[tab.id],
                    onSelect = { controller.selectTab(tab.id); onDone() },
                    onClose = { controller.closeTab(tab.id) },
                    modifier = Modifier.animateItem(),
                )
            }
        }
    }
}

@Composable
private fun TabCard(tab: TabState, active: Boolean, thumbnail: Bitmap?, onSelect: () -> Unit, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(VeilTokens.RadiusLg)
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var width by remember { mutableStateOf(1f) }

    Column(
        modifier
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .graphicsLayer {
                translationX = offset.value
                alpha = (1f - abs(offset.value) / width).coerceIn(0f, 1f)
            }
            .clip(shape)
            .background(V.c.toolbar)
            .border(if (active) 2.dp else 1.dp, if (active) V.c.accent else V.c.outline, shape)
            .pointerInput(tab.id) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val x = offset.value
                        scope.launch {
                            if (abs(x) > width * 0.4f) {
                                offset.animateTo(if (x < 0) -width * 1.1f else width * 1.1f, tween(VeilTokens.MotionBase))
                                onClose()
                            } else {
                                offset.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium))
                            }
                        }
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f, spring()) } },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        scope.launch { offset.snapTo(offset.value + dx) }
                    },
                )
            }
            .touchable(onSelect, shape = shape, pressedScale = 0.97f),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            val title = tab.title.ifBlank { tab.host ?: stringResource(R.string.tab_new) }
            VText(title, size = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
            IconBtn(VeilIcons.Close, stringResource(R.string.tab_close), onClose, size = 32.dp, tint = V.c.textMuted)
        }
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.8f).background(V.c.surface),
            contentAlignment = Alignment.Center,
        ) {
            if (thumbnail != null) {
                val image = remember(thumbnail) { thumbnail.asImageBitmap() }
                Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
            } else {
                VIcon(if (tab.isOnion) VeilIcons.Onion else if (tab.isBlank) VeilIcons.Veil else VeilIcons.Globe, V.c.textFaint, 36.dp)
            }
        }
    }
}
