package app.veil.browser.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.veil.browser.R
import app.veil.browser.core.TorPhase
import app.veil.browser.core.TorState
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.theme.VeilTokens
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

/**
 * The page area plus the top bar. The engine view fills everything below the bar; native Compose layers
 * (new-tab page, crash page, fade-in cover, panic flash) sit on top of it.
 */
@Composable
fun BrowserScreen(
    controller: BrowserController,
    engine: EngineHandle,
    backEnabled: Boolean,
    onOpenTabs: () -> Unit,
    onOpen: (Route) -> Unit,
) {
    val tabs by controller.tabs.collectAsState()
    val epoch by controller.tabManager.epoch.collectAsState()
    val tor by controller.torState.collectAsState()
    val fullscreen by controller.fullscreen.collectAsState()
    val panicRunning by controller.panicRunning.collectAsState()
    val tab = tabs.active

    val session = remember(tabs.activeId, epoch) { controller.tabManager.tab(tabs.activeId)?.session }

    BackHandler(enabled = backEnabled && (fullscreen || tab?.canGoBack == true || tab?.parentId != null)) {
        when {
            fullscreen -> controller.exitFullscreen()
            tab?.canGoBack == true -> controller.back()
            tab != null -> controller.closeTab(tab.id)
        }
    }

    // Tab changes fade the new page in instead of cutting hard (the old frame is never visible for long).
    val cover = remember { Animatable(0f) }
    LaunchedEffect(tabs.activeId) {
        cover.snapTo(0.9f)
        cover.animateTo(0f, tween(VeilTokens.MotionSlow, easing = VeilTokens.EaseOut))
    }

    // One short red flash when the panic button fires: confirmation that it happened, even though the page is gone.
    val flash = remember { Animatable(0f) }
    LaunchedEffect(panicRunning) {
        if (panicRunning) {
            flash.snapTo(0.45f)
            flash.animateTo(0f, tween(520))
        }
    }

    Box(Modifier.fillMaxSize().background(V.c.frame)) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars).imePadding()) {
            AnimatedVisibility(
                visible = !fullscreen,
                enter = fadeIn(tween(VeilTokens.MotionBase)) + expandVertically(tween(VeilTokens.MotionBase)),
                exit = fadeOut(tween(VeilTokens.MotionFast)) + shrinkVertically(tween(VeilTokens.MotionBase)),
            ) {
                Column {
                    TopBar(
                        controller = controller,
                        tab = tab,
                        tabCount = tabs.tabs.size,
                        tor = tor,
                        onOpenTabs = onOpenTabs,
                        onOpen = onOpen,
                    )
                    ProgressLine(
                        progress = tab?.progress ?: 0,
                        loading = tab?.loading == true,
                        color = if (tor.phase == TorPhase.ON || tab?.isOnion == true) V.c.tor else V.c.accent,
                    )
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                EngineView(session, V.c.frame.toArgb(), engine, Modifier.fillMaxSize())

                PageOverlays(
                    showNewTab = tab?.isBlank == true && tab.crashed.not(),
                    showCrash = tab?.crashed == true,
                    controller = controller,
                    tor = tor,
                )

                Box(Modifier.fillMaxSize().graphicsLayer { alpha = cover.value }.background(V.c.frame))
            }
        }

        Box(Modifier.fillMaxSize().graphicsLayer { alpha = flash.value }.background(V.c.danger))
    }
}

/**
 * New-tab and crash pages. Kept in a function of their own on purpose: called straight inside the `Box` that sits in a
 * `Column`, Kotlin picks `ColumnScope.AnimatedVisibility`, whose receiver the `Box` scope blocks (compile error). Here no
 * layout scope is in range, so the plain `AnimatedVisibility` is used.
 */
@Composable
private fun PageOverlays(showNewTab: Boolean, showCrash: Boolean, controller: BrowserController, tor: TorState) {
    AnimatedVisibility(
        visible = showNewTab,
        enter = fadeIn(tween(VeilTokens.MotionSlow)),
        exit = fadeOut(tween(VeilTokens.MotionBase)),
    ) { NewTabPage(controller, tor) }

    AnimatedVisibility(
        visible = showCrash,
        enter = fadeIn(tween(VeilTokens.MotionBase)),
        exit = fadeOut(tween(VeilTokens.MotionBase)),
    ) { CrashPage(onReload = controller::reload) }
}

@Composable
private fun EngineView(session: GeckoSession?, coverColor: Int, engine: EngineHandle, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            GeckoView(ctx).also {
                it.coverUntilFirstPaint(coverColor)
                engine.view = it
            }
        },
        update = { view ->
            if (view.session !== session) {
                view.releaseSession()
                if (session != null && session.isOpen) view.setSession(session)
            }
        },
        onRelease = { view ->
            view.releaseSession()
            if (engine.view === view) engine.view = null
        },
    )
}

@Composable
private fun ProgressLine(progress: Int, loading: Boolean, color: androidx.compose.ui.graphics.Color) {
    val p by animateFloatAsState(if (loading) (progress / 100f).coerceIn(0.04f, 1f) else 1f, tween(VeilTokens.MotionBase), label = "progress")
    val a by animateFloatAsState(if (loading) 1f else 0f, tween(VeilTokens.MotionSlow), label = "progress-alpha")
    Box(Modifier.fillMaxWidth().height(2.dp).background(V.c.toolbar)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(p).alpha(a).background(color))
    }
}

@Composable
private fun CrashPage(onReload: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(V.c.frame).blockTouches().padding(32.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        VIcon(VeilIcons.Warning, V.c.warn, 48.dp)
        androidx.compose.foundation.layout.Spacer(Modifier.height(16.dp))
        VText(stringResource(R.string.crash_title), size = 20.sp, weight = androidx.compose.ui.text.font.FontWeight.Medium)
        androidx.compose.foundation.layout.Spacer(Modifier.height(8.dp))
        VText(stringResource(R.string.crash_body), color = V.c.textMuted, size = 14.sp, align = androidx.compose.ui.text.style.TextAlign.Center)
        androidx.compose.foundation.layout.Spacer(Modifier.height(20.dp))
        VButton(stringResource(R.string.action_reload), onReload)
    }
}
