package app.veil.browser.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class PermissionKind { CAMERA, MICROPHONE, GEOLOCATION, NOTIFICATIONS }

data class ChoiceOption(val id: String, val label: String, val selected: Boolean = false, val disabled: Boolean = false, val separator: Boolean = false)

/**
 * Something the page (or the engine on its behalf) wants the user to answer. The engine adapter creates these,
 * the UI renders them, and the answer completes the engine's pending result. Every prompt carries a [cancel]
 * that must complete the engine side without a user answer – it runs on tab close, panic and engine crash.
 */
sealed interface UiPrompt {
    val id: Long
    val origin: String
    val cancel: () -> Unit

    data class Alert(override val id: Long, override val origin: String, val message: String, val done: () -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class Confirm(override val id: Long, override val origin: String, val message: String, val done: (Boolean) -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class Text(override val id: Long, override val origin: String, val message: String, val default: String, val done: (String) -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class Auth(override val id: Long, override val origin: String, val needsUser: Boolean, val user: String, val done: (String, String) -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class Choice(override val id: Long, override val origin: String, val title: String, val options: List<ChoiceOption>, val multiple: Boolean, val done: (List<String>) -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class Permission(override val id: Long, override val origin: String, val kinds: List<PermissionKind>, val done: (allow: Boolean, remember: Boolean) -> Unit, override val cancel: () -> Unit) : UiPrompt
    data class ContextMenu(override val id: Long, override val origin: String, val linkUri: String?, val imageUri: String?, val openInNewTab: (String) -> Unit, override val cancel: () -> Unit) : UiPrompt
}

/** Request for the system file picker (handled by the activity, not rendered as a dialog). */
data class FilePickRequest(val multiple: Boolean, val mimeTypes: List<String>, val done: (List<String>) -> Unit, val cancel: () -> Unit)

/** FIFO of prompts; the UI shows the head. Thread-safe (flows), safe to cancel from any state. */
class PromptBroker {
    private val ids = java.util.concurrent.atomic.AtomicLong(1)
    private val _queue = MutableStateFlow<List<UiPrompt>>(emptyList())
    val queue: StateFlow<List<UiPrompt>> = _queue.asStateFlow()

    fun nextId(): Long = ids.getAndIncrement()

    private val owners = java.util.concurrent.ConcurrentHashMap<Long, Long>()

    /** [owner] ties the prompt to a tab so closing the tab can cancel it. */
    fun post(p: UiPrompt, owner: Long = NO_OWNER) {
        owners[p.id] = owner
        _queue.update { it + p }
    }

    fun cancelOwned(owner: Long) = cancelWhere { owners[it.id] == owner }

    /** The UI calls this after it invoked the prompt's `done`. */
    fun resolve(id: Long) {
        owners.remove(id)
        _queue.update { q -> q.filterNot { it.id == id } }
    }

    /** Cancels one prompt (engine side first, so a pending result is never left hanging). */
    fun cancel(id: Long) {
        val p = _queue.value.firstOrNull { it.id == id } ?: return
        resolve(id)
        runCatching { p.cancel() }
    }

    fun cancelAll() {
        var all: List<UiPrompt> = emptyList()
        _queue.update { all = it; emptyList() }
        owners.clear()
        for (p in all) runCatching { p.cancel() }
    }

    /** Prompts that belong to a closing tab. */
    fun cancelWhere(pred: (UiPrompt) -> Boolean) {
        val gone = _queue.value.filter(pred)
        _queue.update { q -> q.filterNot(pred) }
        for (p in gone) { owners.remove(p.id); runCatching { p.cancel() } }
    }

    companion object {
        const val NO_OWNER = -1L
    }
}
