package app.veil.browser

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import app.veil.browser.core.FilePickRequest
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.VeilApp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var controller: BrowserController

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val done = controller.pendingPermission
        controller.pendingPermission = null
        done?.invoke(results.isNotEmpty() && results.values.all { it })
    }

    private val pickOne = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> finishFilePick(listOfNotNull(uri)) }
    private val pickMany = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> finishFilePick(uris) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = (application as VeilApplication).controller
        if (c == null) { finish(); return }
        controller = c

        // The flag must be set before the first frame, otherwise the app switcher can capture a thumbnail.
        applySecureFlag(controller.settings.value.secureWindow)
        enableEdgeToEdge()

        controller.permissionRequester = { permissions, done -> requestAndroidPermissions(permissions, done) }
        handleIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { controller.settings.map { it.secureWindow }.distinctUntilChanged().collect(::applySecureFlag) }
                launch { controller.fullscreen.collect(::applyFullscreen) }
                launch { controller.fileRequests.collect(::startFilePick) }
            }
        }

        setContent { VeilApp(controller) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        controller.onForeground()
    }

    override fun onStop() {
        controller.onBackground()
        super.onStop()
    }

    override fun onDestroy() {
        if (::controller.isInitialized) controller.permissionRequester = null
        super.onDestroy()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val url = intent.dataString ?: return
        // a link handed to us by another app: never navigate to anything but http(s)
        if (url.startsWith("http://", true) || url.startsWith("https://", true)) controller.openFromIntent(url)
        intent.data = null
    }

    private fun applySecureFlag(secure: Boolean) {
        if (secure) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE) else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun applyFullscreen(on: Boolean) {
        val insets = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            insets.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            insets.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            insets.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun requestAndroidPermissions(permissions: List<String>, done: (Boolean) -> Unit) {
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { done(true); return }
        controller.pendingPermission?.invoke(false) // a newer request replaces an unanswered one
        controller.pendingPermission = done
        try {
            permissionLauncher.launch(missing.toTypedArray())
        } catch (_: Exception) {
            controller.pendingPermission = null
            done(false)
        }
    }

    private fun startFilePick(request: FilePickRequest) {
        controller.pendingFilePick?.cancel()
        controller.pendingFilePick = request
        // Engines may hand over extensions (".pdf") or lists: only a clean single MIME type goes to the system picker.
        val mime = request.mimeTypes.singleOrNull()?.trim()?.takeIf { MIME.matches(it) } ?: "*/*"
        try {
            if (request.multiple) pickMany.launch(mime) else pickOne.launch(mime)
        } catch (_: Exception) {
            controller.pendingFilePick = null
            request.cancel()
        }
    }

    private fun finishFilePick(uris: List<Uri>) {
        val req = controller.pendingFilePick ?: return
        controller.pendingFilePick = null
        // a picker app answering with file:// (or anything else) would hand engine-readable paths to a page
        val safe = uris.filter { it.scheme == "content" }
        if (safe.isEmpty()) req.cancel() else req.done(safe.map(Uri::toString))
    }

    private companion object {
        val MIME = Regex("^[A-Za-z0-9][A-Za-z0-9!#$&^_.+-]*/(\\*|[A-Za-z0-9][A-Za-z0-9!#$&^_.+-]*)$")
    }
}
