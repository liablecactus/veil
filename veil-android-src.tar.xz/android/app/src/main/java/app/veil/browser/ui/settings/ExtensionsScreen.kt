package app.veil.browser.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.ExtensionProblem
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.Callout
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.FieldBox
import app.veil.browser.ui.FieldKind
import app.veil.browser.ui.IconBtn
import app.veil.browser.ui.PrivateTextField
import app.veil.browser.ui.ScreenFrame
import app.veil.browser.ui.SectionTitle
import app.veil.browser.ui.SettingsRow
import app.veil.browser.ui.V
import app.veil.browser.ui.VButton
import app.veil.browser.ui.VText
import app.veil.browser.ui.VeilIcons
import kotlinx.coroutines.launch

@Composable
fun ExtensionsScreen(controller: BrowserController, onBack: () -> Unit) {
    val manager = controller.extensions
    val entries by manager.entries.collectAsState()
    val skipped by manager.skipped.collectAsState()
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { runCatching { manager.refresh() } }

    ScreenFrame(stringResource(R.string.settings_extensions), onBack) {
        SettingsPage {
            Callout(stringResource(R.string.ext_note))

            if (entries.isEmpty() && skipped.isEmpty()) Hint(stringResource(R.string.ext_empty))

            if (entries.isNotEmpty()) {
                SectionTitle(stringResource(R.string.ext_installed))
                CardColumn {
                    entries.forEachIndexed { i, e ->
                        if (i > 0) Divider()
                        val perms = if (e.permissions.isEmpty()) stringResource(R.string.ext_no_permissions) else e.permissions.joinToString(", ")
                        SettingsRow(
                            title = e.name,
                            description = "v${e.version} · $perms",
                            icon = VeilIcons.Extension,
                            trailing = {
                                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                    if (!e.builtIn) IconBtn(VeilIcons.Trash, stringResource(R.string.ext_remove), { scope.launch { runCatching { manager.uninstall(e.id) } } }, size = 36.dp, tint = V.c.textMuted)
                                    app.veil.browser.ui.VSwitch(e.enabled, { on -> scope.launch { runCatching { manager.setEnabled(e.id, on) } } })
                                }
                            },
                        )
                    }
                }
            }

            if (skipped.isNotEmpty()) {
                SectionTitle(stringResource(R.string.ext_skipped))
                CardColumn {
                    skipped.forEachIndexed { i, sk ->
                        if (i > 0) Divider()
                        val reasons = sk.info?.problems.orEmpty().map { problemText(it) }.joinToString("\n")
                        SettingsRow(title = sk.info?.name ?: sk.dir, description = reasons.ifBlank { stringResource(R.string.ext_problem_unknown) }, icon = VeilIcons.Warning, iconTint = V.c.warn)
                    }
                }
            }

            SectionTitle(stringResource(R.string.ext_install_title))
            CardColumn {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    FieldBox { PrivateTextField(url, { url = it }, Modifier.fillMaxWidth(), hint = stringResource(R.string.ext_install_url_hint), kind = FieldKind.Url) }
                    Spacer(Modifier.height(6.dp))
                    VText(stringResource(R.string.ext_install_hint), color = V.c.textMuted, size = 12.sp, lineHeight = 17.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        VButton(stringResource(R.string.ext_install_button), {
                            val target = url.trim()
                            busy = true
                            scope.launch {
                                runCatching { manager.installFromUrl(target) }
                                busy = false
                                url = ""
                            }
                        }, enabled = !busy && url.trim().startsWith("https://"))
                    }
                }
            }
        }
    }
}

@Composable
private fun problemText(p: ExtensionProblem): String = stringResource(
    when (p) {
        ExtensionProblem.NO_GECKO_ID -> R.string.ext_problem_no_id
        ExtensionProblem.SERVICE_WORKER_ONLY -> R.string.ext_problem_service_worker
        ExtensionProblem.UNSUPPORTED_MANIFEST_VERSION -> R.string.ext_problem_mv
    },
)
