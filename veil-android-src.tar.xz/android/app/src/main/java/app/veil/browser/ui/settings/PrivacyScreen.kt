package app.veil.browser.ui.settings

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import app.veil.browser.R
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.Callout
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.ScreenFrame
import app.veil.browser.ui.SectionTitle
import app.veil.browser.ui.SettingsRow
import app.veil.browser.ui.V
import app.veil.browser.ui.VeilIcons

@Composable
fun PrivacyScreen(controller: BrowserController, onBack: () -> Unit) {
    val s by controller.settings.collectAsState()
    ScreenFrame(stringResource(R.string.settings_privacy), onBack) {
        SettingsPage {
            SectionTitle(stringResource(R.string.priv_section_protection))
            CardColumn {
                SwitchRow(stringResource(R.string.priv_https_only), s.httpsOnly, { v -> controller.updateSettings { it.copy(httpsOnly = v) } }, stringResource(R.string.priv_https_only_desc))
                Divider()
                SwitchRow(stringResource(R.string.priv_tracking), s.strictTrackingProtection, { v -> controller.updateSettings { it.copy(strictTrackingProtection = v) } }, stringResource(R.string.priv_tracking_desc))
                Divider()
                SwitchRow(stringResource(R.string.priv_gpc), s.globalPrivacyControl, { v -> controller.updateSettings { it.copy(globalPrivacyControl = v) } }, stringResource(R.string.priv_gpc_desc))
            }

            SectionTitle(stringResource(R.string.priv_section_device))
            CardColumn {
                SwitchRow(stringResource(R.string.priv_secure_window), s.secureWindow, { v -> controller.updateSettings { it.copy(secureWindow = v) } }, stringResource(R.string.priv_secure_window_desc))
            }

            SectionTitle(stringResource(R.string.priv_section_storage))
            Callout(stringResource(R.string.priv_ram_note), color = V.c.accent)
            CardColumn {
                SwitchRow(stringResource(R.string.priv_remember_sites), s.rememberSiteSettings, { v -> controller.updateSettings { it.copy(rememberSiteSettings = v) } }, stringResource(R.string.priv_remember_sites_desc))
            }

            SectionTitle(stringResource(R.string.priv_section_panic))
            CardColumn {
                SwitchRow(stringResource(R.string.priv_panic_clipboard), s.panic.clearClipboard, { v -> controller.updateSettings { it.copy(panic = it.panic.copy(clearClipboard = v)) } }, stringResource(R.string.priv_panic_clipboard_desc))
                Divider()
                SwitchRow(stringResource(R.string.priv_panic_restart), s.panic.restartProcess, { v -> controller.updateSettings { it.copy(panic = it.panic.copy(restartProcess = v)) } }, stringResource(R.string.priv_panic_restart_desc))
                Divider()
                SettingsRow(
                    title = stringResource(R.string.priv_panic_now),
                    icon = VeilIcons.Bolt,
                    iconTint = V.c.danger,
                    onClick = controller::triggerPanic,
                )
            }
        }
    }
}
