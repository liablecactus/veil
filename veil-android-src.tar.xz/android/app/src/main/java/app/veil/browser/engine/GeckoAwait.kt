package app.veil.browser.engine

import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.mozilla.geckoview.GeckoResult
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Suspends until the [GeckoResult] completes. Throws what the engine reported. */
suspend fun <T> GeckoResult<T>.await(): T? = suspendCancellableCoroutine { cont ->
    then<Void>(
        GeckoResult.OnValueListener<T, Void> { value ->
            if (cont.isActive) cont.resume(value)
            null
        },
        GeckoResult.OnExceptionListener<Void> { error ->
            if (cont.isActive) cont.resumeWithException(error)
            null
        },
    )
}

/** Like [await], but never hangs: a wedged engine turns into an exception the caller can handle. */
suspend fun <T> GeckoResult<T>.awaitWithin(timeoutMs: Long, what: String): T? {
    var finished = false
    var value: T? = null
    withTimeoutOrNull(timeoutMs) {
        value = await()
        finished = true
    }
    if (!finished) throw IllegalStateException("$what: engine did not answer within ${timeoutMs}ms")
    return value
}
