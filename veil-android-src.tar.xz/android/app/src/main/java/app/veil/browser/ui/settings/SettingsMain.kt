package app.veil.browser.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.ThemeChoice
import app.veil.browser.engine.BrowserController
import app.veil.browser.ui.Callout
import app.veil.browser.ui.CardColumn
import app.veil.browser.ui.Divider
import app.veil.browser.ui.Route
import app.veil.browser.ui.ScreenFrame
import app.veil.browser.ui.SectionTitle
import app.veil.browser.ui.Segmented
import app.veil.browser.ui.SettingsRow
import app.veil.browser.ui.V
import app.veil.browser.ui.VText
import app.veil.browser.ui.VeilIcons

@Composable
fun SettingsRootScreen(onBack: () -> Unit, onOpen: (Route) -> Unit) {
    ScreenFrame(stringResource(R.string.settings_title), onBack) {
        SettingsPage {
            Spacer(Modifier.height(8.dp))
            CardColumn {
                SettingsRow(stringResource(R.string.settings_privacy), description = stringResource(R.string.settings_privacy_desc), icon = VeilIcons.Shield, onClick = { onOpen(Route.Privacy) }, trailing = { Chevron() })
                Divider()
                SettingsRow(stringResource(R.string.settings_sites), description = stringResource(R.string.settings_sites_desc), icon = VeilIcons.Globe, onClick = { onOpen(Route.SiteSettings) }, trailing = { Chevron() })
                Divider()
                SettingsRow(stringResource(R.string.settings_tor), description = stringResource(R.string.settings_tor_desc), icon = VeilIcons.Onion, onClick = { onOpen(Route.Tor) }, trailing = { Chevron() })
                Divider()
                SettingsRow(stringResource(R.string.settings_extensions), description = stringResource(R.string.settings_extensions_desc), icon = VeilIcons.Extension, onClick = { onOpen(Route.Extensions) }, trailing = { Chevron() })
                Divider()
                SettingsRow(stringResource(R.string.settings_appearance), description = stringResource(R.string.settings_appearance_desc), icon = VeilIcons.Eye, onClick = { onOpen(Route.Appearance) }, trailing = { Chevron() })
                Divider()
                SettingsRow(stringResource(R.string.settings_about), icon = VeilIcons.Info, onClick = { onOpen(Route.About) }, trailing = { Chevron() })
            }
        }
    }
}

private val SEARCH_ENGINES = listOf(
    "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
    "Startpage" to "https://www.startpage.com/do/search?q=%s",
    "Brave Search" to "https://search.brave.com/search?q=%s",
    "Mojeek" to "https://www.mojeek.com/search?q=%s",
    "Google" to "https://www.google.com/search?q=%s",
)

@Composable
fun AppearanceScreen(controller: BrowserController, onBack: () -> Unit) {
    val s by controller.settings.collectAsState()
    ScreenFrame(stringResource(R.string.settings_appearance), onBack) {
        SettingsPage {
            SectionTitle(stringResource(R.string.theme_title))
            CardColumn {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Segmented(
                        options = listOf(
                            ThemeChoice.DARK to stringResource(R.string.theme_dark),
                            ThemeChoice.LIGHT to stringResource(R.string.theme_light),
                            ThemeChoice.SYSTEM to stringResource(R.string.theme_system),
                        ),
                        selected = s.theme,
                        onSelect = { v -> controller.updateSettings { it.copy(theme = v) } },
                    )
                }
            }
            SectionTitle(stringResource(R.string.search_engine_title))
            CardColumn {
                SEARCH_ENGINES.forEachIndexed { i, (name, url) ->
                    if (i > 0) Divider()
                    RadioRow(name, selected = s.searchEngine == url, onSelect = { controller.updateSettings { it.copy(searchEngine = url) } })
                }
            }
            Hint(stringResource(R.string.search_engine_hint))
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val version = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()
    }
    ScreenFrame(stringResource(R.string.settings_about), onBack) {
        SettingsPage {
            Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                app.veil.browser.ui.VIcon(VeilIcons.Veil, V.c.accent, 56.dp)
                Spacer(Modifier.height(10.dp))
                VText(stringResource(R.string.app_name), size = 24.sp)
                VText(stringResource(R.string.about_version, version), color = V.c.textMuted, size = 13.sp)
            }
            SectionTitle(stringResource(R.string.about_limits_title))
            Callout(stringResource(R.string.about_limit_ram))
            Callout(stringResource(R.string.about_limit_cookies))
            Callout(stringResource(R.string.about_limit_extensions))
            Callout(stringResource(R.string.about_limit_tor))
            Callout(stringResource(R.string.about_limit_downloads))
            Callout(stringResource(R.string.about_limit_keyboard))
        }
    }
}
