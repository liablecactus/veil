package app.veil.browser.engine

import android.graphics.Bitmap
import app.veil.browser.core.BLANK_URL
import app.veil.browser.core.TabState
import app.veil.browser.core.TabsState
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.mozilla.geckoview.GeckoSession

/**
 * Tab thumbnails live in RAM only and die with their tab (and on panic). Bitmaps are deliberately not recycled:
 * the UI may still be drawing the previous one, and drawing a recycled bitmap crashes. The GC reclaims them.
 */
class Thumbnails {
    private val _map = MutableStateFlow<Map<Long, Bitmap>>(emptyMap())
    val map: StateFlow<Map<Long, Bitmap>> = _map.asStateFlow()

    fun put(id: Long, bitmap: Bitmap) = _map.update { it + (id to bitmap) }
    fun remove(id: Long) = _map.update { it - id }
    fun clear() { _map.value = emptyMap() }
}

/**
 * Owns the GeckoTabs and the observable [TabsState]. All methods are main-thread only.
 * Background tabs are told they are inactive so the engine can throttle them (battery and RAM).
 */
class TabManager(private val env: () -> TabEnv, private val newSession: () -> GeckoSession) {
    private val ids = AtomicLong(1)
    private val tabs = LinkedHashMap<Long, GeckoTab>()
    private val _state = MutableStateFlow(TabsState())
    val state: StateFlow<TabsState> = _state.asStateFlow()
    val thumbnails = Thumbnails()

    /** Bumps whenever a GeckoSession appears, disappears or becomes the active one (the UI re-attaches its view). */
    private val _epoch = MutableStateFlow(0)
    val epoch: StateFlow<Int> = _epoch.asStateFlow()

    /** A session was closed and opened again: views must re-attach to it. */
    fun bumpEpoch() { _epoch.update { it + 1 } }

    private var placeholderId: Long = TabsState.NONE
    private var closing: List<GeckoTab> = emptyList()

    fun tab(id: Long): GeckoTab? = tabs[id]
    val activeTab: GeckoTab? get() = tabs[_state.value.activeId]

    fun update(id: Long, f: (TabState) -> TabState) = _state.update { it.updated(id, f) }

    fun create(url: String? = null, activate: Boolean = true, parent: Long? = null): GeckoTab {
        val id = ids.getAndIncrement()
        val tab = GeckoTab(id, newSession(), env(), openNow = true)
        tabs[id] = tab
        _state.update { it.added(TabState(id, parentId = parent), activate) }
        syncActive()
        if (url != null && url != BLANK_URL) tab.load(url)
        return tab
    }

    /** A page called window.open / target=_blank: the engine opens the returned session itself. */
    fun createChild(parent: GeckoTab, uri: String?): GeckoSession {
        val id = ids.getAndIncrement()
        val session = newSession()
        tabs[id] = GeckoTab(id, session, env(), openNow = false)
        _state.update { it.added(TabState(id, url = uri ?: BLANK_URL, parentId = parent.id), activate = true) }
        syncActive()
        return session
    }

    fun select(id: Long) {
        if (!tabs.containsKey(id) || _state.value.activeId == id) return
        _state.update { it.selected(id) }
        syncActive()
    }

    fun selectRelative(delta: Int) {
        val s = _state.value
        if (s.tabs.size < 2) return
        val i = (s.activeIndex + delta).mod(s.tabs.size)
        select(s.tabs[i].id)
    }

    fun close(id: Long) {
        val t = tabs.remove(id) ?: return
        t.close()
        thumbnails.remove(id)
        _state.update { it.closed(id) }
        if (_state.value.tabs.isEmpty()) create() else syncActive()
    }

    fun move(id: Long, toIndex: Int) = _state.update { it.moved(id, toIndex) }

    private fun syncActive() {
        _epoch.update { it + 1 }
        val active = _state.value.activeId
        for ((id, t) in tabs) t.setActive(id == active)
    }

    // ------------------------------------------------------------------------------------- panic / reset

    /**
     * Instant, synchronous: the UI state becomes one blank tab *now*; the old sessions are closed right after
     * ([closeStaleSessions]) and the blank tab gets its engine session in [openBlankTab].
     */
    fun beginReset() {
        closing = closing + tabs.values
        tabs.clear()
        thumbnails.clear()
        placeholderId = ids.getAndIncrement()
        _state.value = TabsState(listOf(TabState(placeholderId)), placeholderId)
    }

    fun closeStaleSessions() {
        val stale = closing
        closing = emptyList()
        for (t in stale) runCatching { t.close() }
    }

    fun openBlankTab(): GeckoTab? {
        val id = placeholderId
        if (id == TabsState.NONE || tabs.containsKey(id)) return tabs[id]
        val tab = GeckoTab(id, newSession(), env(), openNow = true)
        tabs[id] = tab
        placeholderId = TabsState.NONE
        syncActive()
        return tab
    }
}
