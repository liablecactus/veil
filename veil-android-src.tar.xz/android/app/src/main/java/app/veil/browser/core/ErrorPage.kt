package app.veil.browser.core

/** Themed, escaped error page used instead of the engine's default one (fail-closed Tor errors included). */
object ErrorPage {
    fun escape(s: String): String = buildString(s.length + 16) {
        for (c in s) when (c) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&#39;")
            else -> append(c)
        }
    }

    private data class Texts(
        val title: String,
        val body: String,
        val torHint: String,
        val torHintEmbedded: String,
        val detail: String,
        val retry: String,
    )

    private val de = Texts(
        "Seite nicht erreichbar",
        "Die Verbindung zu %s konnte nicht hergestellt werden.",
        "Tor ist aktiv: Prüfe, ob Orbot läuft und einen SOCKS-Proxy auf Port %d bereitstellt. Solange er fehlt, wird absichtlich nichts direkt gesendet.",
        "Tor ist aktiv (eingebaut, Port %d). Die Seite ist vielleicht gerade offline – .onion-Dienste sind oft nur zeitweise erreichbar – oder Tor braucht noch einen Moment. Solange keine Verbindung besteht, wird absichtlich nichts direkt gesendet.",
        "Technischer Hinweis: %s",
        "Erneut versuchen",
    )
    private val en = Texts(
        "This site can’t be reached",
        "The connection to %s could not be established.",
        "Tor is on: check that Orbot is running and offers a SOCKS proxy on port %d. While it is missing, nothing is sent directly – on purpose.",
        "Tor is on (built-in, port %d). The site may be offline right now – onion services are often only reachable at times – or Tor may need a moment. While there is no connection, nothing is sent directly – on purpose.",
        "Technical detail: %s",
        "Try again",
    )

    /**
     * [embedded]: the proxy is Veil's own tor, so "start Orbot" would be wrong advice.
     * [detail]: the engine's error name/code, shown small so a failure can be diagnosed from a screenshot.
     */
    fun html(url: String?, torActive: Boolean, torPort: Int, lang: String, embedded: Boolean = false, detail: String? = null): String {
        val t = if (lang.lowercase().startsWith("de")) de else en
        val host = Omnibox.hostOf(url.orEmpty()) ?: url.orEmpty().take(120)
        val hint = if (embedded) t.torHintEmbedded else t.torHint
        val torBlock = if (torActive) "<p class=\"tor\">${escape(hint.format(torPort))}</p>" else ""
        val detailBlock = detail?.takeIf { it.isNotBlank() }?.let { "<p class=\"detail\">${escape(t.detail.format(it.take(160)))}</p>" }.orEmpty()
        return """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<title>${escape(t.title)}</title>
<style>:root{color-scheme:dark light}body{font:16px system-ui,sans-serif;margin:0;display:grid;place-items:center;min-height:100vh;background:#101114;color:#e8eaed}
main{max-width:30em;padding:24px}h1{font-size:1.3em;margin:0 0 12px}p{color:#a3a9b2;line-height:1.5}.tor{border-left:3px solid #b392f0;padding-left:12px}.detail{font-size:.8em;opacity:.8;word-break:break-all}
@media (prefers-color-scheme:light){body{background:#fff;color:#1f2328}p{color:#59616b}}</style></head>
<body><main><h1>${escape(t.title)}</h1><p>${escape(t.body.format(host))}</p>$torBlock$detailBlock</main></body></html>"""
    }
}
