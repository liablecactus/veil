package app.veil.browser.core

/** Result of evaluating a site's rules against a permission request. */
enum class Decision { ALLOW, ASK, BLOCK }

/** Engine-independent view of what a page asked for (the Gecko adapter maps its constants onto this). */
enum class ContentKind { GEOLOCATION, NOTIFICATIONS, STORAGE_ACCESS, AUTOPLAY_INAUDIBLE, AUTOPLAY_AUDIBLE, OTHER }

object PermissionPolicy {
    private fun Setting.toDecision() = when (this) {
        Setting.ALLOW -> Decision.ALLOW
        Setting.ASK -> Decision.ASK
        Setting.BLOCK -> Decision.BLOCK
    }

    /** Unknown permission kinds are blocked (fail closed). */
    fun decideContent(rules: SiteRules, kind: ContentKind): Decision = when (kind) {
        ContentKind.GEOLOCATION -> rules.geolocation.toDecision()
        ContentKind.NOTIFICATIONS -> rules.notifications.toDecision()
        ContentKind.STORAGE_ACCESS ->
            if (rules.thirdPartyCookies == Setting.ALLOW) Decision.ALLOW else Decision.BLOCK
        ContentKind.AUTOPLAY_INAUDIBLE -> Decision.ALLOW
        ContentKind.AUTOPLAY_AUDIBLE, ContentKind.OTHER -> Decision.BLOCK
    }

    /** Camera and microphone are evaluated together: any BLOCK wins, then any ASK, otherwise ALLOW. */
    fun decideMedia(rules: SiteRules, wantsVideo: Boolean, wantsAudio: Boolean): Decision {
        val list = buildList {
            if (wantsVideo) add(rules.camera)
            if (wantsAudio) add(rules.microphone)
        }
        return when {
            list.isEmpty() -> Decision.BLOCK
            list.any { it == Setting.BLOCK } -> Decision.BLOCK
            list.any { it == Setting.ASK } -> Decision.ASK
            else -> Decision.ALLOW
        }
    }

    /** The rule keys a prompt answer should be remembered under. */
    fun keysFor(kind: ContentKind): List<RuleKey> = when (kind) {
        ContentKind.GEOLOCATION -> listOf(RuleKey.GEOLOCATION)
        ContentKind.NOTIFICATIONS -> listOf(RuleKey.NOTIFICATIONS)
        else -> emptyList()
    }

    fun keysForMedia(wantsVideo: Boolean, wantsAudio: Boolean): List<RuleKey> = buildList {
        if (wantsVideo) add(RuleKey.CAMERA)
        if (wantsAudio) add(RuleKey.MICROPHONE)
    }
}
