package app.veil.browser.engine

import android.app.Application
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.IBinder
import androidx.core.content.ContextCompat
import app.veil.browser.core.ProfileWiper
import app.veil.browser.core.TorBootstrap
import app.veil.browser.core.TorEndpoint
import app.veil.browser.core.TorProgress
import app.veil.browser.core.TorRuntime
import app.veil.browser.core.TorRuntimeException
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.torproject.jni.TorService

/**
 * The embedded tor: the Guardian Project's `TorService` (tor 0.4.9 as a native library, `info.guardianproject:tor-android`)
 * bound as a service *inside* this process.
 *
 * Why polling instead of broadcasts for readiness: `TorService` publishes its state with broadcasts that arrive
 * asynchronously and can be stale after a restart; its control connection, SOCKS port and `status/bootstrap-phase` are
 * the ground truth, so those are read directly until tor reports 100%.
 *
 * What lives where: tor's state directory is `app_TorService` in the app's private data (not in `files/` or `cache/`, so
 * [app.veil.browser.VeilApplication]'s start-up wipe does not reach it). It is emptied here before every start and after
 * every stop, so no consensus, guard state or key material survives a switch-off. Torrc is regenerated each time.
 *
 * Not verified against the real library in this repository's build environment – see docs/TOR.md.
 */
class EmbeddedTor(
    private val app: Application,
    private val io: CoroutineDispatcher = Dispatchers.IO,
    private val startTimeoutMs: Long = 150_000,
    private val pollMs: Long = 400,
    private val stopWaitMs: Long = 5_000,
) : TorRuntime {

    private class Session {
        val abort = CompletableDeferred<Unit>()
        val done = CompletableDeferred<Unit>()
        val offSeen = CompletableDeferred<Unit>()
        val tornDown = AtomicBoolean(false)

        @Volatile var service: TorService? = null
        @Volatile var bound = false
        @Volatile var stopping = false
        @Volatile var started = false
        @Volatile var exited: String? = null
        var connection: ServiceConnection? = null
        var receiver: BroadcastReceiver? = null
    }

    @Volatile private var session: Session? = null
    @Volatile private var onExit: ((String?) -> Unit)? = null

    /** Loading the class runs its static initializer, which loads libtor: an ABI without it ends up here, not in a crash. */
    override val available: Boolean by lazy {
        try { Class.forName("org.torproject.jni.TorService"); true } catch (_: Throwable) { false }
    }

    override fun setOnExit(callback: ((String?) -> Unit)?) { onExit = callback }

    override suspend fun start(onProgress: (TorProgress) -> Unit): TorEndpoint {
        if (!available) throw TorRuntimeException(TorRuntimeException.Code.NOT_AVAILABLE, "libtor cannot be loaded on this device")
        session?.let { teardown(it) }
        val s = Session()
        session = s
        try {
            withContext(io) { prepareFiles() }
            if (s.abort.isCompleted) throw TorRuntimeException(TorRuntimeException.Code.ABORTED)
            attach(s)
            val endpoint = awaitReady(s, onProgress)
            s.started = true
            return endpoint
        } catch (e: Throwable) {
            // also when the caller was cancelled: tor must not be left running behind a cancelled start
            withContext(NonCancellable) { teardown(s) }
            throw e
        }
    }

    override suspend fun stop() {
        val s = session ?: return
        s.stopping = true
        s.abort.complete(Unit)
        withContext(NonCancellable) { teardown(s) }
    }

    override suspend fun newCircuits() {
        val s = session
        val svc = s?.service
        if (s == null || svc == null || s.stopping || s.exited != null) throw TorRuntimeException(TorRuntimeException.Code.EXITED, "tor is not running")
        withContext(io) {
            val conn = svc.torControlConnection ?: throw TorRuntimeException(TorRuntimeException.Code.EXITED, "no control connection")
            conn.signal("NEWNYM")
        }
    }

    // --------------------------------------------------------------------------------------------------- internals

    /** Empties tor's directories and writes the torrc (see [TorBootstrap.torrc]). */
    private fun prepareFiles() {
        val torrc = TorService.getTorrc(app)
        val base = torrc.parentFile ?: throw TorRuntimeException(TorRuntimeException.Code.START_FAILED, "no tor directory")
        ProfileWiper.wipeContents(listOf(base, File(app.cacheDir, "TorService")))
        base.mkdirs()
        torrc.writeText(TorBootstrap.torrc())
    }

    private fun wipeFiles() {
        try {
            val base = TorService.getTorrc(app).parentFile
            ProfileWiper.wipeContents(listOfNotNull(base, File(app.cacheDir, "TorService")))
        } catch (_: Throwable) {
        }
    }

    private fun attach(s: Session) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.getStringExtra(TorService.EXTRA_STATUS)) {
                    TorService.STATUS_OFF -> {
                        s.offSeen.complete(Unit)
                        if (!s.stopping) lost(s, "tor stopped")
                    }
                    TorService.STATUS_STOPPING -> if (!s.stopping) lost(s, "tor is stopping")
                }
            }
        }
        s.receiver = receiver
        ContextCompat.registerReceiver(app, receiver, IntentFilter(TorService.ACTION_STATUS), ContextCompat.RECEIVER_NOT_EXPORTED)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                val svc = (binder as? TorService.LocalBinder)?.service
                if (svc == null) lost(s, "unexpected binder (is TorService running in its own process?)") else s.service = svc
            }

            override fun onServiceDisconnected(name: ComponentName) { lost(s, "service disconnected") }
            override fun onBindingDied(name: ComponentName) { lost(s, "binding died") }
            override fun onNullBinding(name: ComponentName) { lost(s, "no binding") }
        }
        s.connection = connection
        // BIND_AUTO_CREATE starts the service, and with it tor (TorService.onCreate)
        s.bound = app.bindService(Intent(app, TorService::class.java), connection, Context.BIND_AUTO_CREATE)
        if (!s.bound) throw TorRuntimeException(TorRuntimeException.Code.START_FAILED, "bindService refused")
    }

    private fun lost(s: Session, why: String) {
        if (s.stopping || s.exited != null) return
        s.exited = why
        if (s.started) onExit?.invoke(why)
    }

    private suspend fun awaitReady(s: Session, onProgress: (TorProgress) -> Unit): TorEndpoint {
        val deadline = System.nanoTime() + startTimeoutMs * 1_000_000
        var last: TorProgress? = null
        while (true) {
            if (s.abort.isCompleted) throw TorRuntimeException(TorRuntimeException.Code.ABORTED)
            s.exited?.let { throw TorRuntimeException(TorRuntimeException.Code.EXITED, it) }
            if (System.nanoTime() > deadline) {
                throw TorRuntimeException(TorRuntimeException.Code.TIMEOUT, "stuck at ${last?.percent ?: 0}%${last?.tag?.let { " ($it)" } ?: ""}")
            }
            val svc = s.service
            if (svc != null) {
                val sample = withContext(io) { sample(svc) }
                val p = sample.progress
                if (p != null && (last == null || p.percent != last.percent || p.tag != last.tag)) {
                    last = p
                    onProgress(p)
                }
                if (sample.port > 0 && sample.progress?.percent == 100) return TorEndpoint("127.0.0.1", sample.port)
            }
            delay(pollMs)
        }
    }

    private class Sample(val port: Int, val progress: TorProgress?)

    /** Reads what tor itself says. Everything here may fail or be null while tor is still starting. */
    private fun sample(svc: TorService): Sample = try {
        val connected = svc.torControlConnection != null
        val port = if (connected) svc.socksPort else -1
        val progress = if (connected) TorBootstrap.parseProgress(svc.getInfo("status/bootstrap-phase")) else null
        Sample(port, progress)
    } catch (_: Exception) {
        Sample(-1, null)
    }

    /** Idempotent and safe to call from start() and stop() at the same time: the second caller waits for the first. */
    private suspend fun teardown(s: Session) {
        if (!s.tornDown.compareAndSet(false, true)) { s.done.await(); return }
        try {
            s.stopping = true
            s.abort.complete(Unit)
            val wasBound = s.bound
            s.connection?.let { c -> try { app.unbindService(c) } catch (_: IllegalArgumentException) { } }
            s.bound = false
            // unbinding destroys the service: it shuts tor down (SIGNAL SHUTDOWN) and then broadcasts OFF
            if (wasBound && s.service != null) withTimeoutOrNull(stopWaitMs) { s.offSeen.await() }
            s.receiver?.let { try { app.unregisterReceiver(it) } catch (_: IllegalArgumentException) { } }
            s.service = null
            withContext(io) { wipeFiles() }
            if (session === s) session = null
        } finally {
            s.done.complete(Unit)
        }
    }
}
