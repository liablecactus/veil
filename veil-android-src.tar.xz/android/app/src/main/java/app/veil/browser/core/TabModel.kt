package app.veil.browser.core

/** Everything the UI needs to know about one tab. Pure data; the engine adapter fills it in. */
data class TabState(
    val id: Long,
    val url: String = BLANK_URL,
    val title: String = "",
    /** 0..100 */
    val progress: Int = 0,
    val loading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val secure: Boolean = false,
    val desktopSite: Boolean = false,
    val scriptsBlocked: Boolean = false,
    val trackersBlocked: Int = 0,
    val crashed: Boolean = false,
    /** The tab that opened this one; closing the child returns to it (Chrome behaviour). */
    val parentId: Long? = null,
) {
    val host: String? get() = Omnibox.hostOf(url)
    val isBlank: Boolean get() = url.isEmpty() || url == BLANK_URL
    val isOnion: Boolean get() = host?.let(Omnibox::isOnionHost) == true
}

data class TabsState(val tabs: List<TabState> = emptyList(), val activeId: Long = NONE) {
    val active: TabState? get() = tabs.firstOrNull { it.id == activeId }
    val activeIndex: Int get() = tabs.indexOfFirst { it.id == activeId }

    fun added(tab: TabState, activate: Boolean = true): TabsState =
        copy(tabs = tabs + tab, activeId = if (activate || activeId == NONE) tab.id else activeId)

    fun updated(id: Long, f: (TabState) -> TabState): TabsState {
        val i = tabs.indexOfFirst { it.id == id }
        if (i < 0) return this
        val next = f(tabs[i])
        if (next == tabs[i]) return this
        return copy(tabs = tabs.toMutableList().also { it[i] = next })
    }

    fun selected(id: Long): TabsState = if (tabs.any { it.id == id }) copy(activeId = id) else this

    /** Closing the active tab picks its parent, else the tab that slides into its place, else the last one. */
    fun closed(id: Long): TabsState {
        val i = tabs.indexOfFirst { it.id == id }
        if (i < 0) return this
        val rest = tabs.filterIndexed { idx, _ -> idx != i }
            .map { if (it.parentId == id) it.copy(parentId = tabs[i].parentId) else it }
        if (id != activeId) return copy(tabs = rest)
        val parent = tabs[i].parentId?.let { pid -> rest.firstOrNull { it.id == pid } }
        val next = parent ?: rest.getOrNull(i) ?: rest.lastOrNull()
        return TabsState(rest, next?.id ?: NONE)
    }

    fun moved(id: Long, toIndex: Int): TabsState {
        val from = tabs.indexOfFirst { it.id == id }
        if (from < 0) return this
        val list = tabs.toMutableList()
        val t = list.removeAt(from)
        list.add(toIndex.coerceIn(0, list.size), t)
        return copy(tabs = list)
    }

    companion object {
        const val NONE = -1L
    }
}
