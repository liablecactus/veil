package app.veil.browser.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import app.veil.browser.core.RuleKey
import app.veil.browser.core.ThemeChoice
import app.veil.browser.engine.BrowserController
import app.veil.browser.engine.ThumbnailCapture
import app.veil.browser.ui.settings.AboutScreen
import app.veil.browser.ui.settings.AppearanceScreen
import app.veil.browser.ui.settings.ExtensionsScreen
import app.veil.browser.ui.settings.PrivacyScreen
import app.veil.browser.ui.settings.SettingsRootScreen
import app.veil.browser.ui.settings.SiteCategoryScreen
import app.veil.browser.ui.settings.SiteHostScreen
import app.veil.browser.ui.settings.SiteSettingsScreen
import app.veil.browser.ui.settings.TorScreen
import app.veil.browser.ui.theme.VeilTokens
import kotlinx.coroutines.launch

/** Screens that open on top of the browser. `depth` decides the slide direction when moving between them. */
sealed interface Route {
    val depth: Int

    data object Browser : Route { override val depth = 0 }
    data object Tabs : Route { override val depth = 1 }
    data object Settings : Route { override val depth = 1 }
    data object Privacy : Route { override val depth = 2 }
    data object SiteSettings : Route { override val depth = 2 }
    data class SiteCategory(val key: RuleKey) : Route { override val depth = 3 }
    data class SiteHost(val host: String) : Route { override val depth = 2 }
    data object Tor : Route { override val depth = 2 }
    data object Extensions : Route { override val depth = 2 }
    data object Appearance : Route { override val depth = 2 }
    data object About : Route { override val depth = 2 }
}

@Stable
class Navigator {
    var stack by mutableStateOf<List<Route>>(listOf(Route.Browser))
        private set
    val top: Route get() = stack.last()

    fun push(route: Route) { if (top != route) stack = stack + route }
    fun pop() { if (stack.size > 1) stack = stack.dropLast(1) }
    fun home() { if (stack.size > 1) stack = listOf(Route.Browser) }
}

/** The one place the browser screen publishes its GeckoView to, so other screens can take thumbnails. */
class EngineHandle {
    var view: org.mozilla.geckoview.GeckoView? = null
}

@Composable
fun VeilApp(controller: BrowserController) {
    val settings by controller.settings.collectAsState()
    val dark = when (settings.theme) {
        ThemeChoice.DARK -> true
        ThemeChoice.LIGHT -> false
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
    }

    VeilTheme(dark) {
        val nav = remember { Navigator() }
        val engine = remember { EngineHandle() }
        val scope = rememberCoroutineScope()
        val panicRunning by controller.panicRunning.collectAsState()

        // After the panic button everything that is open (settings, tab list, …) is gone: back to the empty browser.
        LaunchedEffect(panicRunning) { if (panicRunning) nav.home() }

        BackHandler(enabled = nav.stack.size > 1) { nav.pop() }

        Box(Modifier.fillMaxSize().background(V.c.frame)) {
            // The browser stays composed underneath every other screen: no view re-attach, no flicker, and
            // thumbnails can still be taken from the live page.
            BrowserScreen(
                controller = controller,
                engine = engine,
                backEnabled = nav.top == Route.Browser,
                onOpenTabs = {
                    val tab = controller.tabs.value.active
                    val view = engine.view
                    if (tab != null && view != null && !tab.isBlank) {
                        scope.launch { ThumbnailCapture.capture(view, tab.id, controller.thumbnails) }
                    }
                    nav.push(Route.Tabs)
                },
                onOpen = nav::push,
            )

            AnimatedContent(
                targetState = nav.top.takeIf { it != Route.Browser },
                transitionSpec = { overlayTransition(initialState?.depth ?: 0, targetState?.depth ?: 0) },
                label = "route",
                modifier = Modifier.fillMaxSize(),
            ) { route ->
                if (route != null) {
                    Box(Modifier.fillMaxSize().background(V.c.frame).blockTouches()) {
                        when (route) {
                            Route.Browser -> Unit
                            Route.Tabs -> TabSwitcher(controller, onBack = nav::pop, onDone = nav::home)
                            Route.Settings -> SettingsRootScreen(onBack = nav::pop, onOpen = nav::push)
                            Route.Privacy -> PrivacyScreen(controller, onBack = nav::pop)
                            Route.SiteSettings -> SiteSettingsScreen(controller, onBack = nav::pop, onOpen = nav::push)
                            is Route.SiteCategory -> SiteCategoryScreen(controller, route.key, onBack = nav::pop)
                            is Route.SiteHost -> SiteHostScreen(controller, route.host, onBack = nav::pop)
                            Route.Tor -> TorScreen(controller, onBack = nav::pop)
                            Route.Extensions -> ExtensionsScreen(controller, onBack = nav::pop)
                            Route.Appearance -> AppearanceScreen(controller, onBack = nav::pop)
                            Route.About -> AboutScreen(onBack = nav::pop)
                        }
                    }
                }
            }

            PromptHost(controller)
            MessageHost(controller, Modifier.align(androidx.compose.ui.Alignment.BottomCenter))
        }
    }
}

private fun overlayTransition(from: Int, to: Int): ContentTransform {
    val fast = tween<Float>(VeilTokens.MotionBase)
    return when {
        to > from -> (slideInHorizontally(tween(VeilTokens.MotionSlow, easing = VeilTokens.EaseOut)) { it / 4 } + fadeIn(fast)) togetherWith
            (fadeOut(tween(VeilTokens.MotionBase)))
        to < from -> fadeIn(fast) togetherWith
            (slideOutHorizontally(tween(VeilTokens.MotionSlow, easing = VeilTokens.EaseOut)) { it / 4 } + fadeOut(tween(VeilTokens.MotionBase)))
        else -> fadeIn(fast) togetherWith fadeOut(tween(VeilTokens.MotionFast))
    }
}
