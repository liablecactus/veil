package app.veil.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.veil.browser.R
import app.veil.browser.core.TorPhase
import app.veil.browser.core.TorState
import app.veil.browser.engine.BrowserController

/** What an empty tab shows: no history, no "most visited" – just the current protection state. */
@Composable
fun NewTabPage(controller: BrowserController, tor: TorState) {
    val settings by controller.settings.collectAsState()
    Column(
        Modifier.fillMaxSize().background(V.c.frame).blockTouches().verticalScroll(rememberScrollState()).padding(top = 48.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        VIcon(VeilIcons.Veil, V.c.accent, 60.dp)
        Spacer(Modifier.height(12.dp))
        VText(stringResource(R.string.app_name), size = 30.sp, weight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        VText(stringResource(R.string.newtab_subtitle), color = V.c.textMuted, size = 14.sp, align = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
        Spacer(Modifier.height(28.dp))

        CardColumn {
            val torText = when (tor.phase) {
                TorPhase.ON -> stringResource(R.string.state_on)
                TorPhase.CONNECTING -> stringResource(R.string.tor_state_connecting)
                TorPhase.UNREACHABLE -> stringResource(R.string.tor_state_unreachable)
                TorPhase.OFF -> stringResource(R.string.state_off)
            }
            val torColor = when (tor.phase) {
                TorPhase.ON, TorPhase.CONNECTING -> V.c.tor
                TorPhase.UNREACHABLE -> V.c.warn
                TorPhase.OFF -> V.c.textMuted
            }
            SettingsRow(
                title = stringResource(R.string.newtab_tor),
                icon = VeilIcons.Onion,
                iconTint = torColor,
                onClick = controller::toggleTor,
                trailing = { VText(torText, color = torColor, size = 13.sp) },
            )
            Divider()
            SettingsRow(
                title = stringResource(R.string.newtab_https),
                icon = VeilIcons.Lock,
                trailing = { OnOff(settings.httpsOnly) },
            )
            Divider()
            SettingsRow(
                title = stringResource(R.string.newtab_tracking),
                icon = VeilIcons.Shield,
                trailing = { VText(stringResource(if (settings.strictTrackingProtection) R.string.tracking_strict else R.string.tracking_standard), color = V.c.ok, size = 13.sp) },
            )
            Divider()
            SettingsRow(
                title = stringResource(R.string.newtab_ram),
                description = stringResource(R.string.newtab_ram_desc),
                icon = VeilIcons.Memory,
            )
        }
        Spacer(Modifier.height(16.dp))
        VText(stringResource(R.string.newtab_panic_hint), color = V.c.textFaint, size = 12.sp, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 40.dp))
    }
}

@Composable
private fun OnOff(on: Boolean) {
    VText(stringResource(if (on) R.string.state_on else R.string.state_off), color = if (on) V.c.ok else V.c.textMuted, size = 13.sp)
}
