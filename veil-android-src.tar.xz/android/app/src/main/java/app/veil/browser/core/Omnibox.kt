package app.veil.browser.core

import java.net.URLEncoder

/** Omnibox input → navigation target. Pure and conservative: dangerous schemes become searches. */
sealed interface OmniboxResult {
    val url: String

    data class Navigate(override val url: String) : OmniboxResult
    data class Search(override val url: String) : OmniboxResult
    data object Blank : OmniboxResult {
        override val url: String = BLANK_URL
    }
}

const val BLANK_URL = "about:blank"

object Omnibox {
    const val DEFAULT_SEARCH = "https://duckduckgo.com/?q=%s"

    private val schemeRe = Regex("^([a-z][a-z0-9+.-]*):", RegexOption.IGNORE_CASE)
    // the authority ends at "\\" too: browsers read it as "/" in http(s) URLs ("https://evil.com\\@good.com" is evil.com)
    private val authorityRe = Regex("^[a-z][a-z0-9+.-]*://([^/?#\\\\]*)", RegexOption.IGNORE_CASE)
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d{1,5})?([/?#].*)?$")
    private val ipv6 = Regex("^\\[[0-9a-f:.]+](:\\d{1,5})?([/?#].*)?$", RegexOption.IGNORE_CASE)
    private val localhost = Regex("^localhost(:\\d{1,5})?([/?#].*)?$", RegexOption.IGNORE_CASE)
    private val domainish = Regex(
        "^(?:[a-z0-9\\u00a1-\\uffff](?:[a-z0-9\\u00a1-\\uffff-]{0,61}[a-z0-9\\u00a1-\\uffff])?\\.)+" +
            "[a-z\\u00a1-\\uffff]{2,63}(?::\\d{1,5})?(?:[/?#].*)?$",
        RegexOption.IGNORE_CASE,
    )
    private val neverNavigate = Regex(
        "^(javascript|data|file|blob|view-source|chrome|about|vbscript|filesystem|devtools|resource|moz-extension|content|intent|android-app):",
        RegexOption.IGNORE_CASE,
    )

    fun isOnionHost(host: String): Boolean = host.lowercase().trimEnd('.').endsWith(".onion")

    fun searchUrl(template: String, query: String): String {
        val t = if (template.contains("%s")) template else DEFAULT_SEARCH
        val encoded = URLEncoder.encode(query, "UTF-8").replace("+", "%20")
        return t.replace("%s", encoded)
    }

    /** Host part of an http(s) URL, lower-case, without port or brackets; null for anything else. */
    fun hostOf(url: String): String? {
        val m = authorityRe.find(url) ?: return null
        val scheme = schemeRe.find(url)?.groupValues?.get(1)?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        var authority = m.groupValues[1].substringAfterLast('@')
        authority = if (authority.startsWith("[")) authority.substringBefore(']').removePrefix("[") else authority.substringBefore(':')
        return authority.lowercase().trimEnd('.').ifEmpty { null }
    }

    fun resolve(raw: String, searchTemplate: String = DEFAULT_SEARCH): OmniboxResult {
        val input = raw.trim()
        if (input.isEmpty() || input.equals(BLANK_URL, ignoreCase = true)) return OmniboxResult.Blank
        val search = { OmniboxResult.Search(searchUrl(searchTemplate, input)) }

        if (input.contains("://")) {
            val scheme = schemeRe.find(input)?.groupValues?.get(1)?.lowercase()
            if ((scheme == "http" || scheme == "https") && hostOf(input) != null && !input.any { it.isWhitespace() }) {
                return OmniboxResult.Navigate(input)
            }
            return search()
        }
        // "javascript:…", "data:…", "file:…" and friends never navigate – they are searched instead.
        if (neverNavigate.containsMatchIn(input)) return search()

        if (input.none { it.isWhitespace() }) {
            val hostPart = input.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')
            if (localhost.matches(input) || ipv4.matches(input) || ipv6.matches(input)) {
                return OmniboxResult.Navigate("http://$input")
            }
            if (domainish.matches(input)) {
                // Onion services are plain HTTP by convention (Tor already provides end-to-end encryption).
                val proto = if (isOnionHost(hostPart)) "http" else "https"
                return OmniboxResult.Navigate("$proto://$input")
            }
        }
        return search()
    }
}
