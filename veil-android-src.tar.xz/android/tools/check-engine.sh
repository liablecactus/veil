#!/usr/bin/env bash
# Type-checks the GeckoView/Android glue (engine/, extensions/ and core/) against hand-written stubs in tools/stubs.
# The stubs mirror the API signatures taken from the Mozilla source; they exist so that typos, nullability mistakes
# and wrong overloads in *our* code are caught without an Android SDK. They do not prove that the real GeckoView
# artifact behaves the same – a build against the real dependency is still required (see docs/ANDROID.md).
#   tools/check-engine.sh [GRADLE_HOME]
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
GH="${1:-${GRADLE_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v gradle)")")")}}"
L="$GH/lib"
jar() { ls "$L"/$1 2>/dev/null | head -1; }
KC_CP="$(jar 'kotlin-compiler-embeddable-*.jar'):$(jar 'kotlin-stdlib-*.jar'):$(jar 'kotlin-script-runtime-*.jar'):$(jar 'kotlin-reflect-*.jar'):$(jar 'kotlin-daemon-embeddable-*.jar'):$(jar 'trove4j-*.jar'):$(jar 'annotations-*.jar'):$(jar 'kotlinx-coroutines-core-jvm-*.jar')"
LIBS="$(jar 'kotlin-stdlib-*.jar'):$(jar 'kotlinx-coroutines-core-jvm-*.jar'):$(jar 'kotlinx-serialization-core-jvm-*.jar'):$(jar 'kotlinx-serialization-json-jvm-*.jar')"
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
echo "== javac stubs"
find "$here/tools/stubs" -name '*.java' > "$out/stubs.txt"
mkdir -p "$out/stubs"
javac -nowarn -d "$out/stubs" @"$out/stubs.txt" 2>&1 | grep -v '^Picked up' || true
echo "== kotlinc core + engine + extensions"
log="$out/kotlinc.log"; status=0
java -cp "$KC_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 \
  -cp "$LIBS:$out/stubs" -d "$out/classes" \
  "$here/app/src/main/java/app/veil/browser/core" \
  "$here/app/src/main/java/app/veil/browser/engine" \
  "$here/app/src/main/java/app/veil/browser/extensions" >"$log" 2>&1 || status=$?
grep -v -E '^(Picked up|warning: .*(unused|never used))' "$log" || true
if [ "$status" -ne 0 ]; then echo "FAILED"; exit "$status"; fi
echo "OK: engine glue type-checks against the stubs"
