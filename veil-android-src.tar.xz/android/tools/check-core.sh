#!/usr/bin/env bash
# Compiles and tests the Android-independent core (app/src/main/java/app/veil/browser/core) with the Kotlin
# compiler that ships inside a Gradle distribution – no Android SDK, no Maven access needed.
#   tools/check-core.sh [GRADLE_HOME]
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
GH="${1:-${GRADLE_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v gradle)")")")}}"
L="$GH/lib"
jar() { ls "$L"/$1 2>/dev/null | head -1; }
KC_CP="$(jar 'kotlin-compiler-embeddable-*.jar'):$(jar 'kotlin-stdlib-*.jar'):$(jar 'kotlin-script-runtime-*.jar'):$(jar 'kotlin-reflect-*.jar'):$(jar 'kotlin-daemon-embeddable-*.jar'):$(jar 'trove4j-*.jar'):$(jar 'annotations-*.jar'):$(jar 'kotlinx-coroutines-core-jvm-*.jar')"
LIBS="$(jar 'kotlin-stdlib-*.jar'):$(jar 'kotlinx-coroutines-core-jvm-*.jar'):$(jar 'kotlinx-serialization-core-jvm-*.jar'):$(jar 'kotlinx-serialization-json-jvm-*.jar')"
TEST_LIBS="$(jar 'junit-4*.jar'):$(jar 'hamcrest-core-*.jar')"
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
compile() { # <dest> <classpath> <sources...>
  local dest="$1" cp="$2"; shift 2
  local log status=0
  log="$(mktemp)"
  java -cp "$KC_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 17 -cp "$cp" -d "$dest" "$@" >"$log" 2>&1 || status=$?
  grep -v -E '^(Picked up|warning: .*(unused|never used))' "$log" || true
  rm -f "$log"
  return "$status"
}
echo "== compile core"
compile "$out/main" "$LIBS" "$here/app/src/main/java/app/veil/browser/core"
echo "== compile tests"
compile "$out/test" "$LIBS:$TEST_LIBS:$out/main" "$here/app/src/test/java/app/veil/browser/core"
echo "== run tests"
classes="$(cd "$out/test" && find . -name '*Test.class' | sed 's|^\./||; s|\.class$||; s|/|.|g' | sort | tr '\n' ' ')"
java -cp "$LIBS:$TEST_LIBS:$out/main:$out/test" org.junit.runner.JUnitCore $classes
