#!/usr/bin/env python3
"""
Static consistency checks for the Compose UI layer, which cannot be compiled without the Android SDK:
  * every R.string.* used in code exists in values/ and values-de/, with the same format placeholders
  * string files are well-formed and Android-safe (escaped apostrophes, no stray '@' or '?' prefix)
  * every VeilIcons.X / V.c.X / VeilTokens.X referenced exists
  * brackets are balanced in every Kotlin file (catches truncated writes)
It does NOT type-check Compose calls – that needs the real toolchain (see docs/ANDROID.md).
Usage: tools/check-ui.py
"""
import re, sys, pathlib
import xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parent.parent / "app" / "src" / "main"
kt = sorted((root / "java").rglob("*.kt"))
errors, warnings = [], []

def strings(path):
    out = {}
    for el in ET.parse(path).getroot():
        name = el.get("name")
        text = el.text or ""
        if name in out: errors.append(f"{path.name}: duplicate string {name}")
        if re.search(r"(?<!\\)'", text): errors.append(f"{path}: unescaped apostrophe in {name}")
        if text[:1] in "@?": errors.append(f"{path}: {name} starts with {text[:1]!r}")
        out[name] = text
    return out

en = strings(root / "res/values/strings.xml")
de = strings(root / "res/values-de/strings.xml")

def placeholders(t): return sorted(re.findall(r"%\d\$[sd]", t))
for k in sorted(set(en) | set(de)):
    if k not in en: errors.append(f"string {k} missing in values/")
    elif k not in de: errors.append(f"string {k} missing in values-de/")
    elif placeholders(en[k]) != placeholders(de[k]): errors.append(f"string {k}: placeholders differ between en and de")

src = {p: p.read_text(encoding="utf-8") for p in kt}
all_text = "\n".join(src.values())

used = set(re.findall(r"R\.string\.([a-z0-9_]+)", all_text))
for k in sorted(used):
    if k not in en: errors.append(f"R.string.{k} used but not defined")
for k in sorted(set(en) - used):
    warnings.append(f"string {k} is defined but never used")

# format arguments passed vs placeholders declared
for m in re.finditer(r"stringResource\(R\.string\.([a-z0-9_]+)((?:,[^()]*(?:\([^()]*\))?[^()]*)*)\)", all_text):
    key, rest = m.group(1), m.group(2)
    if key not in en: continue
    n = len(set(re.findall(r"%(\d)\$[sd]", en[key])))
    args = [a for a in re.split(r",(?![^()]*\))", rest) if a.strip()]
    if len(args) != n: errors.append(f"stringResource({key}) passes {len(args)} args, string has {n} placeholders")

icons = set(re.findall(r"val ([A-Za-z0-9]+): ImageVector", (root / "java/app/veil/browser/ui/VeilIcons.kt").read_text()))
for k in sorted(set(re.findall(r"VeilIcons\.([A-Za-z0-9]+)", all_text)) - icons):
    errors.append(f"VeilIcons.{k} does not exist")

tokens = (root / "java/app/veil/browser/ui/theme/Tokens.kt").read_text()
palette = set(re.findall(r"val ([a-zA-Z]+): Color,", tokens))
for k in sorted(set(re.findall(r"\bV\.c\.([a-zA-Z]+)", all_text)) - palette):
    errors.append(f"V.c.{k} does not exist")
tok = set(re.findall(r"(?:val|const val) ([A-Za-z]+) =", tokens.split("object VeilTokens")[1]))
for k in sorted(set(re.findall(r"VeilTokens\.([A-Za-z]+)", all_text)) - tok - {"Dark", "Light"}):
    errors.append(f"VeilTokens.{k} does not exist")

def balanced(text):
    stack, i, n = [], 0, len(text)
    pairs = {")": "(", "]": "[", "}": "{"}
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            i = text.find("\n", i); i = n if i < 0 else i; continue
        if text.startswith("/*", i):
            j = text.find("*/", i + 2); i = n if j < 0 else j + 2; continue
        if text.startswith('"""', i):
            j = text.find('"""', i + 3); i = n if j < 0 else j + 3; continue
        if c == '"':
            i += 1
            while i < n and text[i] != '"':
                if text[i] == "\\": i += 1
                elif text[i] == "$" and text.startswith("${", i):  # template: skip to matching brace
                    depth = 0
                    while i < n:
                        if text[i] == "{": depth += 1
                        elif text[i] == "}":
                            depth -= 1
                            if depth == 0: break
                        i += 1
                i += 1
            i += 1; continue
        if c == "'":
            j = i + 1
            if text[j] == "\\": j += 1
            i = j + 2 if j + 1 < n and text[j + 1] == "'" else i + 1
            continue
        if c in "([{": stack.append(c)
        elif c in ")]}":
            if not stack or stack.pop() != pairs[c]: return False
        i += 1
    return not stack

for p, text in src.items():
    if not balanced(text): errors.append(f"{p.relative_to(root)}: unbalanced brackets")

for w in warnings: print("warning:", w)
for e in errors: print("ERROR:", e)
if errors:
    print(f"FAILED ({len(errors)} errors)"); sys.exit(1)
print(f"OK: {len(used)} string keys in {len(kt)} files, icons/palette/tokens resolve, brackets balanced")
