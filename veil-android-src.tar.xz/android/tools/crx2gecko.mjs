#!/usr/bin/env node
// Converts a Chrome extension (.crx or unpacked folder) into a folder GeckoView can load as a built-in extension.
//
//   node tools/crx2gecko.mjs <extension.crx | unpacked-dir> [--out app/src/main/assets/extensions] [--name folder] [--id addon@id]
//
// What it changes in manifest.json (and nothing else):
//   * adds browser_specific_settings.gecko.id        (Gecko refuses to install built-ins without an id)
//   * background.service_worker -> background.scripts (Gecko runs MV3 background code as an event page)
//   * removes update_url and key                      (no update pings to Google; the id is fixed by us)
// It also reports Chrome-only APIs that Gecko does not provide, so you know what will not work.
//
// A .crx is verified first (CRX3 signature + id derivation) with the same code the desktop app uses. That proves the
// file was not modified after signing; it does NOT prove the Chrome Web Store published it.
// Requires Node >= 22.18 (runs the shared TypeScript helpers directly).

import { cp, lstat, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, join, resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { parseCrx3 } from '../../desktop/src/core/crx.ts';
import { extractZip } from '../../desktop/src/core/zip.ts';
import { parseManifestJson } from '../../desktop/src/core/manifest.ts';

const here = fileURLToPath(new URL('.', import.meta.url));
const MAX_BYTES = 64 * 1024 * 1024;

// APIs without a Gecko counterpart (or with a different shape); the extension loads, but these parts do nothing.
const CHROME_ONLY_PERMISSIONS = new Set([
  'sidePanel', 'offscreen', 'tabGroups', 'desktopCapture', 'pageCapture', 'tabCapture', 'system.cpu', 'system.display',
  'system.memory', 'system.storage', 'enterprise.platformKeys', 'enterprise.deviceAttributes', 'fileBrowserHandler',
  'vpnProvider', 'wallpaper', 'documentScan', 'printing', 'processes', 'readingList', 'gcm', 'power', 'ttsEngine', 'loginState',
]);

function parseArgs(argv) {
  const args = { input: null, out: join(here, '../app/src/main/assets/extensions'), name: null, id: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--out') args.out = resolve(argv[++i] ?? '');
    else if (a === '--name') args.name = argv[++i] ?? '';
    else if (a === '--id') args.id = argv[++i] ?? '';
    else if (a === '-h' || a === '--help') { console.log('usage: crx2gecko.mjs <extension.crx | unpacked-dir> [--out dir] [--name folder] [--id addon@id]'); process.exit(0); }
    else if (!args.input) args.input = resolve(a);
    else fail(`unexpected argument: ${a}`);
  }
  if (!args.input) fail('missing input (.crx file or unpacked folder)');
  return args;
}

function fail(message) {
  console.error(`error: ${message}`);
  process.exit(1);
}

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'extension';

/** Gecko ids are either an email-like string or a {uuid}; both forms are matched by this. */
const validGeckoId = (id) => /^[A-Za-z0-9._@+-]{3,128}$/.test(id) && /@/.test(id) || /^\{[0-9a-fA-F-]{36}\}$/.test(id);

/** Refuses symlinks and oversized trees in an unpacked folder (it is untrusted input just like a CRX). */
async function checkTree(dir) {
  let total = 0;
  const walk = async (d) => {
    for (const e of await readdir(d, { withFileTypes: true })) {
      const p = join(d, e.name);
      const st = await lstat(p);
      if (st.isSymbolicLink()) fail(`symlink in extension folder: ${p}`);
      if (st.isDirectory()) await walk(p);
      else { total += st.size; if (total > MAX_BYTES) fail('extension folder is too large'); }
    }
  };
  await walk(dir);
}

async function loadSource(input) {
  const st = await lstat(input).catch(() => fail(`cannot read ${input}`));
  const work = await mkdtemp(join(tmpdir(), 'crx2gecko-'));
  const dir = join(work, 'ext');
  await mkdir(dir);
  if (st.isDirectory()) {
    await checkTree(input);
    await cp(input, dir, { recursive: true, dereference: false });
    return { dir, work, chromeId: null };
  }
  if (st.size > MAX_BYTES) fail('file is too large');
  const crx = parseCrx3(new Uint8Array(await readFile(input)));
  await extractZip(crx.zip, dir, { skip: (p) => p === '_metadata' || p.startsWith('_metadata/') });
  console.log(`CRX3 signature ok, Chrome id ${crx.id}`);
  return { dir, work, chromeId: crx.id };
}

function convert(manifest, { chromeId, forcedId }) {
  const notes = [];
  const warnings = [];
  const out = structuredClone(manifest);

  if (out.manifest_version !== 3 && out.manifest_version !== 2) fail(`unsupported manifest_version ${out.manifest_version}`);
  if (out.manifest_version === 2) warnings.push('Manifest V2: Gecko still loads it, but this project targets MV3.');

  const bss = (out.browser_specific_settings ??= {});
  const gecko = (bss.gecko ??= {});
  if (forcedId) gecko.id = forcedId;
  if (!gecko.id) {
    const basis = chromeId ?? createHash('sha256').update(JSON.stringify(manifest)).digest('hex').slice(0, 32);
    gecko.id = `${basis}@veil.chrome`;
    notes.push(`added browser_specific_settings.gecko.id = ${gecko.id}`);
  }
  if (!validGeckoId(gecko.id)) fail(`invalid Gecko id: ${gecko.id}`);

  const bg = out.background;
  if (bg && typeof bg === 'object') {
    if (bg.service_worker && !Array.isArray(bg.scripts)) {
      bg.scripts = [bg.service_worker];
      notes.push(`background.service_worker "${bg.service_worker}" -> background.scripts`);
    }
    if (bg.service_worker) delete bg.service_worker;
    if (out.manifest_version === 3 && bg.scripts && bg.persistent === true) { bg.persistent = false; notes.push('background.persistent -> false'); }
  }

  for (const k of ['update_url', 'key']) {
    if (k in out) { delete out[k]; notes.push(`removed ${k}`); }
  }

  const perms = [...(out.permissions ?? []), ...(out.optional_permissions ?? [])].filter((p) => typeof p === 'string');
  const missing = perms.filter((p) => CHROME_ONLY_PERMISSIONS.has(p));
  if (missing.length) warnings.push(`Chrome-only permissions without a Gecko equivalent: ${missing.join(', ')}`);
  if (out.incognito === 'not_allowed') warnings.push('manifest says incognito:"not_allowed" – every tab here is private, so it will not run');
  if (out.chrome_url_overrides) warnings.push('chrome_url_overrides is ignored by this browser (the new-tab page is native)');
  if (out.side_panel) warnings.push('side_panel is not supported on GeckoView');
  if (out.devtools_page) warnings.push('devtools_page has no effect on Android');
  return { manifest: out, notes, warnings };
}

const args = parseArgs(process.argv.slice(2));
const src = await loadSource(args.input);
try {
  let manifest;
  try { manifest = parseManifestJson(await readFile(join(src.dir, 'manifest.json'), 'utf8')); }
  catch (e) { fail(`manifest.json: ${e.message}`); }
  if (typeof manifest !== 'object' || manifest === null || Array.isArray(manifest)) fail('manifest.json is not an object');

  const { manifest: converted, notes, warnings } = convert(manifest, { chromeId: src.chromeId, forcedId: args.id });
  const name = slug(args.name ?? (typeof manifest.name === 'string' && !manifest.name.startsWith('__MSG_') ? manifest.name : basename(args.input).replace(/\.crx$/i, '')));
  const dest = join(args.out, name);
  await rm(dest, { recursive: true, force: true });
  await mkdir(args.out, { recursive: true });
  await cp(src.dir, dest, { recursive: true });
  await writeFile(join(dest, 'manifest.json'), JSON.stringify(converted, null, 2) + '\n');

  console.log(`\nwritten: ${dest}`);
  for (const n of notes) console.log(`  changed: ${n}`);
  for (const w of warnings) console.log(`  warning: ${w}`);
  console.log('\nRebuild the app; the extension is installed as a built-in on the next start.');
} finally {
  await rm(src.work, { recursive: true, force: true });
}
