package android.content;
import android.os.Bundle;
public class Intent implements android.os.Parcelable {
    public static final int FLAG_ACTIVITY_NEW_TASK = 1, FLAG_ACTIVITY_CLEAR_TASK = 2;
    public Intent() {} public Intent(Context c, Class<?> cls) {}
    public Intent addFlags(int f) { return this; }
    public Intent putExtra(String k, int v) { return this; }
    public Intent putExtra(String k, android.os.Parcelable v) { return this; }
    public Bundle getExtras() { return null; }
    public String getStringExtra(String name) { return null; }
    public String getAction() { return null; }
}
