package android.content.res;
import java.io.InputStream;
public abstract class AssetManager { public abstract String[] list(String path) throws java.io.IOException; public abstract InputStream open(String fileName) throws java.io.IOException; }
