package android.content;
import android.content.res.AssetManager; import android.content.res.Resources; import android.content.pm.PackageManager; import java.io.File;
public class Context {
    public static final int BIND_AUTO_CREATE = 1;
    public static final String CLIPBOARD_SERVICE = "clipboard", ACTIVITY_SERVICE = "activity";
    public AssetManager getAssets() { return null; }
    public Resources getResources() { return null; }
    public PackageManager getPackageManager() { return null; }
    public String getPackageName() { return ""; }
    public File getFilesDir() { return null; } public File getCacheDir() { return null; } public File getNoBackupFilesDir() { return null; }
    public Object getSystemService(String name) { return null; }
    public void startActivity(Intent i) {}
    public boolean bindService(Intent service, ServiceConnection conn, int flags) { return false; }
    public void unbindService(ServiceConnection conn) {}
    public void unregisterReceiver(BroadcastReceiver receiver) {}
    public File getDir(String name, int mode) { return null; }
    public final String getString(int resId, Object... formatArgs) { return ""; }
    public final String getString(int resId) { return ""; }
}
