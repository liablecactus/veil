package android.content;
public class ClipboardManager { public void clearPrimaryClip() {} public void setPrimaryClip(ClipData c) {} }
