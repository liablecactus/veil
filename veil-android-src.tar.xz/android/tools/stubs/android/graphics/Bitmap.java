package android.graphics;
public final class Bitmap {
    public void recycle() {}
    public int getWidth() { return 0; }
    public int getHeight() { return 0; }
    public static Bitmap createScaledBitmap(Bitmap src, int w, int h, boolean filter) { return src; }
}
