package android.app;
import java.util.List;
public class ActivityManager { public static class RunningAppProcessInfo { public int pid; } public List<RunningAppProcessInfo> getRunningAppProcesses() { return null; } }
