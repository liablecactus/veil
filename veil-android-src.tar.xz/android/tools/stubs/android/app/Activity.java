package android.app;
import android.os.Bundle; import android.content.Intent;
public class Activity extends android.content.Context { protected void onCreate(Bundle b) {} public Intent getIntent() { return null; } public void finish() {} }
