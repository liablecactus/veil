package android;
public final class Manifest { public static final class permission { public static final String CAMERA = "android.permission.CAMERA", RECORD_AUDIO = "android.permission.RECORD_AUDIO"; } }
