package android.os;
public class Bundle { public int getInt(String k, int d) { return d; } public <T extends Parcelable> T getParcelable(String k) { return null; } }
