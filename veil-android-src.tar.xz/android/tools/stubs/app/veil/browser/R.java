package app.veil.browser;
public final class R { public static final class string { public static final int ext_install_prompt = 1; } }
