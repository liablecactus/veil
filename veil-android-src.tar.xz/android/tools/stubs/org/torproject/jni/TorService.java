package org.torproject.jni;
import android.app.Service; import android.content.Context; import android.content.Intent; import android.os.Binder; import android.os.IBinder; import java.io.File;
import net.freehaven.tor.control.TorControlConnection;
// Mirrors the public surface of info.guardianproject:tor-android 0.4.9.x as read from
// https://github.com/guardianproject/tor-android (tor-android-binary/.../TorService.java). Not the real thing.
public class TorService extends Service {
    public static final String ACTION_START = "org.torproject.android.intent.action.START";
    public static final String ACTION_STOP = "org.torproject.android.intent.action.STOP";
    public static final String ACTION_STATUS = "org.torproject.android.intent.action.STATUS";
    public static final String ACTION_ERROR = "org.torproject.android.intent.action.ERROR";
    public static final String EXTRA_STATUS = "org.torproject.android.intent.extra.STATUS";
    public static final String EXTRA_SERVICE_PACKAGE_NAME = "org.torproject.android.intent.extra.SERVICE_PACKAGE_NAME";
    public static final String STATUS_OFF = "OFF", STATUS_ON = "ON", STATUS_STARTING = "STARTING", STATUS_STOPPING = "STOPPING";
    public static final String STATUS_CLIENT_CIRCUIT_ESTABLISHED = "CIRCUIT_ESTABLISHED";
    public class LocalBinder extends Binder { public TorService getService() { return TorService.this; } }
    public static File getTorrc(Context context) { return null; }
    public static File getDefaultsTorrc(Context context) { return null; }
    @Override public IBinder onBind(Intent intent) { return null; }
    public int getSocksPort() { return -1; }
    public int getHttpTunnelPort() { return -1; }
    public String getInfo(String key) { return null; }
    public TorControlConnection getTorControlConnection() { return null; }
}
