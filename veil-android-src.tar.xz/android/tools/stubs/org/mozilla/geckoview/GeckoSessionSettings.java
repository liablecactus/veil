package org.mozilla.geckoview;
public class GeckoSessionSettings {
    public static final int USER_AGENT_MODE_MOBILE = 0, USER_AGENT_MODE_DESKTOP = 1, USER_AGENT_MODE_VR = 2;
    public static final int VIEWPORT_MODE_MOBILE = 0, VIEWPORT_MODE_DESKTOP = 1;
    public void setAllowJavascript(boolean v) {} public boolean getAllowJavascript() { return true; }
    public void setUserAgentMode(int v) {} public int getUserAgentMode() { return 0; }
    public void setViewportMode(int v) {} public int getViewportMode() { return 0; }
    public void setUseTrackingProtection(boolean v) {} public boolean getUseTrackingProtection() { return true; }
    public boolean getUsePrivateMode() { return true; }
    public static class Builder {
        public Builder usePrivateMode(boolean f) { return this; }
        public Builder useTrackingProtection(boolean f) { return this; }
        public Builder allowJavascript(boolean f) { return this; }
        public Builder suspendMediaWhenInactive(boolean f) { return this; }
        public GeckoSessionSettings build() { return new GeckoSessionSettings(); }
    }
}
