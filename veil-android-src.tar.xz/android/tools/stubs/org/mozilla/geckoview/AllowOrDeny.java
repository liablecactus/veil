package org.mozilla.geckoview;
public enum AllowOrDeny { ALLOW, DENY }
