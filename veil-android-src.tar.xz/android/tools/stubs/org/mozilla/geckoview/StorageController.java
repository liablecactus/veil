package org.mozilla.geckoview;
public class StorageController {
    public GeckoResult<Void> clearData(final long flags) { return null; }
    public static class ClearFlags {
        public static final long COOKIES = 1; public static final long NETWORK_CACHE = 2; public static final long IMAGE_CACHE = 4;
        public static final long DOM_STORAGES = 16; public static final long AUTH_SESSIONS = 32; public static final long PERMISSIONS = 64;
        public static final long ALL = 512;
    }
}
