package org.mozilla.geckoview;
public class WebRequestError { public final int code = 0; public final int category = 0; }
