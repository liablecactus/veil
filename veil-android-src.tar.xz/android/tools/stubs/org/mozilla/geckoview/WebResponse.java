package org.mozilla.geckoview;
public class WebResponse { public final String uri = ""; public final java.io.InputStream body = null; }
