package org.mozilla.geckoview;
import java.util.List;
public class WebExtensionController {
    public interface PromptDelegate {
        default GeckoResult<WebExtension.PermissionPromptResponse> onInstallPromptRequest(WebExtension extension, String[] permissions, String[] origins, String[] dataCollectionPermissions) { return null; }
    }
    public static class EnableSource { public static final int USER = 1, APP = 2; }
    public void setPromptDelegate(PromptDelegate d) {}
    public GeckoResult<WebExtension> install(String uri) { return null; }
    public GeckoResult<WebExtension> setAllowedInPrivateBrowsing(WebExtension extension, boolean allowed) { return null; }
    public GeckoResult<WebExtension> ensureBuiltIn(String uri, String id) { return null; }
    public GeckoResult<Void> uninstall(WebExtension extension) { return null; }
    public GeckoResult<WebExtension> enable(WebExtension extension, int source) { return null; }
    public GeckoResult<WebExtension> disable(WebExtension extension, int source) { return null; }
    public GeckoResult<List<WebExtension>> list() { return null; }
}
