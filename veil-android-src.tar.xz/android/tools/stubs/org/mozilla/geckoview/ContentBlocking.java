package org.mozilla.geckoview;
public class ContentBlocking {
    public static class AntiTracking { public static final int NONE = 0, DEFAULT = 2 | 4 | 8 | 32, STRICT = 0xFFFF; }
    public static class SafeBrowsing { public static final int NONE = 0, DEFAULT = 1; }
    public static class CookieBehavior { public static final int ACCEPT_ALL = 0, ACCEPT_FIRST_PARTY = 1, ACCEPT_NONE = 2, ACCEPT_VISITED = 3, ACCEPT_NON_TRACKERS = 4, ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS = 5; }
    public static class EtpLevel { public static final int NONE = 0, DEFAULT = 1, STRICT = 2; }
    public static class BlockEvent { public final String uri = ""; public boolean isBlocking() { return true; } }
    public interface Delegate {
        default void onContentBlocked(GeckoSession session, BlockEvent event) {}
        default void onContentLoaded(GeckoSession session, BlockEvent event) {}
    }
    public static class Settings {
        public Settings setCookieBehavior(int b) { return this; }
        public Settings setCookieBehaviorPrivateMode(int b) { return this; }
        public Settings setAntiTracking(int c) { return this; }
        public Settings setEnhancedTrackingProtectionLevel(int l) { return this; }
        public Settings setStrictSocialTrackingProtection(boolean e) { return this; }
        public Settings setCookiePurging(boolean e) { return this; }
        public static class Builder {
            public Builder antiTracking(int v) { return this; }
            public Builder safeBrowsing(int v) { return this; }
            public Builder cookieBehavior(int v) { return this; }
            public Builder cookieBehaviorPrivateMode(int v) { return this; }
            public Builder enhancedTrackingProtectionLevel(int v) { return this; }
            public Builder emailTrackerBlockingPrivateMode(boolean v) { return this; }
            public Builder strictSocialTrackingProtection(boolean v) { return this; }
            public Builder cookiePurging(boolean v) { return this; }
            public Builder queryParameterStrippingEnabled(boolean v) { return this; }
            public Builder queryParameterStrippingPrivateBrowsingEnabled(boolean v) { return this; }
            public Settings build() { return new Settings(); }
        }
    }
}
