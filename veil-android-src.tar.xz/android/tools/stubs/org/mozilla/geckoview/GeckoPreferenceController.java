package org.mozilla.geckoview;
public class GeckoPreferenceController {
    public static final int PREF_BRANCH_USER = 0; public static final int PREF_BRANCH_DEFAULT = 1;
    public static GeckoResult<Void> setGeckoPref(String prefName, String value, int branch) { return null; }
    public static GeckoResult<Void> setGeckoPref(String prefName, Integer value, int branch) { return null; }
    public static GeckoResult<Void> setGeckoPref(String prefName, Boolean value, int branch) { return null; }
    public static GeckoResult<Void> clearGeckoUserPref(String prefName) { return null; }
}
