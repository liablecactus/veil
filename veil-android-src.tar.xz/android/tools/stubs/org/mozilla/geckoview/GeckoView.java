package org.mozilla.geckoview;
import android.graphics.Bitmap;
public class GeckoView {
    public GeckoSession getSession() { return null; }
    public void setSession(GeckoSession session) {}
    public GeckoSession releaseSession() { return null; }
    public GeckoResult<Bitmap> capturePixels() { return null; }
    public void coverUntilFirstPaint(int color) {}
}
