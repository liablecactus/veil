package org.mozilla.geckoview;
import android.content.Context;
import android.net.Uri;
import java.util.List;
public class GeckoSession {
    public GeckoSession() {}
    public GeckoSession(GeckoSessionSettings settings) {}
    public static class Loader { public Loader uri(String u) { return this; } public Loader flags(int f) { return this; } }
    public void open(GeckoRuntime r) {} public void close() {} public boolean isOpen() { return true; }
    public void load(Loader l) {} public void reload() {} public void stop() {} public void goBack() {} public void goForward() {}
    public void setActive(boolean a) {} public void setFocused(boolean f) {} public void exitFullScreen() {}
    public GeckoSessionSettings getSettings() { return null; }
    public void setNavigationDelegate(NavigationDelegate d) {} public void setProgressDelegate(ProgressDelegate d) {}
    public void setContentDelegate(ContentDelegate d) {} public void setPermissionDelegate(PermissionDelegate d) {}
    public void setPromptDelegate(PromptDelegate d) {} public void setContentBlockingDelegate(ContentBlocking.Delegate d) {}

    public interface NavigationDelegate {
        class LoadRequest { public final String uri = ""; public final boolean hasUserGesture = false; }
        default void onLocationChange(GeckoSession session, String url, List<PermissionDelegate.ContentPermission> perms, Boolean hasUserGesture) {}
        default void onCanGoBack(GeckoSession session, boolean canGoBack) {}
        default void onCanGoForward(GeckoSession session, boolean canGoForward) {}
        default GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession session, LoadRequest request) { return null; }
        default GeckoResult<AllowOrDeny> onSubframeLoadRequest(GeckoSession session, LoadRequest request) { return null; }
        default GeckoResult<GeckoSession> onNewSession(GeckoSession session, String uri) { return null; }
        default GeckoResult<String> onLoadError(GeckoSession session, String uri, WebRequestError error) { return null; }
    }
    public interface ProgressDelegate {
        class SecurityInformation { public final boolean isSecure = false; }
        default void onPageStart(GeckoSession session, String url) {}
        default void onPageStop(GeckoSession session, boolean success) {}
        default void onProgressChange(GeckoSession session, int progress) {}
        default void onSecurityChange(GeckoSession session, SecurityInformation securityInfo) {}
    }
    public interface ContentDelegate {
        class ContextElement { public final String linkUri = null; public final String srcUri = null; public final int type = 0; }
        default void onTitleChange(GeckoSession session, String title) {}
        default void onFullScreen(GeckoSession session, boolean fullScreen) {}
        default void onCloseRequest(GeckoSession session) {}
        default void onExternalResponse(GeckoSession session, WebResponse response) {}
        default void onContextMenu(GeckoSession session, int screenX, int screenY, ContextElement element) {}
        default void onCrash(GeckoSession session) {}
        default void onKill(GeckoSession session) {}
    }
    public interface PermissionDelegate {
        int PERMISSION_GEOLOCATION = 0, PERMISSION_DESKTOP_NOTIFICATION = 5, PERMISSION_STORAGE_ACCESS = 8, PERMISSION_AUTOPLAY_INAUDIBLE = 3, PERMISSION_AUTOPLAY_AUDIBLE = 4, PERMISSION_TRACKING = 7;
        class ContentPermission {
            public static final int VALUE_ALLOW = 1, VALUE_DENY = 2, VALUE_PROMPT = 3;
            public final String uri = ""; public final int permission = 0; public final int value = 0;
        }
        class MediaSource {
            public static final int SOURCE_CAMERA = 0, SOURCE_MICROPHONE = 1, TYPE_VIDEO = 0, TYPE_AUDIO = 1;
            public final String id = ""; public final String name = ""; public final int source = 0; public final int type = 0;
        }
        interface Callback { void grant(); void reject(); }
        interface MediaCallback { void grant(String video, String audio); void grant(MediaSource video, MediaSource audio); void reject(); }
        default void onAndroidPermissionsRequest(GeckoSession session, String[] permissions, Callback callback) {}
        default GeckoResult<Integer> onContentPermissionRequest(GeckoSession session, ContentPermission perm) { return null; }
        default void onMediaPermissionRequest(GeckoSession session, String uri, MediaSource[] video, MediaSource[] audio, MediaCallback callback) {}
    }
    public interface PromptDelegate {
        class PromptResponse {}
        class BasePrompt { public PromptResponse dismiss() { return null; } public String title = null; }
        class AlertPrompt extends BasePrompt { public final String message = null; }
        class ButtonPrompt extends BasePrompt {
            public enum Type { POSITIVE, NEGATIVE }
            public final String message = null;
            public PromptResponse confirm(Type t) { return null; }
        }
        class TextPrompt extends BasePrompt { public final String message = null; public final String defaultValue = null; public PromptResponse confirm(String text) { return null; } }
        class AuthPrompt extends BasePrompt {
            public static class AuthOptions { public static class Flags { public static final int ONLY_PASSWORD = 1; } public final int flags = 0; public final String username = null; public final String uri = null; }
            public final AuthOptions authOptions = null;
            public PromptResponse confirm(String password) { return null; }
            public PromptResponse confirm(String user, String password) { return null; }
        }
        class ChoicePrompt extends BasePrompt {
            public static class Type { public static final int SINGLE = 1, MENU = 2, MULTIPLE = 3; }
            public static class Choice { public final String id = ""; public final String label = null; public final boolean selected = false; public final boolean disabled = false; public final boolean separator = false; public final Choice[] items = null; }
            public final int type = 1; public final Choice[] choices = null;
            public PromptResponse confirm(String id) { return null; }
            public PromptResponse confirm(String[] ids) { return null; }
        }
        class PopupPrompt extends BasePrompt { public final String targetUri = null; public PromptResponse confirm(AllowOrDeny a) { return null; } }
        class BeforeUnloadPrompt extends BasePrompt { public PromptResponse confirm(AllowOrDeny a) { return null; } }
        class RepostConfirmPrompt extends BasePrompt { public PromptResponse confirm(AllowOrDeny a) { return null; } }
        class FilePrompt extends BasePrompt {
            public static class Type { public static final int SINGLE = 1, MULTIPLE = 2, FOLDER = 3; }
            public final int type = 1; public final String[] mimeTypes = null;
            public PromptResponse confirm(Context c, Uri u) { return null; }
            public PromptResponse confirm(Context c, Uri[] u) { return null; }
        }
        default GeckoResult<PromptResponse> onAlertPrompt(GeckoSession s, AlertPrompt p) { return null; }
        default GeckoResult<PromptResponse> onButtonPrompt(GeckoSession s, ButtonPrompt p) { return null; }
        default GeckoResult<PromptResponse> onTextPrompt(GeckoSession s, TextPrompt p) { return null; }
        default GeckoResult<PromptResponse> onAuthPrompt(GeckoSession s, AuthPrompt p) { return null; }
        default GeckoResult<PromptResponse> onChoicePrompt(GeckoSession s, ChoicePrompt p) { return null; }
        default GeckoResult<PromptResponse> onPopupPrompt(GeckoSession s, PopupPrompt p) { return null; }
        default GeckoResult<PromptResponse> onBeforeUnloadPrompt(GeckoSession s, BeforeUnloadPrompt p) { return null; }
        default GeckoResult<PromptResponse> onRepostConfirmPrompt(GeckoSession s, RepostConfirmPrompt p) { return null; }
        default GeckoResult<PromptResponse> onFilePrompt(GeckoSession s, FilePrompt p) { return null; }
    }
}
