package org.mozilla.geckoview;
public class WebExtension {
    public final String location = ""; public final String id = ""; public final boolean isBuiltIn = false;
    public final MetaData metaData = null;
    public static class MetaData {
        public final String name = null; public final String description = null; public final String version = "";
        public final String[] optionalPermissions = null; public final String[] requiredPermissions = null; public final String[] requiredOrigins = null;
        public final boolean enabled = true; public final boolean allowedInPrivateBrowsing = false;
    }
    public static class PermissionPromptResponse {
        public PermissionPromptResponse(boolean isPermissionsGranted, boolean isPrivateModeGranted, boolean isTechnicalAndInteractionDataGranted) {}
    }
}
