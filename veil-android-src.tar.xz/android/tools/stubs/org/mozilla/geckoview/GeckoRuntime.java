package org.mozilla.geckoview;
import android.content.Context;
public class GeckoRuntime {
    public static GeckoRuntime create(Context context, GeckoRuntimeSettings settings) { return new GeckoRuntime(); }
    public GeckoRuntimeSettings getSettings() { return null; }
    public WebExtensionController getWebExtensionController() { return null; }
    public StorageController getStorageController() { return null; }
}
