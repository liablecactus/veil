package org.mozilla.geckoview;
public class GeckoRuntimeSettings {
    public static final int COLOR_SCHEME_LIGHT = 0, COLOR_SCHEME_DARK = 1, COLOR_SCHEME_SYSTEM = -1;
    public static final int ALLOW_ALL = 0, HTTPS_ONLY_PRIVATE = 1, HTTPS_ONLY = 2;
    public ContentBlocking.Settings getContentBlocking() { return null; }
    public GeckoRuntimeSettings setPreferredColorScheme(int s) { return this; }
    public GeckoRuntimeSettings setGlobalPrivacyControl(boolean e) { return this; }
    public GeckoRuntimeSettings setAllowInsecureConnections(int level) { return this; }
    public GeckoRuntimeSettings setJavaScriptEnabled(boolean f) { return this; }
    public static class Builder {
        public Builder javaScriptEnabled(boolean b) { return this; }
        public Builder remoteDebuggingEnabled(boolean b) { return this; }
        public Builder aboutConfigEnabled(boolean b) { return this; }
        public Builder consoleOutput(boolean b) { return this; }
        public Builder debugLogging(boolean b) { return this; }
        public Builder loginAutofillEnabled(boolean b) { return this; }
        public Builder globalPrivacyControlEnabled(boolean b) { return this; }
        public Builder allowInsecureConnections(int l) { return this; }
        public Builder preferredColorScheme(int s) { return this; }
        public Builder contentBlocking(ContentBlocking.Settings s) { return this; }
        public Builder configFilePath(String p) { return this; }
        public GeckoRuntimeSettings build() { return new GeckoRuntimeSettings(); }
    }
}
