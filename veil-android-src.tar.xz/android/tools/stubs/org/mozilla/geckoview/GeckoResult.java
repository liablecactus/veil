package org.mozilla.geckoview;
public class GeckoResult<T> {
    public GeckoResult() {}
    public static <U> GeckoResult<U> fromValue(U value) { return new GeckoResult<>(); }
    public static <T> GeckoResult<T> fromException(Throwable error) { return new GeckoResult<>(); }
    public void complete(T value) {}
    public void completeExceptionally(Throwable e) {}
    public <U> GeckoResult<U> then(OnValueListener<T, U> v) { return null; }
    public <U> GeckoResult<U> then(OnValueListener<T, U> v, OnExceptionListener<U> e) { return null; }
    public GeckoResult<Void> accept(Consumer<T> v, Consumer<Throwable> e) { return null; }
    public interface OnValueListener<T, U> { GeckoResult<U> onValue(T value) throws Throwable; }
    public interface OnExceptionListener<V> { GeckoResult<V> onException(Throwable exception) throws Throwable; }
    public interface Consumer<T> { void accept(T t); }
}
