package net.freehaven.tor.control;
import java.io.IOException;
// Only what Veil calls. jtorctl 0.4.5.7: `signal` is declared as `public void signal(String signal) throws IOException`.
public class TorControlConnection {
    public void signal(String signal) throws IOException {}
}
